﻿using AmbulanceIs.Common;
using AmbulanceIs.Forms;
using AmbulanceIs.Services;
using AmbulanceIs.Tools;

namespace AmbulanceIs;

/// <summary>Точка входа приложения и обработка необработанных исключений.</summary>
internal static class Program
{
    private const string SelfTestArgument = "--selftest";
    private const string ScreensArgument = "--screens";
    private const string DataTestArgument = "--datatest";

    [STAThread]
    private static int Main(string[] args)
    {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        Application.SetHighDpiMode(HighDpiMode.SystemAware);

        AppDomain.CurrentDomain.UnhandledException += (_, e) =>
        {
            var error = e.ExceptionObject as Exception;
            MessageBox.Show(
                "В работе приложения возникла непредвиденная ошибка. Данные не сохранены.\r\n" +
                "Перезапустите приложение. Если ошибка повторяется, обратитесь к администратору.\r\n\r\n" +
                error?.Message,
                "Непредвиденная ошибка",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        };

        Application.ThreadException += (_, e) =>
        {
            MessageBox.Show(
                "Операция не выполнена из-за непредвиденной ошибки. Приложение продолжает работу.\r\n\r\n" +
                e.Exception.Message,
                "Ошибка выполнения операции",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        };

        try
        {
            if (args.Contains(SelfTestArgument))
            {
                return SelfTest.Run();
            }

            if (args.Contains(DataTestArgument))
            {
                return DataTest.Run();
            }

            if (args.Contains(ScreensArgument))
            {
                var index = Array.IndexOf(args, ScreensArgument);
                var directory = index >= 0 && index + 1 < args.Length
                    ? args[index + 1]
                    : Path.Combine(AppContext.BaseDirectory, "screens");
                try
                {
                    return ScreenshotRunner.Run(directory);
                }
                catch (Exception screensException)
                {
                    File.WriteAllText(Path.Combine(AppContext.BaseDirectory, "screens-error.log"), screensException.ToString());
                    return 2;
                }
            }

            RunApplication();
            return 0;
        }
        catch (Exception exception)
        {
            File.WriteAllText(Path.Combine(AppContext.BaseDirectory, "fatal-error.log"), exception.ToString());
            MessageBox.Show(exception.Message, "Критическая ошибка приложения", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return 1;
        }
    }

    private static void RunApplication()
    {
        var repository = new UserRepository();
        var authenticationService = new AuthenticationService(repository);

        while (true)
        {
            using var loginForm = new LoginForm(authenticationService, repository);
            if (loginForm.ShowDialog() != DialogResult.OK)
            {
                return;
            }

            Session.CurrentUser = loginForm.AuthenticatedUser;
            var store = StoreFile.Exists ? StoreFile.Load() : DataStore.ResetDemo();
            Session.DemoMode = store.IsDemo;
            StoreFile.TrySave(store);
            using var mainForm = new MainForm(store, repository);
            mainForm.ShowDialog();

            if (!mainForm.SwitchUserRequested)
            {
                return;
            }
        }
    }
}
