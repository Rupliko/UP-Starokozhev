﻿using AmbulanceIs.Common;
using AmbulanceIs.Domain;
using AmbulanceIs.Forms.Base;
using AmbulanceIs.Services;

namespace AmbulanceIs.Forms.References;

/// <summary>Окно справочника больниц, принимающих пациентов службы скорой помощи.</summary>
public class HospitalForm : EntityForm<Hospital>
{
    private readonly TextBox _nameBox = AppTheme.CreateTextBox();
    private readonly TextBox _addressBox = AppTheme.CreateTextBox();
    private readonly TextBox _profileBox = AppTheme.CreateTextBox();

    public HospitalForm(DataStore store)
        : base(store, "Больницы", "Справочник медицинских организаций для направления пациентов при госпитализации")
    {
    }

    protected override string SearchPlaceholder => "Наименование или профиль";

    protected override string EntityName => "Больница";

    protected override void ConfigureColumns(DataGridView grid)
    {
        grid.AutoGenerateColumns = false;
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Наименование", DataPropertyName = nameof(Hospital.Name), FillWeight = 190 });
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Адрес", DataPropertyName = nameof(Hospital.Address), FillWeight = 190 });
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Профиль", DataPropertyName = nameof(Hospital.Profile), FillWeight = 150 });
    }

    protected override void BuildEditor(FlowLayoutPanel host)
    {
        AddEditorRow(host, "Наименование *", _nameBox, "Например: БСМП №2");
        AddEditorRow(host, "Адрес *", _addressBox);
        AddEditorRow(host, "Профиль отделений", _profileBox, "Например: Хирургия, терапия");
    }

    protected override void ClearEditor()
    {
        _nameBox.Clear();
        _addressBox.Clear();
        _profileBox.Clear();
    }

    protected override Hospital CreateEntity()
    {
        if (_nameBox.Text.Trim().Length < 3)
        {
            throw new InputValidationException("Поле «Наименование» должно содержать не менее 3 символов.");
        }

        if (_addressBox.Text.Trim().Length < 5)
        {
            throw new InputValidationException("Поле «Адрес» должно содержать не менее 5 символов.");
        }

        return new Hospital
        {
            Id = Store.Hospitals.Count == 0 ? 1 : Store.Hospitals.Max(item => item.Id) + 1,
            Name = _nameBox.Text.Trim(),
            Address = _addressBox.Text.Trim(),
            Profile = _profileBox.Text.Trim()
        };
    }

    protected override void FillEditor(Hospital item)
    {
        _nameBox.Text = item.Name;
        _addressBox.Text = item.Address;
        _profileBox.Text = item.Profile;
    }

    protected override IReadOnlyList<Hospital> LoadItems() => Store.Hospitals;

    protected override void EditExisting(Hospital? current, Hospital updated)
    {
        if (current is null)
        {
            return;
        }

        current.Name = updated.Name;
        current.Address = updated.Address;
        current.Profile = updated.Profile;
    }

    protected override void PersistNew(Hospital entity) => Store.Hospitals.Add(entity);

    protected override void PersistDelete(Hospital entity) => Store.Hospitals.Remove(entity);

    protected override bool MatchesSearch(Hospital item, string query) =>
        item.Name.Contains(query, StringComparison.OrdinalIgnoreCase);
}
