﻿namespace AmbulanceIs.Domain;

/// <summary>Запись о вхождении сотрудника в состав бригады на период дежурства.</summary>
public class CrewMember
{
    public int CrewId { get; set; }

    public int EmployeeId { get; set; }

    public string RoleInCrew { get; set; } = string.Empty;

    public DateTime DateFrom { get; set; }

    public DateTime? DateTo { get; set; }

    public bool IsActiveOn(DateTime date) => DateFrom.Date <= date.Date && (DateTo is null || DateTo.Value.Date >= date.Date);
}
