﻿using AmbulanceIs.Common;
using AmbulanceIs.Domain;
using AmbulanceIs.Forms.Base;
using AmbulanceIs.Services;

namespace AmbulanceIs.Forms.Queries;

/// <summary>Запрос 2: перечень и общее число сотрудников указанной категории.</summary>
public class Query02EmployeesForm : QueryFormBase
{
    private readonly FilterCombo _categoryCombo = new();
    private readonly FilterCombo _stationCombo = new();

    public Query02EmployeesForm(DataStore store)
        : base(store, "Сотрудники службы",
            "Перечень и общее число сотрудников указанной категории для конкретной подстанции либо всей службы города")
    {
        _categoryCombo.Fill([(null, "Все категории"), (0, "Врачи"), (1, "Фельдшеры"), (2, "Медсёстры"), (3, "Водители"), (4, "Диспетчеры")]);
        _stationCombo.Fill(StationOptions());
    }

    protected override void BuildFilters(FlowLayoutPanel host)
    {
        AddFilter(host, "Категория персонала", _categoryCombo);
        AddFilter(host, "Подстанция", _stationCombo, 260);
    }

    protected override QueryResult Execute()
    {
        EmployeeCategory? category = _categoryCombo.SelectedValue is int value ? (EmployeeCategory)value : null;
        return Service.GetEmployees(category, _stationCombo.SelectedValue);
    }
}
