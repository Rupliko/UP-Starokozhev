﻿using System.Runtime.InteropServices;
using AmbulanceIs.Common;

namespace AmbulanceIs.Controls;

/// <summary>Поле поиска с подсказкой, отображаемой средствами Windows, пока строка пуста.</summary>
public class PlaceholderTextBox : TextBox
{
    private const int EmSetCueBanner = 0x1501;
    private string _placeholder = string.Empty;

    public PlaceholderTextBox()
    {
        Font = AppTheme.Body(9.75F);
        BorderStyle = BorderStyle.FixedSingle;
    }

    /// <summary>Текст подсказки, поясняющий, что можно вводить.</summary>
    public string Placeholder
    {
        get => _placeholder;
        set
        {
            _placeholder = value ?? string.Empty;
            ApplyCueBanner();
        }
    }

    [DllImport("user32.dll", CharSet = CharSet.Unicode)]
    private static extern IntPtr SendMessage(IntPtr hWnd, int msg, IntPtr wParam, string lParam);

    protected override void OnHandleCreated(EventArgs e)
    {
        base.OnHandleCreated(e);
        ApplyCueBanner();
    }

    private void ApplyCueBanner()
    {
        if (!IsHandleCreated)
        {
            return;
        }

        SendMessage(Handle, EmSetCueBanner, (IntPtr)1, _placeholder);
    }
}
