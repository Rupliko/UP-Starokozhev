﻿using System.Text;
using AmbulanceIs.Common;
using AmbulanceIs.Domain;
using AmbulanceIs.Services;

namespace AmbulanceIs.Forms.Base;

/// <summary>Базовое окно запроса: панель условий отбора, таблица результата и строка итогов.</summary>
public abstract class QueryFormBase : Form
{
    private readonly DataGridView _grid = new();
    private readonly FlowLayoutPanel _filtersHost;
    private readonly Label _summaryLabel;
    private readonly Label _emptyLabel;
    private readonly Panel _gridHost;
    private readonly ToolTip _toolTip = new()
    {
        AutoPopDelay = 9000,
        InitialDelay = 400,
        ReshowDelay = 200,
        ShowAlways = true
    };

    private QueryResult? _lastResult;

    protected QueryFormBase(DataStore store, string title, string subtitle)
    {
        Store = store;
        Service = new QueryService(store);

        Text = title;
        StartPosition = FormStartPosition.CenterParent;
        MinimumSize = new Size(960, 560);
        ClientSize = new Size(1100, 660);
        BackColor = AppTheme.Surface;
        Font = AppTheme.Body();

        var header = new PageHeaderPanel(title, subtitle);

        _filtersHost = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false,
            AutoScroll = true,
            Padding = new Padding(16, 8, 8, 4),
            BackColor = Color.White
        };

        var runButton = AppTheme.CreatePrimaryButton("Выполнить запрос", 170);
        runButton.Click += (_, _) => RunQuery();
        var resetButton = AppTheme.CreateSecondaryButton("Очистить", 110);
        resetButton.Click += (_, _) => ResetFilters();
        var exportButton = AppTheme.CreateSecondaryButton("Экспорт в CSV", 140);
        exportButton.Click += (_, _) => ExportToCsv();

        var filterBar = new Panel { Dock = DockStyle.Top, Height = 92, BackColor = Color.White };
        filterBar.Controls.Add(_filtersHost);

        runButton.Height = 30;
        resetButton.Height = 30;
        exportButton.Height = 30;

        var actionPanel = new FlowLayoutPanel
        {
            Dock = DockStyle.Right,
            Width = 470,
            FlowDirection = FlowDirection.LeftToRight,
            Padding = new Padding(0, 8, 12, 0),
            BackColor = Color.White
        };
        actionPanel.Controls.Add(runButton);
        actionPanel.Controls.Add(resetButton);
        actionPanel.Controls.Add(exportButton);

        var summaryBar = new Panel { Dock = DockStyle.Top, Height = 46, BackColor = Color.White };
        _summaryLabel = new Label
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(18, 12, 12, 4),
            Font = AppTheme.SubHeading(9.5F),
            ForeColor = AppTheme.Primary,
            BackColor = Color.White,
            Text = "Задайте условия отбора и нажмите «Выполнить запрос». Чтобы получить все записи, оставьте условия без изменений."
        };
        summaryBar.Controls.Add(_summaryLabel);
        summaryBar.Controls.Add(actionPanel);

        AppTheme.StyleGrid(_grid);
        _grid.Dock = DockStyle.Fill;

        _emptyLabel = new Label
        {
            Dock = DockStyle.Fill,
            TextAlign = ContentAlignment.MiddleCenter,
            Font = AppTheme.Body(10F),
            ForeColor = AppTheme.TextMuted,
            Text = "Данные отсутствуют.\r\nЗадайте условия отбора и нажмите кнопку «Выполнить запрос».",
            Visible = false,
            BackColor = Color.White
        };

        _gridHost = new Panel { Dock = DockStyle.Fill, Padding = new Padding(16, 8, 16, 12), BackColor = AppTheme.Surface };
        _gridHost.Controls.Add(_emptyLabel);
        _gridHost.Controls.Add(_grid);

        BuildFilters(_filtersHost);

        _toolTip.SetToolTip(runButton, "Выполнить запрос с указанными условиями");
        _toolTip.SetToolTip(resetButton, "Вернуть условия отбора к значениям по умолчанию");
        _toolTip.SetToolTip(exportButton, "Сохранить найденные записи в файл CSV (открывается в Excel)");
        _toolTip.SetToolTip(_grid, "Результат запроса. Заголовки колонок можно сортировать щелчком");
        foreach (Control control in _filtersHost.Controls)
        {
            ApplyFilterToolTips(control);
        }

        Controls.Add(_gridHost);
        Controls.Add(summaryBar);
        Controls.Add(filterBar);
        Controls.Add(header);

        Shown += (_, _) => RunQuery();
    }

    protected DataStore Store { get; }

    protected QueryService Service { get; }

    /// <summary>Строит элементы отбора; элементы добавляются в конец панели условий.</summary>
    protected abstract void BuildFilters(FlowLayoutPanel host);

    protected abstract QueryResult Execute();

    /// <summary>Возвращает условия отбора к значениям по умолчанию и повторяет запрос.</summary>
    protected virtual void ResetFilters()
    {
        var pickers = new List<DateTimePicker>();
        CollectControls(_filtersHost, pickers);

        var (from, to) = DefaultPeriod();
        if (pickers.Count >= 2)
        {
            pickers[0].Value = from;
            pickers[1].Value = to;
        }
        else
        {
            foreach (var picker in pickers)
            {
                picker.Value = DateTime.Today;
            }
        }

        RunQuery();
    }

    private static void CollectControls(Control parent, List<DateTimePicker> pickers)
    {
        foreach (Control child in parent.Controls)
        {
            if (child is DateTimePicker picker)
            {
                pickers.Add(picker);
            }
            else if (child is FilterCombo combo && combo.Items.Count > 0)
            {
                combo.SelectedIndex = 0;
            }

            if (child.HasChildren)
            {
                CollectControls(child, pickers);
            }
        }
    }

    /// <summary>Назначает всплывающие подсказки элементам условий отбора.</summary>
    private void ApplyFilterToolTips(Control control)
    {
        foreach (Control child in control.Controls)
        {
            if (child is ComboBox)
            {
                _toolTip.SetToolTip(child, "Условие отбора: вариант «все…» не ограничивает выборку");
            }
            else if (child is DateTimePicker)
            {
                _toolTip.SetToolTip(child, "Граница периода: выберите дату из календаря");
            }
            else if (child is Button button)
            {
                _toolTip.SetToolTip(button, "Выполнить запрос с указанными условиями");
            }

            if (child.HasChildren)
            {
                ApplyFilterToolTips(child);
            }
        }
    }

    /// <summary>Добавляет группу условий: подпись и элемент управления.</summary>
    protected static void AddFilter(FlowLayoutPanel host, string label, Control control, int width = 200)
    {
        var group = new Panel
        {
            Width = width + 12,
            Height = 68,
            Margin = new Padding(0, 0, 6, 0),
            BackColor = Color.Transparent
        };

        var caption = new Label
        {
            Text = label,
            Dock = DockStyle.Top,
            Height = 20,
            Font = AppTheme.Body(8.75F),
            ForeColor = AppTheme.TextMuted
        };

        control.Dock = DockStyle.Top;
        control.Width = width;
        control.Font = AppTheme.Body(9.75F);

        group.Controls.Add(control);
        group.Controls.Add(caption);
        host.Controls.Add(group);
    }

    /// <summary>Добавляет кнопку в панель условий (например, для запуска запроса).</summary>
    protected static void AddFilterButton(FlowLayoutPanel host, Button button)
    {
        button.Margin = new Padding(0, 22, 8, 0);
        host.Controls.Add(button);
    }

    /// <summary>Варианты отбора по подстанциям.</summary>
    protected IEnumerable<(int? Value, string Text)> StationOptions(string allText = "Все подстанции")
    {
        yield return (null, allText);
        foreach (var substation in Store.Substations)
        {
            yield return (substation.Id, substation.ToString());
        }
    }

    /// <summary>Варианты отбора по бригадам; includeAll = false — только конкретные бригады.</summary>
    protected IEnumerable<(int? Value, string Text)> CrewOptions(string allText = "Все бригады", bool includeAll = true)
    {
        if (includeAll)
        {
            yield return (null, allText);
        }

        foreach (var crew in Store.Crews)
        {
            yield return (crew.Id, $"Бригада №{crew.Number} ({crew.TypeName})");
        }
    }

    /// <summary>Варианты отбора по сотрудникам указанной категории.</summary>
    protected IEnumerable<(int? Value, string Text)> EmployeeOptions(EmployeeCategory? category, string allText)
    {
        yield return (null, allText);
        foreach (var employee in Store.Employees.Where(employee => category is null || employee.Category == category)
                     .OrderBy(employee => employee.FullName))
        {
            yield return (employee.Id, employee.FullName);
        }
    }

    /// <summary>Варианты отбора по пациентам; includeAll = false — только конкретные пациенты.</summary>
    protected IEnumerable<(int? Value, string Text)> PatientOptions(bool includeAll = true)
    {
        if (includeAll)
        {
            yield return (null, "Все пациенты");
        }

        foreach (var patient in Store.Patients.OrderBy(patient => patient.FullName))
        {
            yield return (patient.Id, $"{patient.FullName}, {patient.Age} лет");
        }
    }

    /// <summary>Варианты отбора по автомобилям.</summary>
    protected IEnumerable<(int? Value, string Text)> VehicleOptions()
    {
        yield return (null, "Все автомобили");
        foreach (var vehicle in Store.Vehicles)
        {
            yield return (vehicle.Id, $"{vehicle.Brand} {vehicle.PlateNumber}");
        }
    }

    /// <summary>Период по умолчанию: диапазон дат имеющихся вызовов.</summary>
    protected (DateTime From, DateTime To) DefaultPeriod()
    {
        if (Store.Calls.Count == 0)
        {
            return (DateTime.Today.AddDays(-30), DateTime.Today);
        }

        return (Store.Calls.Min(call => call.ReceivedAt).Date, Store.Calls.Max(call => call.ReceivedAt).Date);
    }

    /// <summary>Проверяет корректность периода и возвращает его значения.</summary>
    protected static (DateTime From, DateTime To) ValidatePeriod(DateTimePicker fromPicker, DateTimePicker toPicker)
    {
        if (!InputValidator.TryParsePeriod(fromPicker.Value, toPicker.Value, out var error))
        {
            throw new InputValidationException(error);
        }

        return (fromPicker.Value.Date, toPicker.Value.Date);
    }

    protected void RunQuery()
    {
        try
        {
            var result = Execute();
            _lastResult = result;
            RenderResult(result);
        }
        catch (InputValidationException exception)
        {
            Messages.ShowError(this, exception.Message, "Некорректные условия запроса");
        }
        catch (Exception exception)
        {
            Messages.ShowError(this,
                "При выполнении запроса возникла непредвиденная ошибка. Проверьте условия отбора и повторите попытку.\r\n\r\n" + exception.Message,
                "Ошибка выполнения запроса");
        }
    }

    private void RenderResult(QueryResult result)
    {
        _grid.DataSource = null;
        _grid.Columns.Clear();
        _grid.AutoGenerateColumns = false;
        _grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;

        foreach (var column in result.Columns)
        {
            _grid.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = column.Header,
                DataPropertyName = column.PropertyName,
                FillWeight = column.Weight,
                MinimumWidth = 60
            });
        }

        _grid.Rows.Clear();
        foreach (var row in result.Rows)
        {
            var values = result.Columns.Select(column => row[column.PropertyName] ?? string.Empty).ToArray();
            _grid.Rows.Add(values);
        }

        _summaryLabel.Text = result.Summary;

        var empty = result.IsEmpty;
        _emptyLabel.Visible = empty;
        _grid.Visible = true;
        if (empty)
        {
            _emptyLabel.Text = "По заданным условиям записи не найдены.\r\nИзмените период или параметры отбора " +
                               "(кнопка «Очистить» возвращает значения по умолчанию).";
        }
    }

    private void ExportToCsv()
    {
        if (_lastResult is null || _lastResult.IsEmpty)
        {
            Messages.ShowWarning(this, "Нет данных для экспорта. Сначала выполните запрос.", "Экспорт невозможен");
            return;
        }

        using var dialog = new SaveFileDialog
        {
            Filter = "Файлы CSV (*.csv)|*.csv",
            FileName = $"Запрос_{DateTime.Now:yyyy-MM-dd_HH-mm}.csv",
            Title = "Сохранение результата запроса"
        };

        if (dialog.ShowDialog(this) != DialogResult.OK)
        {
            return;
        }

        var builder = new StringBuilder();
        builder.AppendLine(string.Join(";", _lastResult.Columns.Select(column => column.Header)));
        foreach (var row in _lastResult.Rows)
        {
            builder.AppendLine(string.Join(";", _lastResult.Columns.Select(column => row[column.PropertyName]?.ToString() ?? string.Empty)));
        }

        File.WriteAllText(dialog.FileName, builder.ToString(), new UTF8Encoding(true));
        Messages.ShowInfo(this, $"Результат запроса сохранён в файл:\r\n{dialog.FileName}", "Экспорт завершён");
    }
}
