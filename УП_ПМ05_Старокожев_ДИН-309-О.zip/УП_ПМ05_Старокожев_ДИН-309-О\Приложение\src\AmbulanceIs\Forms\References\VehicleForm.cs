﻿using AmbulanceIs.Common;
using AmbulanceIs.Domain;
using AmbulanceIs.Forms.Base;
using AmbulanceIs.Services;

namespace AmbulanceIs.Forms.References;

/// <summary>Окно справочника автомобилей автопарка.</summary>
public class VehicleForm : EntityForm<Vehicle>
{
    private readonly TextBox _brandBox = AppTheme.CreateTextBox();
    private readonly TextBox _plateBox = AppTheme.CreateTextBox();
    private readonly TextBox _yearBox = AppTheme.CreateTextBox();
    private readonly ComboBox _typeBox = AppTheme.CreateComboBox();
    private readonly ComboBox _substationBox = AppTheme.CreateComboBox();
    private readonly TextBox _mileageBox = AppTheme.CreateTextBox();

    public VehicleForm(DataStore store)
        : base(store, "Автопарк службы", "Справочник автомобилей: марка, государственный номер, тип и пробег")
    {
        _typeBox.Items.AddRange(["Реанимобиль", "Линейный"]);
        foreach (var substation in store.Substations)
        {
            _substationBox.Items.Add(substation);
        }
    }

    protected override string SearchPlaceholder => "Марка или госномер";

    protected override string EntityName => "Автомобиль";

    protected override void ConfigureColumns(DataGridView grid)
    {
        grid.AutoGenerateColumns = false;
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Марка", DataPropertyName = nameof(Vehicle.Brand), FillWeight = 140 });
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Госномер", DataPropertyName = nameof(Vehicle.PlateNumber), FillWeight = 90 });
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Год выпуска", DataPropertyName = nameof(Vehicle.ManufactureYear), FillWeight = 80 });
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Тип", DataPropertyName = nameof(Vehicle.TypeName), FillWeight = 100 });
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Подстанция", DataPropertyName = nameof(Vehicle.SubstationName), FillWeight = 150 });
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Пробег, км", DataPropertyName = nameof(Vehicle.MileageKm), FillWeight = 90 });
    }

    protected override void BuildEditor(FlowLayoutPanel host)
    {
        AddEditorRow(host, "Марка автомобиля *", _brandBox, "Например: ГАЗель Next");
        AddEditorRow(host, "Государственный номер *", _plateBox, "Например: А123ВС55");
        AddEditorRow(host, "Год выпуска *", _yearBox, "Четыре цифры, например: 2021");
        AddEditorRow(host, "Тип автомобиля *", _typeBox);
        AddEditorRow(host, "Подстанция *", _substationBox);
        AddEditorRow(host, "Пробег, км *", _mileageBox, "Целое число километров");
    }

    protected override void ClearEditor()
    {
        _brandBox.Clear();
        _plateBox.Clear();
        _yearBox.Clear();
        _typeBox.SelectedIndex = -1;
        _substationBox.SelectedIndex = -1;
        _mileageBox.Clear();
    }

    protected override Vehicle CreateEntity()
    {
        if (_brandBox.Text.Trim().Length < 2)
        {
            throw new InputValidationException("Поле «Марка автомобиля» обязательно для заполнения.");
        }

        if (!InputValidator.TryParsePlateNumber(_plateBox.Text, out var plate, out var plateError))
        {
            throw new InputValidationException(plateError);
        }

        if (!InputValidator.TryParseYear(_yearBox.Text, "Год выпуска", out var year, out var yearError))
        {
            throw new InputValidationException(yearError);
        }

        if (!InputValidator.TryParsePositiveInt(_mileageBox.Text, "Пробег", out var mileage, out var mileageError))
        {
            throw new InputValidationException(mileageError);
        }

        if (_typeBox.SelectedIndex < 0)
        {
            throw new InputValidationException("Выберите тип автомобиля из выпадающего списка.");
        }

        if (_substationBox.SelectedItem is not Substation substation)
        {
            throw new InputValidationException("Выберите подстанцию, за которой закреплён автомобиль.");
        }

        return new Vehicle
        {
            Id = Store.Vehicles.Count == 0 ? 1 : Store.Vehicles.Max(item => item.Id) + 1,
            Brand = _brandBox.Text.Trim(),
            PlateNumber = plate,
            ManufactureYear = year,
            Type = (VehicleType)_typeBox.SelectedIndex,
            SubstationId = substation.Id,
            MileageKm = mileage
        };
    }

    protected override void FillEditor(Vehicle item)
    {
        _brandBox.Text = item.Brand;
        _plateBox.Text = item.PlateNumber;
        _yearBox.Text = item.ManufactureYear.ToString();
        _typeBox.SelectedIndex = (int)item.Type;
        _substationBox.SelectedItem = Store.Substations.FirstOrDefault(substation => substation.Id == item.SubstationId);
        _mileageBox.Text = item.MileageKm.ToString();
    }

    protected override IReadOnlyList<Vehicle> LoadItems()
    {
        foreach (var vehicle in Store.Vehicles)
        {
            vehicle.SubstationName = Store.Substations.FirstOrDefault(substation => substation.Id == vehicle.SubstationId)?.ToString() ?? "—";
        }

        return Store.Vehicles;
    }

    protected override void EditExisting(Vehicle? current, Vehicle updated)
    {
        if (current is null)
        {
            return;
        }

        current.Brand = updated.Brand;
        current.PlateNumber = updated.PlateNumber;
        current.ManufactureYear = updated.ManufactureYear;
        current.Type = updated.Type;
        current.SubstationId = updated.SubstationId;
        current.MileageKm = updated.MileageKm;
    }

    protected override void PersistNew(Vehicle entity) => Store.Vehicles.Add(entity);

    protected override void PersistDelete(Vehicle entity) => Store.Vehicles.Remove(entity);

    protected override bool MatchesSearch(Vehicle item, string query) =>
        item.Brand.Contains(query, StringComparison.OrdinalIgnoreCase) ||
        item.PlateNumber.Contains(query, StringComparison.OrdinalIgnoreCase);
}
