﻿using AmbulanceIs.Domain;

namespace AmbulanceIs.Services;

/// <summary>Формирует демонстрационный набор данных, используемый для проверки запросов без подключения к БД.</summary>
public static class DemoDataProvider
{
    private static readonly string[] Streets =
    [
        "Ленина", "Маркса", "Кемеровская", "Мира", "Мельничная", "3-я Молодёжная",
        "Бульвар Архитекторов", "Маяковского", "Харьковская", "Дианова"
    ];

    private static readonly string[] Reasons =
    [
        "Боль в груди, одышка", "Высокая температура, слабость", "Потеря сознания",
        "Травма после падения", "Головная боль, гипертонический криз", "Боли в животе",
        "Одышка, затруднённое дыхание", "Судорожный приступ", "Отравление",
        "Резкое повышение артериального давления"
    ];

    private static readonly string[] Diagnoses =
    [
        "Острый коронарный синдром", "ОРВИ, лихорадка", "Обморок неясного генеза",
        "Закрытый перелом конечности", "Гипертонический криз", "Острый гастрит",
        "Бронхиальная астма, приступ", "Эпилептический приступ", "Пищевое отравление",
        "Аритмия, тахикардия"
    ];

    /// <summary>Оказанная помощь — выровнена с перечнем поводов к вызову.</summary>
    private static readonly string[] Aids =
    [
        "ЭКГ-контроль, нитроглицерин под язык, оксигенотерапия",
        "Жаропонижающие, инфузионная терапия",
        "Контроль глюкозы, инфузионная терапия, оксигенотерапия",
        "Иммобилизация, обезболивание, холод",
        "Гипотензивные препараты, контроль АД",
        "Спазмолитики, обезболивание, холод на живот",
        "Ингаляция бронхолитика, оксигенотерапия",
        "Противосудорожные препараты, оксигенотерапия",
        "Промывание желудка, сорбенты, инфузионная терапия",
        "Гипотензивные препараты, контроль АД, оксигенотерапия"
    ];

    public static DataStore Create()
    {
        var store = new DataStore();
        CreateSubstations(store);
        CreateEmployees(store);
        CreateVehicles(store);
        CreateCrews(store);
        CreatePatients(store);
        CreateHospitals(store);
        CreateCalls(store);
        store.IsDemo = true;
        return store;
    }

    private static void CreateSubstations(DataStore store)
    {
        store.Substations.AddRange(
        [
            new Substation { Id = 1, Number = "1", District = "Центральный", Address = "ул. Кемеровская, 6а", Phone = "78-01-03" },
            new Substation { Id = 2, Number = "2", District = "Кировский", Address = "ул. Мельничная, 132", Phone = "78-02-11" },
            new Substation { Id = 3, Number = "3", District = "Советский", Address = "пр. Мира, 58", Phone = "78-03-07" },
            new Substation { Id = 4, Number = "4", District = "Ленинский", Address = "ул. 3-я Молодёжная, 4", Phone = "78-04-19" }
        ]);
    }

    private static void CreateEmployees(DataStore store)
    {
        store.Employees.AddRange(
        [
            new Employee { Id = 1, FullName = "Иванов Пётр Сергеевич", Category = EmployeeCategory.Doctor, Specialization = DoctorSpecialization.Therapist, ExperienceYears = 18, SubstationId = 1 },
            new Employee { Id = 2, FullName = "Смирнова Анна Викторовна", Category = EmployeeCategory.Doctor, Specialization = DoctorSpecialization.Cardiologist, ExperienceYears = 12, SubstationId = 1 },
            new Employee { Id = 3, FullName = "Кузнецов Дмитрий Олегович", Category = EmployeeCategory.Doctor, Specialization = DoctorSpecialization.Resuscitator, ExperienceYears = 22, SubstationId = 2 },
            new Employee { Id = 4, FullName = "Петрова Елена Александровна", Category = EmployeeCategory.Doctor, Specialization = DoctorSpecialization.Pediatrician, ExperienceYears = 9, SubstationId = 2 },
            new Employee { Id = 5, FullName = "Соколов Артём Игоревич", Category = EmployeeCategory.Doctor, Specialization = DoctorSpecialization.Therapist, ExperienceYears = 6, SubstationId = 3 },
            new Employee { Id = 6, FullName = "Морозова Ольга Николаевна", Category = EmployeeCategory.Doctor, Specialization = DoctorSpecialization.Cardiologist, ExperienceYears = 15, SubstationId = 3 },
            new Employee { Id = 7, FullName = "Волков Сергей Анатольевич", Category = EmployeeCategory.Doctor, Specialization = DoctorSpecialization.Resuscitator, ExperienceYears = 11, SubstationId = 4 },
            new Employee { Id = 8, FullName = "Зайцева Мария Павловна", Category = EmployeeCategory.Doctor, Specialization = DoctorSpecialization.Pediatrician, ExperienceYears = 4, SubstationId = 4 },
            new Employee { Id = 9, FullName = "Лебедев Игорь Викторович", Category = EmployeeCategory.Feldsher, ExperienceYears = 14, SubstationId = 1 },
            new Employee { Id = 10, FullName = "Никитина Светлана Юрьевна", Category = EmployeeCategory.Feldsher, ExperienceYears = 8, SubstationId = 1 },
            new Employee { Id = 11, FullName = "Орлов Максим Денисович", Category = EmployeeCategory.Feldsher, ExperienceYears = 5, SubstationId = 2 },
            new Employee { Id = 12, FullName = "Фёдорова Татьяна Ильинична", Category = EmployeeCategory.Feldsher, ExperienceYears = 19, SubstationId = 2 },
            new Employee { Id = 13, FullName = "Медведев Андрей Валерьевич", Category = EmployeeCategory.Feldsher, ExperienceYears = 7, SubstationId = 3 },
            new Employee { Id = 14, FullName = "Соловьёва Ирина Андреевна", Category = EmployeeCategory.Feldsher, ExperienceYears = 3, SubstationId = 3 },
            new Employee { Id = 15, FullName = "Гусев Павел Олегович", Category = EmployeeCategory.Feldsher, ExperienceYears = 10, SubstationId = 4 },
            new Employee { Id = 16, FullName = "Белова Наталья Сергеевна", Category = EmployeeCategory.Nurse, ExperienceYears = 12, SubstationId = 1 },
            new Employee { Id = 17, FullName = "Тихонов Виктор Михайлович", Category = EmployeeCategory.Nurse, ExperienceYears = 9, SubstationId = 2 },
            new Employee { Id = 18, FullName = "Яковлева Дарья Сергеевна", Category = EmployeeCategory.Nurse, ExperienceYears = 6, SubstationId = 3 },
            new Employee { Id = 19, FullName = "Климов Евгений Петрович", Category = EmployeeCategory.Nurse, ExperienceYears = 4, SubstationId = 4 },
            new Employee { Id = 20, FullName = "Сорокин Вадим Николаевич", Category = EmployeeCategory.Driver, ExperienceYears = 21, SubstationId = 1 },
            new Employee { Id = 21, FullName = "Родионов Александр Иванович", Category = EmployeeCategory.Driver, ExperienceYears = 16, SubstationId = 2 },
            new Employee { Id = 22, FullName = "Максимов Юрий Петрович", Category = EmployeeCategory.Driver, ExperienceYears = 13, SubstationId = 3 },
            new Employee { Id = 23, FullName = "Степанов Николай Егорович", Category = EmployeeCategory.Driver, ExperienceYears = 24, SubstationId = 4 },
            new Employee { Id = 24, FullName = "Афанасьева Людмила Викторовна", Category = EmployeeCategory.Dispatcher, ExperienceYears = 17, SubstationId = 1 },
            new Employee { Id = 25, FullName = "Борисов Денис Алексеевич", Category = EmployeeCategory.Dispatcher, ExperienceYears = 8, SubstationId = 2 },
            new Employee { Id = 26, FullName = "Кулагина Екатерина Ивановна", Category = EmployeeCategory.Dispatcher, ExperienceYears = 11, SubstationId = 3 },
            new Employee { Id = 27, FullName = "Дементьев Роман Сергеевич", Category = EmployeeCategory.Driver, ExperienceYears = 7, SubstationId = 4 },
            new Employee { Id = 28, FullName = "Ершова Полина Дмитриевна", Category = EmployeeCategory.Feldsher, ExperienceYears = 12, SubstationId = 4 },
            new Employee { Id = 29, FullName = "Симонов Илья Владимирович", Category = EmployeeCategory.Driver, ExperienceYears = 6, SubstationId = 1 },
            new Employee { Id = 30, FullName = "Кравцов Олег Иванович", Category = EmployeeCategory.Driver, ExperienceYears = 15, SubstationId = 2 },
            new Employee { Id = 31, FullName = "Григорьев Станислав Юрьевич", Category = EmployeeCategory.Driver, ExperienceYears = 9, SubstationId = 3 }
        ]);
    }

    private static void CreateVehicles(DataStore store)
    {
        store.Vehicles.AddRange(
        [
            new Vehicle { Id = 1, Brand = "ГАЗель Next", PlateNumber = "А123ВС55", ManufactureYear = 2021, Type = VehicleType.Linear, SubstationId = 1, MileageKm = 148500 },
            new Vehicle { Id = 2, Brand = "Ford Transit", PlateNumber = "В456ЕК55", ManufactureYear = 2019, Type = VehicleType.Linear, SubstationId = 1, MileageKm = 214300 },
            new Vehicle { Id = 3, Brand = "Mercedes Sprinter", PlateNumber = "С789МН55", ManufactureYear = 2022, Type = VehicleType.Resuscitation, SubstationId = 2, MileageKm = 96500 },
            new Vehicle { Id = 4, Brand = "ГАЗель Next", PlateNumber = "Е234ОР55", ManufactureYear = 2020, Type = VehicleType.Linear, SubstationId = 2, MileageKm = 178900 },
            new Vehicle { Id = 5, Brand = "УАЗ Profi", PlateNumber = "К567ТУ55", ManufactureYear = 2018, Type = VehicleType.Linear, SubstationId = 3, MileageKm = 245700 },
            new Vehicle { Id = 6, Brand = "Mercedes Sprinter", PlateNumber = "М890АВ55", ManufactureYear = 2023, Type = VehicleType.Resuscitation, SubstationId = 3, MileageKm = 61400 },
            new Vehicle { Id = 7, Brand = "Ford Transit", PlateNumber = "Н345СЕ55", ManufactureYear = 2021, Type = VehicleType.Linear, SubstationId = 3, MileageKm = 132800 },
            new Vehicle { Id = 8, Brand = "ГАЗель Next", PlateNumber = "О678ХМ55", ManufactureYear = 2022, Type = VehicleType.Linear, SubstationId = 4, MileageKm = 87400 },
            new Vehicle { Id = 9, Brand = "Mercedes Sprinter", PlateNumber = "Р901УК55", ManufactureYear = 2020, Type = VehicleType.Resuscitation, SubstationId = 4, MileageKm = 156200 },
            new Vehicle { Id = 10, Brand = "УАЗ Profi", PlateNumber = "Т234НР55", ManufactureYear = 2017, Type = VehicleType.Linear, SubstationId = 4, MileageKm = 289500 }
        ]);
    }

    private static void CreateCrews(DataStore store)
    {
        store.Crews.AddRange(
        [
            new Crew { Id = 1, Number = "101", Type = CrewType.Feldsher, SubstationId = 1, VehicleId = 1, IsOnDuty = true },
            new Crew { Id = 2, Number = "102", Type = CrewType.Medical, SubstationId = 1, VehicleId = 2, IsOnDuty = true },
            new Crew { Id = 3, Number = "201", Type = CrewType.Feldsher, SubstationId = 2, VehicleId = 4, IsOnDuty = true },
            new Crew { Id = 4, Number = "202", Type = CrewType.Medical, SubstationId = 2, VehicleId = 3, IsOnDuty = true },
            new Crew { Id = 5, Number = "301", Type = CrewType.Feldsher, SubstationId = 3, VehicleId = 5, IsOnDuty = true },
            new Crew { Id = 6, Number = "302", Type = CrewType.Medical, SubstationId = 3, VehicleId = 6, IsOnDuty = false },
            new Crew { Id = 7, Number = "401", Type = CrewType.Medical, SubstationId = 4, VehicleId = 9, IsOnDuty = true },
            new Crew { Id = 8, Number = "402", Type = CrewType.Feldsher, SubstationId = 4, VehicleId = 8, IsOnDuty = false }
        ]);

        var since = new DateTime(2026, 1, 12);
        AddMembers(store, 1, since, (9, "Врач бригады"), (10, "Фельдшер"), (20, "Водитель"));
        AddMembers(store, 2, since, (1, "Врач бригады"), (16, "Медицинская сестра"), (29, "Водитель"));
        AddMembers(store, 3, since, (11, "Фельдшер-бригадир"), (12, "Фельдшер"), (21, "Водитель"));
        AddMembers(store, 4, since, (3, "Врач бригады"), (17, "Медицинская сестра"), (30, "Водитель"));
        AddMembers(store, 5, since, (13, "Фельдшер-бригадир"), (14, "Фельдшер"), (22, "Водитель"));
        AddMembers(store, 6, since, (6, "Врач бригады"), (18, "Медицинская сестра"), (31, "Водитель"));
        AddMembers(store, 7, since, (7, "Врач бригады"), (19, "Медицинская сестра"), (23, "Водитель"));
        AddMembers(store, 8, since, (15, "Фельдшер-бригадир"), (28, "Фельдшер"), (27, "Водитель"));
    }

    private static void AddMembers(DataStore store, int crewId, DateTime since, params (int EmployeeId, string Role)[] members)
    {
        foreach (var (employeeId, role) in members)
        {
            store.CrewMembers.Add(new CrewMember
            {
                CrewId = crewId,
                EmployeeId = employeeId,
                RoleInCrew = role,
                DateFrom = since
            });
        }
    }

    private static void CreatePatients(DataStore store)
    {
        store.Patients.AddRange(
        [
            new Patient { Id = 1, FullName = "Григорьева Нина Павловна", Sex = Sex.Female, Age = 74, District = "Центральный", PolicyNumber = "5501 112233" },
            new Patient { Id = 2, FullName = "Абрамов Виктор Степанович", Sex = Sex.Male, Age = 61, District = "Центральный", PolicyNumber = "5501 114455" },
            new Patient { Id = 3, FullName = "Ткаченко Людмила Ивановна", Sex = Sex.Female, Age = 45, District = "Кировский", PolicyNumber = "5502 223311" },
            new Patient { Id = 4, FullName = "Николаев Артём Юрьевич", Sex = Sex.Male, Age = 8, District = "Кировский", PolicyNumber = "5502 226677" },
            new Patient { Id = 5, FullName = "Семёнова Валентина Петровна", Sex = Sex.Female, Age = 82, District = "Советский", PolicyNumber = "5503 331122" },
            new Patient { Id = 6, FullName = "Крылов Денис Андреевич", Sex = Sex.Male, Age = 34, District = "Советский", PolicyNumber = "5503 334488" },
            new Patient { Id = 7, FullName = "Овчинникова Галина Фёдоровна", Sex = Sex.Female, Age = 67, District = "Ленинский", PolicyNumber = "5504 441199" },
            new Patient { Id = 8, FullName = "Белов Егор Максимович", Sex = Sex.Male, Age = 3, District = "Ленинский", PolicyNumber = "5504 445533" },
            new Patient { Id = 9, FullName = "Щербакова Тамара Ильинична", Sex = Sex.Female, Age = 91, District = "Центральный", PolicyNumber = "5501 116622" },
            new Patient { Id = 10, FullName = "Пономарёв Илья Сергеевич", Sex = Sex.Male, Age = 27, District = "Центральный", PolicyNumber = "5501 118844" },
            new Patient { Id = 11, FullName = "Дьяченко Светлана Олеговна", Sex = Sex.Female, Age = 39, District = "Кировский", PolicyNumber = "5502 227744" },
            new Patient { Id = 12, FullName = "Макаров Степан Николаевич", Sex = Sex.Male, Age = 55, District = "Советский", PolicyNumber = "5503 335566" },
            new Patient { Id = 13, FullName = "Романова Алина Викторовна", Sex = Sex.Female, Age = 12, District = "Ленинский", PolicyNumber = "5504 442277" },
            new Patient { Id = 14, FullName = "Артемьев Павел Игоревич", Sex = Sex.Male, Age = 48, District = "Кировский", PolicyNumber = "5502 229988" },
            new Patient { Id = 15, FullName = "Ковалёва Зоя Михайловна", Sex = Sex.Female, Age = 70, District = "Советский", PolicyNumber = "5503 337711" }
        ]);
    }

    private static void CreateHospitals(DataStore store)
    {
        store.Hospitals.AddRange(
        [
            new Hospital { Id = 1, Name = "БСМП №1", Address = "ул. Перелёта, 7", Profile = "Многопрофильная" },
            new Hospital { Id = 2, Name = "ГКБ №1 им. Кабанова", Address = "ул. Перелёта, 9", Profile = "Терапия, кардиология" },
            new Hospital { Id = 3, Name = "ГДКБ №3", Address = "ул. Кемеровская, 52", Profile = "Детская" },
            new Hospital { Id = 4, Name = "Областная клиническая больница", Address = "ул. Бульварная, 7", Profile = "Многопрофильная" }
        ]);
    }

    private static void CreateCalls(DataStore store)
    {
        var random = new Random(20261119);
        var start = new DateTime(2026, 10, 5);
        var numbers = 1;

        for (var date = start; date <= new DateTime(2026, 11, 18); date = date.AddDays(1))
        {
            var isWeekend = date.DayOfWeek == DayOfWeek.Saturday || date.DayOfWeek == DayOfWeek.Sunday;
            var callsPerDay = isWeekend ? 5 : 9;
            for (var index = 0; index < callsPerDay; index++)
            {
                var crew = store.Crews[random.Next(store.Crews.Count)];
                var patient = store.Patients[random.Next(store.Patients.Count)];
                var urgency = random.Next(100) < 70 ? UrgencyCategory.Emergency : UrgencyCategory.Urgent;
                var received = date.AddHours(7 + random.Next(15)).AddMinutes(random.Next(60));

                var norm = urgency.NormativeArrivalMinutes();
                var delayMinutes = random.Next(100) < 18 ? random.Next(2, 26) : random.Next(-9, 1);
                var arrival = received.AddMinutes(norm + delayMinutes);
                var finished = arrival.AddMinutes(25 + random.Next(45));

                var resultRoll = random.Next(100);
                var result = resultRoll < 55 ? CallResult.Hospitalized
                    : resultRoll < 78 ? CallResult.RefusedHospitalization
                    : CallResult.LeftAtPlace;

                // повод, диагноз и оказанная помощь берутся из одного клинического случая
                var caseIndex = random.Next(Reasons.Length);
                var isCurrent = date == new DateTime(2026, 11, 18) && index >= callsPerDay - 3;
                var status = isCurrent ? CallStatus.OnTheWay : CallStatus.Completed;

                var call = new Call
                {
                    Id = numbers,
                    Number = $"В-{numbers:0000}",
                    ReceivedAt = received,
                    District = patient.District,
                    Street = Streets[random.Next(Streets.Length)],
                    House = (1 + random.Next(60)).ToString(),
                    PatientId = patient.Id,
                    Reason = Reasons[caseIndex],
                    Urgency = urgency,
                    CrewId = crew.Id,
                    DoctorId = ResolveDoctorId(store, crew.Id),
                    Status = status
                };

                if (!isCurrent)
                {
                    call.ArrivalAt = arrival;
                    call.FinishedAt = finished;
                    call.Aid = Aids[caseIndex];
                    call.Diagnosis = Diagnoses[caseIndex];
                    call.Result = result;
                    if (result == CallResult.Hospitalized)
                    {
                        call.HospitalId = store.Hospitals[random.Next(store.Hospitals.Count)].Id;
                    }
                }

                store.Calls.Add(call);
                numbers++;
            }
        }

        RedistributeActiveCalls(store);
    }

    /// <summary>Распределяет незавершённые вызовы между дежурными бригадами разных подстанций.</summary>
    private static void RedistributeActiveCalls(DataStore store)
    {
        var activeCalls = store.Calls.Where(call => call.Status != CallStatus.Completed).ToList();
        var dutyCrews = store.Crews.Where(crew => crew.IsOnDuty).ToList();
        for (var index = 0; index < activeCalls.Count && dutyCrews.Count > 0; index++)
        {
            var crew = dutyCrews[index % dutyCrews.Count];
            activeCalls[index].CrewId = crew.Id;
            activeCalls[index].DoctorId = ResolveDoctorId(store, crew.Id);
        }
    }

    private static int? ResolveDoctorId(DataStore store, int crewId)
    {
        var member = store.CrewMembers.FirstOrDefault(item => item.CrewId == crewId && item.RoleInCrew == "Врач бригады");
        if (member is not null)
        {
            return member.EmployeeId;
        }

        var feldsher = store.CrewMembers.FirstOrDefault(item => item.CrewId == crewId && item.RoleInCrew == "Фельдшер-бригадир");
        return feldsher?.EmployeeId;
    }
}
