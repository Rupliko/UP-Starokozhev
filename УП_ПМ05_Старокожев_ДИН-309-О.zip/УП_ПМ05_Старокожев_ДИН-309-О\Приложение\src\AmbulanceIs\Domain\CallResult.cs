﻿namespace AmbulanceIs.Domain;

/// <summary>Результат обслуживания вызова.</summary>
public enum CallResult
{
    Hospitalized = 0,
    RefusedHospitalization = 1,
    LeftAtPlace = 2
}

/// <summary>Отображаемые названия результатов вызова.</summary>
public static class CallResultNames
{
    public static string ToRussian(this CallResult result) => result switch
    {
        CallResult.Hospitalized => "Госпитализация",
        CallResult.RefusedHospitalization => "Отказ от госпитализации",
        CallResult.LeftAtPlace => "Оставлен на месте",
        _ => "Не указан"
    };
}
