﻿namespace AmbulanceIs.Domain;

/// <summary>Больница, в которую госпитализируется пациент.</summary>
public class Hospital
{
    public int Id { get; set; }

    public string Name { get; set; } = string.Empty;

    public string Address { get; set; } = string.Empty;

    public string Profile { get; set; } = string.Empty;

    public override string ToString() => Name;
}
