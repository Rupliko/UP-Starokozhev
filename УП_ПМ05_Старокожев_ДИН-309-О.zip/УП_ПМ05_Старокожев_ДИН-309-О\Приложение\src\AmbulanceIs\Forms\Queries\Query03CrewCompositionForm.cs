﻿using AmbulanceIs.Common;
using AmbulanceIs.Domain;
using AmbulanceIs.Forms.Base;
using AmbulanceIs.Services;

namespace AmbulanceIs.Forms.Queries;

/// <summary>Запрос 3: состав указанной бригады на заданную дату.</summary>
public class Query03CrewCompositionForm : QueryFormBase
{
    private readonly FilterCombo _crewCombo = new();
    private readonly DateTimePicker _datePicker = new() { Format = DateTimePickerFormat.Long };

    public Query03CrewCompositionForm(DataStore store)
        : base(store, "Состав бригады",
            "Состав указанной бригады на текущий момент или на указанную дату")
    {
        _crewCombo.Fill(CrewOptions(includeAll: false));
        _datePicker.Value = DateTime.Today;
    }

    protected override void BuildFilters(FlowLayoutPanel host)
    {
        AddFilter(host, "Бригада", _crewCombo, 280);
        AddFilter(host, "Дата", _datePicker, 200);
    }

    protected override QueryResult Execute()
    {
        if (_crewCombo.SelectedValue is not int crewId)
        {
            throw new InputValidationException("Выберите бригаду, состав которой требуется получить.");
        }

        return Service.GetCrewComposition(crewId, _datePicker.Value.Date);
    }
}
