﻿using AmbulanceIs.Common;
using AmbulanceIs.Domain;
using AmbulanceIs.Forms.Base;
using AmbulanceIs.Services;

namespace AmbulanceIs.Forms.Queries;

/// <summary>Запрос 9: полная история обращений пациента в службу скорой помощи.</summary>
public class Query09PatientHistoryForm : QueryFormBase
{
    private readonly FilterCombo _patientCombo = new();

    public Query09PatientHistoryForm(DataStore store)
        : base(store, "История обращений пациента",
            "Даты вызовов, поводы, диагнозы и обслуживавшие бригады по указанному пациенту")
    {
        _patientCombo.Fill(PatientOptions(includeAll: false));
    }

    protected override void BuildFilters(FlowLayoutPanel host)
    {
        AddFilter(host, "Пациент", _patientCombo, 360);
    }

    protected override QueryResult Execute()
    {
        if (_patientCombo.SelectedValue is not int patientId)
        {
            throw new InputValidationException("Выберите пациента, историю обращений которого требуется получить.");
        }

        return Service.GetPatientHistory(patientId);
    }
}
