﻿namespace AmbulanceIs.Domain;

/// <summary>Текущее состояние обработки вызова.</summary>
public enum CallStatus
{
    Accepted = 0,
    Assigned = 1,
    OnTheWay = 2,
    InProgress = 3,
    Completed = 4
}

/// <summary>Отображаемые названия состояний вызова.</summary>
public static class CallStatusNames
{
    public static string ToRussian(this CallStatus status) => status switch
    {
        CallStatus.Accepted => "Принят диспетчером",
        CallStatus.Assigned => "Передан бригаде",
        CallStatus.OnTheWay => "Бригада в пути",
        CallStatus.InProgress => "Бригада на месте",
        CallStatus.Completed => "Завершён",
        _ => "Не указано"
    };
}
