﻿using AmbulanceIs.Common;
using AmbulanceIs.Domain;
using AmbulanceIs.Forms.Base;
using AmbulanceIs.Services;

namespace AmbulanceIs.Forms.Queries;

/// <summary>Запрос 10: госпитализации за период с указанием больницы.</summary>
public class Query10HospitalizationsForm : QueryFormBase
{
    private readonly DateTimePicker _fromPicker = new() { Format = DateTimePickerFormat.Short };
    private readonly DateTimePicker _toPicker = new() { Format = DateTimePickerFormat.Short };

    public Query10HospitalizationsForm(DataStore store)
        : base(store, "Госпитализации",
            "Перечень вызовов с госпитализацией и общее число госпитализаций за период по каждой больнице")
    {
        var (from, to) = DefaultPeriod();
        _fromPicker.Value = from;
        _toPicker.Value = to;
    }

    protected override void BuildFilters(FlowLayoutPanel host)
    {
        AddFilter(host, "Период с", _fromPicker, 160);
        AddFilter(host, "по", _toPicker, 160);
    }

    protected override QueryResult Execute()
    {
        var (from, to) = ValidatePeriod(_fromPicker, _toPicker);
        return Service.GetHospitalizations(from, to);
    }
}
