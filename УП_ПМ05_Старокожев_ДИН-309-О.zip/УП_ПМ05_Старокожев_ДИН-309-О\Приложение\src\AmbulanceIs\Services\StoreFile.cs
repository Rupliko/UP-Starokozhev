using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Serialization;
using AmbulanceIs.Domain;

namespace AmbulanceIs.Services;

/// <summary>
/// Сохранение набора данных приложения в файл JSON и загрузка из него.
/// Файл заменяет базу данных на время учебной практики: он читается при запуске
/// и перезаписывается после каждого изменения справочников и журнала вызовов.
/// </summary>
public static class StoreFile
{
    private static readonly JsonSerializerOptions Options = new()
    {
        WriteIndented = true,
        IgnoreReadOnlyProperties = true,
        Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,
        Converters = { new JsonStringEnumConverter() }
    };

    /// <summary>Каталог с файлом данных (по умолчанию — папка data рядом с исполняемым файлом).</summary>
    public static string Folder { get; set; } = Path.Combine(AppContext.BaseDirectory, "data");

    public static string FilePath => Path.Combine(Folder, "ambulance-data.json");

    public static bool Exists => File.Exists(FilePath);

    /// <summary>Автоматическое сохранение после каждого изменения.</summary>
    public static bool AutoSave { get; set; } = true;

    /// <summary>Текст последней ошибки сохранения или загрузки.</summary>
    public static string? LastError { get; private set; }

    /// <summary>Дата и время последнего успешного сохранения.</summary>
    public static DateTime? LastSavedAt { get; private set; }

    /// <summary>Загружает данные из файла; если файла нет, возвращает новый пустой набор.</summary>
    public static DataStore Load()
    {
        LastError = null;
        if (!Exists)
        {
            return new DataStore();
        }

        try
        {
            return FromJson(File.ReadAllText(FilePath));
        }
        catch (Exception exception)
        {
            LastError = $"Файл данных повреждён или недоступен: {exception.Message}. Загружен пустой набор записей.";
            return new DataStore();
        }
    }

    /// <summary>Сохраняет набор данных; при ошибке возвращает false и заполняет <see cref="LastError"/>.</summary>
    public static bool TrySave(DataStore store)
    {
        if (!AutoSave)
        {
            return true;
        }

        try
        {
            Save(store);
            LastError = null;
            return true;
        }
        catch (Exception exception)
        {
            LastError = $"Не удалось сохранить данные в файл: {exception.Message}";
            return false;
        }
    }

    /// <summary>Сохраняет набор данных в файл, заменяя его целиком.</summary>
    public static void Save(DataStore store)
    {
        Directory.CreateDirectory(Folder);
        var temporary = FilePath + ".tmp";
        File.WriteAllText(temporary, ToJson(store));
        File.Move(temporary, FilePath, overwrite: true);
        LastSavedAt = DateTime.Now;
    }

    /// <summary>Удаляет файл данных (используется для возврата к демонстрационному набору).</summary>
    public static void Delete()
    {
        if (Exists)
        {
            File.Delete(FilePath);
        }
    }

    /// <summary>Число записей в наборе данных — для строки состояния.</summary>
    public static int CountRecords(DataStore store)
        => store.Substations.Count + store.Employees.Count + store.Crews.Count + store.CrewMembers.Count +
           store.Vehicles.Count + store.Patients.Count + store.Calls.Count + store.Hospitals.Count;

    internal static string ToJson(DataStore store) => JsonSerializer.Serialize(store, Options);

    internal static DataStore FromJson(string json)
        => JsonSerializer.Deserialize<DataStore>(json, Options) ?? new DataStore();
}
