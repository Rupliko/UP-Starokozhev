using AmbulanceIs.Domain;
using AmbulanceIs.Services;

namespace AmbulanceIs.Tools;

/// <summary>
/// Проверка сохранения данных между запусками приложения:
/// добавляет запись в справочник, сохраняет файл, затем читает его заново.
/// Запуск: AmbulanceIs.exe --datatest (второй запуск подтверждает, что запись осталась).
/// </summary>
public static class DataTest
{
    private const string ProbeName = "Проверка сохранения (тестовая запись)";

    public static int Run()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        Console.WriteLine("=== Проверка сохранения данных в файл ===");
        Console.WriteLine($"Файл данных: {StoreFile.FilePath}");

        var store = StoreFile.Load();
        if (!StoreFile.Exists)
        {
            store = DataStore.ResetDemo();
            StoreFile.Save(store);
            Console.WriteLine("Файл данных создан из демонстрационного набора.");
        }

        var employeesBefore = store.Employees.Count;
        var existing = store.Employees.FirstOrDefault(employee => employee.FullName == ProbeName);
        Console.WriteLine(existing is null
            ? "Тестовая запись не найдена — выполняется добавление."
            : "Тестовая запись найдена в файле: сохранение между запусками работает.");

        if (existing is null)
        {
            if (store.Substations.Count == 0)
            {
                store.Substations.Add(new Substation
                {
                    Id = 1,
                    Number = "1",
                    District = "Тестовый район",
                    Address = "ул. Тестовая, 1",
                    Phone = "00-00-00"
                });
            }

            store.Employees.Add(new Employee
            {
                Id = store.Employees.Count == 0 ? 1 : store.Employees.Max(employee => employee.Id) + 1,
                FullName = ProbeName,
                Category = EmployeeCategory.Doctor,
                Specialization = DoctorSpecialization.Therapist,
                ExperienceYears = 10,
                SubstationId = store.Substations[0].Id
            });

            StoreFile.Save(store);
            Console.WriteLine($"Добавлена запись. Сотрудников было: {employeesBefore}, стало: {store.Employees.Count}.");
        }

        var reloaded = StoreFile.Load();
        var found = reloaded.Employees.Any(employee => employee.FullName == ProbeName);
        Console.WriteLine($"Записей в файле после повторного чтения: подстанций {reloaded.Substations.Count}, " +
                          $"сотрудников {reloaded.Employees.Count}, бригад {reloaded.Crews.Count}, " +
                          $"состав бригад {reloaded.CrewMembers.Count}, автомобилей {reloaded.Vehicles.Count}, " +
                          $"пациентов {reloaded.Patients.Count}, вызовов {reloaded.Calls.Count}, " +
                          $"больниц {reloaded.Hospitals.Count}.");
        Console.WriteLine(found ? "ИТОГ: данные сохраняются и загружаются." : "ИТОГ: запись не найдена после повторного чтения.");
        return found ? 0 : 1;
    }
}
