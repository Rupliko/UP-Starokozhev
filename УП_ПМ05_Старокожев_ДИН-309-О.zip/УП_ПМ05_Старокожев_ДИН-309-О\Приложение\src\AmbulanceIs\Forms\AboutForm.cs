﻿using AmbulanceIs.Common;

namespace AmbulanceIs.Forms;

/// <summary>Окно сведений о программе.</summary>
public class AboutForm : Form
{
    public AboutForm()
    {
        Text = "О программе";
        FormBorderStyle = FormBorderStyle.FixedDialog;
        StartPosition = FormStartPosition.CenterParent;
        MaximizeBox = false;
        MinimizeBox = false;
        ClientSize = new Size(520, 360);
        BackColor = Color.White;

        var title = new Label
        {
            Text = "АИС «Скорая помощь»",
            Dock = DockStyle.Top,
            Height = 44,
            Padding = new Padding(24, 22, 0, 0),
            Font = AppTheme.Heading(16F),
            ForeColor = AppTheme.Primary
        };

        var text = new Label
        {
            Dock = DockStyle.Fill,
            Padding = new Padding(24, 8, 24, 8),
            Font = AppTheme.Body(9.75F),
            ForeColor = AppTheme.TextPrimary,
            Text = "Информационная система службы скорой медицинской помощи.\r\n\r\n" +
                   "Назначение: учёт подстанций, персонала, выездных бригад и автопарка, " +
                   "регистрация вызовов и формирование аналитических отчётов.\r\n\r\n" +
                   "Версия 1.0 от 26.11.2026\r\n" +
                   "Разработчик: Старокожев М.Д., группа ДИН-309\r\n" +
                   "Специальность 09.02.07 «Информационные системы и программирование»\r\n\r\n" +
                   "Среда разработки: Microsoft Visual Studio Code, .NET, Windows Forms"
        };

        var closeButton = AppTheme.CreatePrimaryButton("Закрыть", 120);
        closeButton.Click += (_, _) => Close();
        var buttons = new FlowLayoutPanel { Dock = DockStyle.Bottom, Height = 56, Padding = new Padding(24, 10, 0, 0) };
        buttons.Controls.Add(closeButton);

        Controls.Add(text);
        Controls.Add(title);
        Controls.Add(buttons);
        AcceptButton = closeButton;
    }
}
