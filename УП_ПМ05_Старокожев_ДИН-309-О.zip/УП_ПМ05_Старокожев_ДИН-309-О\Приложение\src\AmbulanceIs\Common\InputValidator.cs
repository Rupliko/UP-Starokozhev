﻿using System.Globalization;

namespace AmbulanceIs.Common;

/// <summary>Проверка значений, вводимых пользователем, с формированием понятных сообщений об ошибке.</summary>
internal static class InputValidator
{
    public static bool TryParsePositiveInt(string text, string fieldName, out int value, out string error)
    {
        value = 0;
        error = string.Empty;
        if (string.IsNullOrWhiteSpace(text))
        {
            error = $"Поле «{fieldName}» обязательно для заполнения.";
            return false;
        }

        if (!int.TryParse(text.Trim(), NumberStyles.Integer, CultureInfo.CurrentCulture, out value))
        {
            error = $"Поле «{fieldName}» может содержать только целое число. Проверьте введённое значение.";
            return false;
        }

        if (value < 0)
        {
            error = $"Поле «{fieldName}» не может быть отрицательным.";
            return false;
        }

        return true;
    }

    public static bool TryParseYear(string text, string fieldName, out int value, out string error)
    {
        var success = TryParsePositiveInt(text, fieldName, out value, out error);
        if (!success)
        {
            return false;
        }

        var currentYear = DateTime.Today.Year;
        if (value < 1960 || value > currentYear)
        {
            error = $"Год выпуска в поле «{fieldName}» должен быть в диапазоне от 1960 до {currentYear}.";
            return false;
        }

        return true;
    }

    public static bool TryParsePlateNumber(string text, out string value, out string error)
    {
        value = text.Trim().ToUpperInvariant();
        error = string.Empty;
        if (value.Length < 6)
        {
            error = "Государственный номер автомобиля должен содержать не менее 6 символов, например: А123ВС55.";
            return false;
        }

        foreach (var symbol in value)
        {
            if (!char.IsLetterOrDigit(symbol) && symbol != ' ')
            {
                error = "Государственный номер автомобиля может содержать только буквы и цифры.";
                return false;
            }
        }

        return true;
    }

    public static bool TryParseFullName(string text, out string value, out string error)
    {
        value = text.Trim();
        error = string.Empty;
        if (value.Length < 5)
        {
            error = "Поле «ФИО» должно содержать не менее 5 символов в формате «Фамилия Имя Отчество».";
            return false;
        }

        if (value.Split(' ', StringSplitOptions.RemoveEmptyEntries).Length < 2)
        {
            error = "Поле «ФИО» должно содержать фамилию и имя, разделённые пробелом.";
            return false;
        }

        return true;
    }

    public static bool TryParsePeriod(DateTime from, DateTime to, out string error)
    {
        error = string.Empty;
        if (from > to)
        {
            error = "Дата начала периода не может быть позже даты окончания. Уточните границы периода.";
            return false;
        }

        return true;
    }
}
