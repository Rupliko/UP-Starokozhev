﻿namespace AmbulanceIs.Domain;

/// <summary>Специализация врача выездной бригады.</summary>
public enum DoctorSpecialization
{
    Therapist = 0,
    Cardiologist = 1,
    Pediatrician = 2,
    Resuscitator = 3,
    Surgeon = 4
}

/// <summary>Отображаемые названия специализаций.</summary>
public static class SpecializationNames
{
    public static string ToRussian(this DoctorSpecialization specialization) => specialization switch
    {
        DoctorSpecialization.Therapist => "Терапевт",
        DoctorSpecialization.Cardiologist => "Кардиолог",
        DoctorSpecialization.Pediatrician => "Педиатр",
        DoctorSpecialization.Resuscitator => "Реаниматолог",
        DoctorSpecialization.Surgeon => "Хирург",
        _ => "Не указана"
    };
}
