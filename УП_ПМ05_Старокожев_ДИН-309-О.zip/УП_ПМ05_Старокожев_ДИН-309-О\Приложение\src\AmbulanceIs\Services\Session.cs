﻿using AmbulanceIs.Domain;

namespace AmbulanceIs.Services;

/// <summary>Текущий сеанс работы: авторизованный пользователь и режим отображения данных.</summary>
public static class Session
{
    public static UserAccount? CurrentUser { get; set; }

    /// <summary>Демонстрационный режим подставляет тестовый набор данных вместо пустых таблиц.</summary>
    public static bool DemoMode { get; set; } = true;

    public static bool IsAdministrator => CurrentUser?.Role == UserRole.Administrator;

    public static string CurrentUserName => CurrentUser?.FullName ?? "Гость";
}
