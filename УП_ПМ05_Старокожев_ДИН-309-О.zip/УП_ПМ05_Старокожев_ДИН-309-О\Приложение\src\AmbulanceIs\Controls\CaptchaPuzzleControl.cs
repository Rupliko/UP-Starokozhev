﻿using AmbulanceIs.Common;

namespace AmbulanceIs.Controls;

/// <summary>Интерактивная капча-пазл: пользователь собирает изображение из четырёх фрагментов.</summary>
public class CaptchaPuzzleControl : UserControl
{
    private const int FragmentSize = 72;
    private const int FragmentCount = 4;

    private readonly TableLayoutPanel _slotsGrid;
    private readonly FlowLayoutPanel _fragmentsPanel;
    private readonly PictureBox?[] _slots = new PictureBox?[FragmentCount];
    private readonly bool[] _slotFilled = new bool[FragmentCount];
    private readonly List<PictureBox> _fragments = new();
    private readonly Label _hintLabel;
    private PictureBox? _selectedFragment;

    public CaptchaPuzzleControl()
    {
        BackColor = Color.White;
        Width = 430;
        Height = 290;
        MinimumSize = new Size(400, 270);
        Padding = new Padding(10);

        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 1,
            BackColor = Color.Transparent
        };
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 172));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

        _slotsGrid = new TableLayoutPanel
        {
            ColumnCount = 2,
            RowCount = 2,
            Dock = DockStyle.Fill,
            Margin = new Padding(0),
            Padding = new Padding(0)
        };
        _slotsGrid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        _slotsGrid.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        _slotsGrid.RowStyles.Add(new RowStyle(SizeType.Percent, 50));
        _slotsGrid.RowStyles.Add(new RowStyle(SizeType.Percent, 50));

        for (var index = 0; index < FragmentCount; index++)
        {
            var slot = CreatePictureBox();
            slot.AllowDrop = true;
            var slotIndex = index;
            slot.Click += (_, _) => OnSlotClick(slotIndex);
            slot.DragEnter += (_, e) => e.Effect = e.Data?.GetDataPresent(typeof(int)) == true ? DragDropEffects.Move : DragDropEffects.None;
            slot.DragDrop += (_, e) => OnSlotDrop(slotIndex, e);
            _slots[index] = slot;
            _slotsGrid.Controls.Add(slot, index % 2, index / 2);
        }

        var slotsPanel = new Panel { Dock = DockStyle.Fill, Margin = new Padding(0, 0, 8, 0) };
        slotsPanel.Controls.Add(_slotsGrid);

        var rightPanel = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 1,
            RowCount = 4,
            Margin = new Padding(0),
            Padding = new Padding(0),
            BackColor = Color.Transparent
        };
        rightPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        rightPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 22));
        rightPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, FragmentSize * 2 + 28));
        rightPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 34));
        rightPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));

        var bankTitle = new Label
        {
            Text = "Фрагменты изображения",
            Dock = DockStyle.Fill,
            Font = AppTheme.SubHeading(9.5F),
            ForeColor = AppTheme.TextMuted,
            TextAlign = ContentAlignment.MiddleLeft,
            Margin = new Padding(0)
        };

        _fragmentsPanel = new FlowLayoutPanel
        {
            Dock = DockStyle.None,
            Size = new Size(FragmentSize * 2 + 26, FragmentSize * 2 + 22),
            Location = new Point(0, 0),
            WrapContents = true,
            AutoScroll = false,
            Margin = new Padding(0)
        };
        var bankHost = new Panel { Dock = DockStyle.Fill, Margin = new Padding(0, 2, 0, 2) };
        bankHost.Controls.Add(_fragmentsPanel);

        var shufflePanel = new Panel { Dock = DockStyle.Fill, Margin = new Padding(0) };
        var shuffleButton = AppTheme.CreateSecondaryButton("Перемешать", 118);
        shuffleButton.Height = 28;
        shuffleButton.Margin = new Padding(0, 2, 0, 0);
        shuffleButton.Click += (_, _) => ShuffleFragments();
        shufflePanel.Controls.Add(shuffleButton);

        _hintLabel = new Label
        {
            Text = "Выберите фрагмент и укажите ячейку",
            Dock = DockStyle.Fill,
            Font = AppTheme.Body(8.75F),
            ForeColor = AppTheme.TextMuted,
            Margin = new Padding(0, 2, 0, 0)
        };

        rightPanel.Controls.Add(bankTitle, 0, 0);
        rightPanel.Controls.Add(bankHost, 0, 1);
        rightPanel.Controls.Add(shufflePanel, 0, 2);
        rightPanel.Controls.Add(_hintLabel, 0, 3);

        layout.Controls.Add(slotsPanel, 0, 0);
        layout.Controls.Add(rightPanel, 1, 0);
        Controls.Add(layout);

        LoadFragments();
        ShuffleFragments();
    }

    /// <summary>Признак того, что изображение собрано верно.</summary>
    public bool IsSolved
    {
        get
        {
            for (var index = 0; index < FragmentCount; index++)
            {
                if (!_slotFilled[index] || _slots[index]?.Tag is not int fragmentId || fragmentId != index + 1)
                {
                    return false;
                }
            }

            return true;
        }
    }

    /// <summary>Сбрасывает текущую сборку и заново перемешивает фрагменты.</summary>
    public void Reset()
    {
        for (var index = 0; index < FragmentCount; index++)
        {
            ReturnFragmentFromSlot(index);
        }

        _selectedFragment = null;
        ShuffleFragments();
    }

    /// <summary>Программно расставляет фрагменты в правильном порядке (используется при демонстрации).</summary>
    public void SolveAutomatically()
    {
        Reset();
        for (var index = 0; index < FragmentCount; index++)
        {
            var fragment = _fragments.FirstOrDefault(item => item.Tag is int id && id == index + 1);
            if (fragment is not null)
            {
                PlaceFragment(index, fragment);
            }
        }
    }

    private static PictureBox CreatePictureBox() => new()
    {
        Size = new Size(FragmentSize, FragmentSize),
        SizeMode = PictureBoxSizeMode.Zoom,
        BorderStyle = BorderStyle.FixedSingle,
        BackColor = Color.FromArgb(244, 246, 249),
        Margin = new Padding(3)
    };

    private void LoadFragments()
    {
        for (var index = 1; index <= FragmentCount; index++)
        {
            var picture = new PictureBox
            {
                Size = new Size(FragmentSize, FragmentSize),
                SizeMode = PictureBoxSizeMode.Zoom,
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = Color.White,
                Margin = new Padding(4),
                Tag = index,
                Cursor = Cursors.Hand
            };

            var path = Path.Combine(AppContext.BaseDirectory, "Assets", "captcha", $"{index}.png");
            if (File.Exists(path))
            {
                using var stream = File.OpenRead(path);
                picture.Image = Image.FromStream(stream);
            }
            else
            {
                picture.Image = CreateFallbackImage(index);
            }

            picture.Click += (_, _) => SelectFragment(picture);
            picture.MouseDown += (_, e) =>
            {
                if (e.Button == MouseButtons.Left)
                {
                    SelectFragment(picture);
                    picture.DoDragDrop(picture.Tag!, DragDropEffects.Move);
                }
            };

            _fragments.Add(picture);
        }

        foreach (var fragment in _fragments)
        {
            _fragmentsPanel.Controls.Add(fragment);
        }
    }

    private static Image CreateFallbackImage(int index)
    {
        var bitmap = new Bitmap(FragmentSize, FragmentSize);
        using var graphics = Graphics.FromImage(bitmap);
        graphics.Clear(Color.White);
        using var font = new Font(AppTheme.UiFamily, 20F, FontStyle.Bold);
        graphics.DrawString(index.ToString(), font, Brushes.SteelBlue, 30, 28);
        return bitmap;
    }

    private void ShuffleFragments()
    {
        var items = _fragments.ToList();
        var random = new Random();
        items = items.OrderBy(_ => random.Next()).ToList();
        _fragmentsPanel.Controls.Clear();
        foreach (var item in items)
        {
            _fragmentsPanel.Controls.Add(item);
        }
    }

    private void SelectFragment(PictureBox fragment)
    {
        foreach (var item in _fragments)
        {
            item.BorderStyle = BorderStyle.FixedSingle;
        }

        _selectedFragment = fragment;
        fragment.BorderStyle = BorderStyle.Fixed3D;
        _hintLabel.Text = "Фрагмент выбран. Укажите ячейку, в которую его следует поместить.";
    }

    private void OnSlotClick(int slotIndex)
    {
        if (_slotFilled[slotIndex])
        {
            ReturnFragmentFromSlot(slotIndex);
            return;
        }

        if (_selectedFragment is null)
        {
            _hintLabel.Text = "Сначала выберите фрагмент в правой части окна.";
            return;
        }

        PlaceFragment(slotIndex, _selectedFragment);
    }

    private void OnSlotDrop(int slotIndex, DragEventArgs e)
    {
        if (e.Data?.GetData(typeof(int)) is not int fragmentId)
        {
            return;
        }

        var fragment = _fragments.FirstOrDefault(item => item.Tag is int id && id == fragmentId);
        if (fragment is null)
        {
            return;
        }

        if (_slotFilled[slotIndex])
        {
            ReturnFragmentFromSlot(slotIndex);
        }

        PlaceFragment(slotIndex, fragment);
    }

    private void PlaceFragment(int slotIndex, PictureBox fragment)
    {
        var slot = _slots[slotIndex];
        if (slot is null)
        {
            return;
        }

        slot.Image = fragment.Image;
        slot.Tag = fragment.Tag;
        _slotFilled[slotIndex] = true;
        _fragmentsPanel.Controls.Remove(fragment);
        _selectedFragment = null;
        _hintLabel.Text = "Фрагмент установлен. Продолжайте сборку изображения.";
    }

    private void ReturnFragmentFromSlot(int slotIndex)
    {
        var slot = _slots[slotIndex];
        if (slot is null || !_slotFilled[slotIndex])
        {
            return;
        }

        var fragment = _fragments.FirstOrDefault(item => item.Tag is int id && slot.Tag is int slotId && id == slotId);
        if (fragment is not null)
        {
            _fragmentsPanel.Controls.Add(fragment);
        }

        slot.Image = null;
        slot.Tag = null;
        _slotFilled[slotIndex] = false;
        _hintLabel.Text = "Фрагмент возвращён в набор. Выберите другой фрагмент.";
    }
}
