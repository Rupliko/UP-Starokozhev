﻿namespace AmbulanceIs.Forms.Base;

/// <summary>Исключение, возникающее при некорректном вводе данных в диалоговом окне.</summary>
public class InputValidationException : Exception
{
    public InputValidationException(string message) : base(message)
    {
    }
}
