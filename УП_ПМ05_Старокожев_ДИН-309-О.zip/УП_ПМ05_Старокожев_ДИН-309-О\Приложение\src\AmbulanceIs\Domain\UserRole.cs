﻿namespace AmbulanceIs.Domain;

/// <summary>Роль пользователя информационной системы.</summary>
public enum UserRole
{
    Administrator = 0,
    Dispatcher = 1
}

/// <summary>Отображаемые названия ролей.</summary>
public static class UserRoleNames
{
    public static string ToRussian(this UserRole role) => role switch
    {
        UserRole.Administrator => "Администратор",
        UserRole.Dispatcher => "Пользователь",
        _ => "Не указана"
    };
}
