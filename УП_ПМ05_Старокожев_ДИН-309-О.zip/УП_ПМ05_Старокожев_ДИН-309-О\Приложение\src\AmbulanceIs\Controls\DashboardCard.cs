﻿using AmbulanceIs.Common;

namespace AmbulanceIs.Controls;

/// <summary>Карточка сводных показателей на главном окне.</summary>
public class DashboardCard : Panel
{
    private readonly Label _valueLabel;
    private readonly Label _captionLabel;

    public DashboardCard(string title, string caption, Color accent)
    {
        Width = 240;
        Height = 116;
        BackColor = Color.White;
        Margin = new Padding(0, 0, 16, 0);
        Cursor = Cursors.Hand;
        Padding = new Padding(16, 12, 16, 10);

        var titleLabel = new Label
        {
            Text = title,
            Dock = DockStyle.Top,
            Height = 22,
            Font = AppTheme.Body(9F),
            ForeColor = AppTheme.TextMuted
        };

        _valueLabel = new Label
        {
            Text = "0",
            Dock = DockStyle.Top,
            Height = 42,
            Font = new Font(AppTheme.UiFamily, 22F, FontStyle.Bold),
            ForeColor = accent
        };

        _captionLabel = new Label
        {
            Text = caption,
            Dock = DockStyle.Fill,
            Font = AppTheme.Body(8.5F),
            ForeColor = AppTheme.TextMuted
        };

        Controls.Add(_captionLabel);
        Controls.Add(_valueLabel);
        Controls.Add(titleLabel);

        AppTheme.ApplyRoundedBorder(this, AppTheme.Border);
    }

    public string Value
    {
        get => _valueLabel.Text;
        set => _valueLabel.Text = value;
    }

    public string Caption
    {
        get => _captionLabel.Text;
        set => _captionLabel.Text = value;
    }
}
