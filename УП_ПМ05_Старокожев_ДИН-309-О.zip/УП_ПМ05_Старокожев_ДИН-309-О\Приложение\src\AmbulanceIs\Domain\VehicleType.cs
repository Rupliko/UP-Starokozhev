﻿namespace AmbulanceIs.Domain;

/// <summary>Тип автомобиля скорой помощи.</summary>
public enum VehicleType
{
    Resuscitation = 0,
    Linear = 1
}

/// <summary>Отображаемые названия типов автомобилей.</summary>
public static class VehicleTypeNames
{
    public static string ToRussian(this VehicleType type) => type switch
    {
        VehicleType.Resuscitation => "Реанимобиль",
        VehicleType.Linear => "Линейный",
        _ => "Не указан"
    };
}
