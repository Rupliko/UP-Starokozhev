﻿namespace AmbulanceIs.Domain;

/// <summary>Категория персонала службы скорой помощи.</summary>
public enum EmployeeCategory
{
    Doctor = 0,
    Feldsher = 1,
    Nurse = 2,
    Driver = 3,
    Dispatcher = 4
}

/// <summary>Отображаемые названия категорий персонала.</summary>
public static class EmployeeCategoryNames
{
    public static string ToRussian(this EmployeeCategory category) => category switch
    {
        EmployeeCategory.Doctor => "Врач",
        EmployeeCategory.Feldsher => "Фельдшер",
        EmployeeCategory.Nurse => "Медицинская сестра",
        EmployeeCategory.Driver => "Водитель",
        EmployeeCategory.Dispatcher => "Диспетчер",
        _ => "Не указана"
    };
}
