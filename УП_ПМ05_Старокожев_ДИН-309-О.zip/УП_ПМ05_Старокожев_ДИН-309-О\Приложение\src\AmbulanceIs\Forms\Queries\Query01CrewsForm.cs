﻿using AmbulanceIs.Common;
using AmbulanceIs.Domain;
using AmbulanceIs.Forms.Base;
using AmbulanceIs.Services;

namespace AmbulanceIs.Forms.Queries;

/// <summary>Запрос 1: перечень и общее число бригад указанного типа для подстанции или всей службы.</summary>
public class Query01CrewsForm : QueryFormBase
{
    private readonly FilterCombo _typeCombo = new();
    private readonly FilterCombo _stationCombo = new();

    public Query01CrewsForm(DataStore store)
        : base(store, "Бригады подстанций",
            "Перечень и общее число бригад указанного типа для конкретной подстанции либо для всех подстанций города")
    {
        _typeCombo.Fill([(null, "Все типы"), (0, "Фельдшерская"), (1, "Врачебная")]);
        _stationCombo.Fill(StationOptions());
    }

    protected override void BuildFilters(FlowLayoutPanel host)
    {
        AddFilter(host, "Тип бригады", _typeCombo);
        AddFilter(host, "Подстанция", _stationCombo, 260);
    }

    protected override QueryResult Execute()
    {
        CrewType? type = _typeCombo.SelectedValue is int value ? (CrewType)value : null;
        return Service.GetCrews(type, _stationCombo.SelectedValue);
    }
}
