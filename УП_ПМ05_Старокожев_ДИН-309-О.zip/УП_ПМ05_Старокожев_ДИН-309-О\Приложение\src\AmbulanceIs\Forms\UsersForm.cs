﻿using AmbulanceIs.Common;
using AmbulanceIs.Domain;
using AmbulanceIs.Services;

namespace AmbulanceIs.Forms;

/// <summary>Окно администратора: управление учётными записями и снятие блокировки.</summary>
public class UsersForm : Form
{
    private readonly UserRepository _repository;
    private readonly DataGridView _grid = new();
    private readonly ToolStripStatusLabel _statusLabel;

    public UsersForm(UserRepository repository)
    {
        _repository = repository;

        Text = "Управление пользователями";
        StartPosition = FormStartPosition.CenterParent;
        MinimumSize = new Size(820, 480);
        ClientSize = new Size(880, 520);
        BackColor = AppTheme.Surface;
        Font = AppTheme.Body();

        var header = new Forms.Base.PageHeaderPanel("Пользователи системы",
            "Добавление учётных записей, изменение данных и снятие блокировки после неудачных попыток входа");

        var toolStrip = new ToolStrip
        {
            GripStyle = ToolStripGripStyle.Hidden,
            BackColor = Color.White,
            Padding = new Padding(12, 4, 12, 4),
            Height = 42
        };

        var addButton = new ToolStripButton("Добавить пользователя") { DisplayStyle = ToolStripItemDisplayStyle.Text };
        addButton.Click += (_, _) => AddUser();
        var editButton = new ToolStripButton("Изменить") { DisplayStyle = ToolStripItemDisplayStyle.Text };
        editButton.Click += (_, _) => EditUser();
        var unblockButton = new ToolStripButton("Снять блокировку") { DisplayStyle = ToolStripItemDisplayStyle.Text };
        unblockButton.Click += (_, _) => Unblock();
        var deleteButton = new ToolStripButton("Удалить") { DisplayStyle = ToolStripItemDisplayStyle.Text };
        deleteButton.Click += (_, _) => DeleteUser();
        var refreshButton = new ToolStripButton("Обновить") { DisplayStyle = ToolStripItemDisplayStyle.Text };
        refreshButton.Click += (_, _) => Reload();

        var toolTip = new ToolTip { AutoPopDelay = 9000, InitialDelay = 400, ShowAlways = true };
        addButton.ToolTipText = "Создать учётную запись: логин, ФИО, пароль и роль";
        editButton.ToolTipText = "Изменить данные пользователя или сменить пароль";
        unblockButton.ToolTipText = "Снять блокировку после трёх неудачных попыток входа";
        deleteButton.ToolTipText = "Удалить учётную запись";
        refreshButton.ToolTipText = "Перечитать список учётных записей";
        toolTip.SetToolTip(_grid, "Двойной щелчок по строке открывает пользователя для изменения");

        toolStrip.Items.AddRange(new ToolStripItem[]
        {
            addButton, editButton, unblockButton, deleteButton, new ToolStripSeparator(), refreshButton
        });

        AppTheme.StyleGrid(_grid);
        _grid.Dock = DockStyle.Fill;
        _grid.AutoGenerateColumns = false;
        _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Логин", DataPropertyName = nameof(UserAccount.Login), FillWeight = 90 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "ФИО", DataPropertyName = nameof(UserAccount.FullName), FillWeight = 220 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Роль", DataPropertyName = nameof(UserAccount.RoleName), FillWeight = 120 });
        _grid.Columns.Add(new DataGridViewCheckBoxColumn { HeaderText = "Заблокирован", DataPropertyName = nameof(UserAccount.IsBlocked), FillWeight = 90 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Неудачных попыток", DataPropertyName = nameof(UserAccount.FailedAttempts), FillWeight = 100 });
        _grid.CellDoubleClick += (_, e) => { if (e.RowIndex >= 0) EditUser(); };

        var gridHost = new Panel { Dock = DockStyle.Fill, Padding = new Padding(16, 10, 16, 10) };
        gridHost.Controls.Add(_grid);

        var statusStrip = new StatusStrip { BackColor = Color.White, SizingGrip = false };
        _statusLabel = new ToolStripStatusLabel { Spring = true, TextAlign = ContentAlignment.MiddleLeft };
        statusStrip.Items.Add(_statusLabel);

        Controls.Add(gridHost);
        Controls.Add(toolStrip);
        Controls.Add(header);
        Controls.Add(statusStrip);

        Load += (_, _) => Reload();
    }

    private void Reload()
    {
        _grid.DataSource = null;
        _grid.DataSource = _repository.Accounts.ToList();
        _statusLabel.Text = $"Учётных записей: {_repository.Accounts.Count}";
    }

    private void AddUser()
    {
        using var dialog = new UserEditForm(_repository, null, isNew: true);
        if (dialog.ShowDialog(this) == DialogResult.OK)
        {
            Reload();
            Messages.ShowInfo(this, $"Пользователь «{dialog.ResultLogin}» добавлен.", "Пользователь добавлен");
        }
    }

    private void EditUser()
    {
        if (_grid.CurrentRow?.DataBoundItem is not UserAccount account)
        {
            Messages.ShowWarning(this, "Выберите пользователя в таблице.", "Запись не выбрана");
            return;
        }

        using var dialog = new UserEditForm(_repository, account, isNew: false);
        if (dialog.ShowDialog(this) == DialogResult.OK)
        {
            Reload();
            Messages.ShowInfo(this, "Данные пользователя изменены.", "Данные сохранены");
        }
    }

    private void Unblock()
    {
        if (_grid.CurrentRow?.DataBoundItem is not UserAccount account)
        {
            Messages.ShowWarning(this, "Выберите пользователя в таблице.", "Запись не выбрана");
            return;
        }

        if (!account.IsBlocked)
        {
            Messages.ShowInfo(this, $"Учётная запись «{account.Login}» не заблокирована. Снятие блокировки не требуется.", "Действие не выполнено");
            return;
        }

        account.IsBlocked = false;
        account.FailedAttempts = 0;
        Reload();
        Messages.ShowInfo(this, $"Блокировка учётной записи «{account.Login}» снята. Пользователь может войти в систему.", "Блокировка снята");
    }

    private void DeleteUser()
    {
        if (_grid.CurrentRow?.DataBoundItem is not UserAccount account)
        {
            Messages.ShowWarning(this, "Выберите пользователя в таблице.", "Запись не выбрана");
            return;
        }

        if (account == Session.CurrentUser)
        {
            Messages.ShowError(this, "Нельзя удалить учётную запись, под которой выполнен вход в систему.", "Действие запрещено");
            return;
        }

        if (!Messages.Confirm(this, $"Удалить учётную запись «{account.Login}»?", "Удаление пользователя"))
        {
            return;
        }

        _repository.Remove(account);
        Reload();
    }
}
