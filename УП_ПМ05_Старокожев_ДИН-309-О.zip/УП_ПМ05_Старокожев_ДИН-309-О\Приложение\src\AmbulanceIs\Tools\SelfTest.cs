﻿using AmbulanceIs.Common;
using AmbulanceIs.Controls;
using AmbulanceIs.Domain;
using AmbulanceIs.Services;

namespace AmbulanceIs.Tools;

/// <summary>Автоматическая проверка ключевых сценариев работы приложения без участия пользователя.</summary>
public static class SelfTest
{
    private static int _failed;

    public static int Run()
    {
        Console.OutputEncoding = System.Text.Encoding.UTF8;
        Console.WriteLine("=== Автоматическая проверка АИС «Скорая помощь» ===");
        Console.WriteLine();

        CheckAuthentication();
        CheckBlocking();
        CheckValidation();
        CheckCaptcha();
        CheckReferenceEditing();
        CheckPersistence();
        CheckQueries();

        Console.WriteLine();
        Console.WriteLine(_failed == 0 ? "ИТОГ: все проверки пройдены." : $"ИТОГ: проверок с ошибкой — {_failed}.");
        return _failed == 0 ? 0 : 1;
    }

    private static void Check(string name, bool condition, string details = "")
    {
        if (condition)
        {
            Console.WriteLine($"  [OK]   {name} {details}");
            return;
        }

        _failed++;
        Console.WriteLine($"  [FAIL] {name} {details}");
    }

    private static void CheckAuthentication()
    {
        Console.WriteLine("1. Авторизация");
        var repository = new UserRepository();
        var service = new AuthenticationService(repository);

        var unknown = service.Authenticate("unknown", "123");
        Check("Неизвестный логин отклоняется", unknown.Status == AuthenticationStatus.InvalidCredentials);
        Check("Текст ошибки соответствует заданию", unknown.Message == Messages.AuthorizationFailed, $"«{unknown.Message}»");

        var empty = service.Authenticate("", "");
        Check("Пустые поля отклоняются", empty.Status == AuthenticationStatus.EmptyCredentials);

        var admin = service.Authenticate("admin", "Admin2026");
        Check("Администратор входит без капчи", admin.Status == AuthenticationStatus.Success &&
                                                 admin.Account?.Role == UserRole.Administrator);

        var dispatcher = service.Authenticate("dispatcher", "Disp2026");
        Check("Пользователю требуется капча", dispatcher.Status == AuthenticationStatus.CaptchaRequired);

        var wrong = service.Authenticate("dispatcher", "wrong");
        Check("Неверный пароль отклоняется", wrong.Status == AuthenticationStatus.InvalidCredentials);
        repository.Find("dispatcher")!.FailedAttempts = 0;
        Console.WriteLine();
    }

    private static void CheckBlocking()
    {
        Console.WriteLine("2. Блокировка после трёх неудачных попыток");
        var repository = new UserRepository();
        var service = new AuthenticationService(repository);
        var account = repository.Find("feldsher")!;

        var first = service.Authenticate("feldsher", "bad");
        Check("Первая ошибка — счётчик 1", first.Status == AuthenticationStatus.InvalidCredentials && account.FailedAttempts == 1);
        var second = service.Authenticate("feldsher", "bad");
        Check("Вторая ошибка — счётчик 2", second.Status == AuthenticationStatus.InvalidCredentials && account.FailedAttempts == 2);
        var third = service.Authenticate("feldsher", "bad");
        Check("Третья ошибка блокирует учётную запись", third.Status == AuthenticationStatus.Blocked && account.IsBlocked);
        Check("Текст блокировки соответствует заданию", third.Message == Messages.AccountBlocked, $"«{third.Message}»");

        var afterBlock = service.Authenticate("feldsher", "Feld2026");
        Check("Заблокированная запись не пускает даже с верным паролем", afterBlock.Status == AuthenticationStatus.Blocked);

        account.IsBlocked = false;
        account.FailedAttempts = 0;
        var unblocked = service.Authenticate("feldsher", "Feld2026");
        Check("После снятия блокировки вход выполняется", unblocked.Status == AuthenticationStatus.CaptchaRequired);
        Console.WriteLine();
    }

    private static void CheckValidation()
    {
        Console.WriteLine("3. Проверка ввода");
        Check("Госномер с недопустимыми символами отклоняется",
            !InputValidator.TryParsePlateNumber("А12-ВС", out _, out _));
        Check("Корректный госномер принимается",
            InputValidator.TryParsePlateNumber("а123вс55", out var plate, out _) && plate == "А123ВС55");
        Check("Год выпуска 2035 отклоняется", !InputValidator.TryParseYear("2035", "Год выпуска", out _, out _));
        Check("Отрицательный пробег отклоняется", !InputValidator.TryParsePositiveInt("-5", "Пробег", out _, out _));
        Check("Период с началом позже окончания отклоняется",
            !InputValidator.TryParsePeriod(new DateTime(2026, 11, 10), new DateTime(2026, 11, 1), out _));
        Console.WriteLine();
    }

    private static void CheckCaptcha()
    {
        Console.WriteLine("4. Капча-пазл");
        using var control = new CaptchaPuzzleControl();
        Check("Изначально пазл не собран", !control.IsSolved);
        control.SolveAutomatically();
        Check("После правильной сборки пазл считается собранным", control.IsSolved);
        control.Reset();
        Check("После перемешивания пазл снова не собран", !control.IsSolved);
        Console.WriteLine();
    }

    private static void CheckReferenceEditing()
    {
        Console.WriteLine("5. Ведение справочников");
        var store = new DataStore();
        using var form = new Forms.References.SubstationForm(store);
        var before = form.ItemCount;

        var added = new Domain.Substation
        {
            Id = 99,
            Number = "9",
            District = "Тестовый район",
            Address = "ул. Тестовая, 1",
            Phone = "00-00-00"
        };

        var previousFolder = StoreFile.Folder;
        var temporaryFolder = Path.Combine(Path.GetTempPath(), "ambulance-ref-" + Guid.NewGuid().ToString("N"));
        StoreFile.Folder = temporaryFolder;
        try
        {
            form.TestAdd(added);
            Check("Добавленная запись сохраняется в справочнике",
                store.Substations.Contains(added) && form.ItemCount == before + 1,
                $"записей: {form.ItemCount}");

            var fromDisk = StoreFile.Load();
            Check("Добавленная запись записывается в файл данных",
                File.Exists(StoreFile.FilePath) && fromDisk.Substations.Any(item => item.Number == "9"),
                $"файл: {Path.GetFileName(StoreFile.FilePath)}");

            // проверка сохранения по формам, о которых спрашивают чаще всего: врач, автомобиль, пациент
            using (var employeeForm = new Forms.References.EmployeeForm(store))
            {
                employeeForm.TestAdd(new Employee
                {
                    Id = 500,
                    FullName = "Сохранённый Врач Тестович",
                    Category = EmployeeCategory.Doctor,
                    Specialization = DoctorSpecialization.Cardiologist,
                    ExperienceYears = 12,
                    SubstationId = 1
                });
            }

            using (var vehicleForm = new Forms.References.VehicleForm(store))
            {
                vehicleForm.TestAdd(new Vehicle
                {
                    Id = 500,
                    Brand = "TestLine",
                    PlateNumber = "Х999ХХ55",
                    ManufactureYear = 2024,
                    Type = VehicleType.Linear,
                    SubstationId = 1,
                    MileageKm = 12000
                });
            }

            using (var patientForm = new Forms.References.PatientForm(store))
            {
                patientForm.TestAdd(new Patient
                {
                    Id = 500,
                    FullName = "Пациентов Иван Тестович",
                    Sex = Sex.Male,
                    Age = 40,
                    District = "Центральный",
                    PolicyNumber = "0000 0000 0000 0000"
                });
            }

            var afterForms = StoreFile.Load();
            Check("Добавленные врач, автомобиль и пациент сохраняются в файле",
                afterForms.Employees.Any(item => item.FullName == "Сохранённый Врач Тестович") &&
                afterForms.Vehicles.Any(item => item.Brand == "TestLine") &&
                afterForms.Patients.Any(item => item.FullName == "Пациентов Иван Тестович"),
                $"сотрудников: {afterForms.Employees.Count}, автомобилей: {afterForms.Vehicles.Count}, пациентов: {afterForms.Patients.Count}");

            form.TestRemove(added);
            Check("Удалённая запись убирается из справочника",
                !store.Substations.Contains(added) && form.ItemCount == before,
                $"записей: {form.ItemCount}");
        }
        finally
        {
            StoreFile.Folder = previousFolder;
            try
            {
                if (Directory.Exists(temporaryFolder))
                {
                    Directory.Delete(temporaryFolder, true);
                }
            }
            catch (IOException)
            {
                // временная папка будет удалена системой
            }
        }

        Console.WriteLine();
    }

    private static void CheckPersistence()
    {
        Console.WriteLine("6. Сохранение данных в файл");

        var store = new DataStore();
        store.Substations.Add(new Substation { Id = 1, Number = "7", District = "Тестовый" });
        store.Employees.Add(new Employee
        {
            Id = 1,
            FullName = "Тестовый Врач",
            Category = EmployeeCategory.Doctor,
            Specialization = DoctorSpecialization.Cardiologist,
            ExperienceYears = 5,
            SubstationId = 1
        });

        var json = StoreFile.ToJson(store);
        var restored = StoreFile.FromJson(json);
        Check("Набор данных восстанавливается из JSON",
            restored.Employees.Count == 1 && restored.Employees[0].FullName == "Тестовый Врач" &&
            restored.Employees[0].Specialization == DoctorSpecialization.Cardiologist,
            $"записей: {restored.Employees.Count}");
        Check("Перечисления сохраняются по имени", json.Contains("\"Cardiologist\""));

        var previousFolder = StoreFile.Folder;
        var temporaryFolder = Path.Combine(Path.GetTempPath(), "ambulance-selftest-" + Guid.NewGuid().ToString("N"));
        StoreFile.Folder = temporaryFolder;
        try
        {
            StoreFile.AutoSave = true;
            StoreFile.Save(store);
            var loaded = StoreFile.Load();
            Check("Файл данных создаётся и читается при следующем запуске",
                File.Exists(StoreFile.FilePath) && loaded.Substations.Count == 1 && loaded.Employees.Count == 1,
                $"файл: {Path.GetFileName(StoreFile.FilePath)}");
        }
        finally
        {
            StoreFile.Folder = previousFolder;
            StoreFile.AutoSave = true;
            try
            {
                if (Directory.Exists(temporaryFolder))
                {
                    Directory.Delete(temporaryFolder, true);
                }
            }
            catch (IOException)
            {
                // временная папка будет удалена системой
            }
        }

        Console.WriteLine();
    }

    private static void CheckQueries()
    {
        Console.WriteLine("7. Запросы информационной системы (демонстрационный набор данных)");
        var store = DemoDataProvider.Create();
        var service = new QueryService(store);
        var from = new DateTime(2026, 10, 5);
        var to = new DateTime(2026, 11, 18);

        var crews = service.GetCrews(CrewType.Medical, null);
        Check("Запрос 1: врачебные бригады", crews.Rows.Count == store.Crews.Count(crew => crew.Type == CrewType.Medical), crews.Summary);

        var employees = service.GetEmployees(EmployeeCategory.Doctor, 1);
        Check("Запрос 2: врачи подстанции №1", employees.Rows.Count > 0, employees.Summary);

        var composition = service.GetCrewComposition(2, new DateTime(2026, 11, 1));
        Check("Запрос 3: состав бригады", composition.Rows.Count == 3, composition.Summary);

        var calls = service.GetCalls(from, to, null, null);
        Check("Запрос 4: вызовы за период", calls.Rows.Count > 30, calls.Summary);

        var arrival = service.GetAverageArrival(from, to, null, null);
        Check("Запрос 5: среднее время прибытия", arrival.Rows.Count > 0, arrival.Summary);

        var workload = service.GetWorkload(from, to, EmployeeCategory.Doctor, null);
        Check("Запрос 6: выработка врачей", workload.Rows.Count > 0, workload.Summary);

        var load = service.GetSubstationLoad(null);
        Check("Запрос 7: загрузка подстанций", load.Rows.Count == 4, load.Summary);

        var served = service.GetServedPatients(from, to, 1, null);
        Check("Запрос 8: пациенты бригады", served.Rows.Count > 0, served.Summary);

        var history = service.GetPatientHistory(1);
        var patientCalls = store.Calls.Where(call => call.PatientId == 1).ToList();
        Check("Запрос 9: история пациента — все обращения в выборке",
            history.Rows.Count == patientCalls.Count, history.Summary);
        Check("История пациента заполнена полностью и упорядочена по дате",
            history.Rows.All(row => !string.IsNullOrWhiteSpace(row["Reason"]?.ToString()) &&
                                    !string.IsNullOrWhiteSpace(row["Crew"]?.ToString()) &&
                                    !string.IsNullOrWhiteSpace(row["Doctor"]?.ToString()) &&
                                    !string.IsNullOrWhiteSpace(row["Result"]?.ToString())) &&
            history.Rows[0]["Date"]?.ToString()!.StartsWith(patientCalls.Min(call => call.ReceivedAt).ToString("dd.MM.yyyy")) == true &&
            history.Rows[^1]["Date"]?.ToString()!.StartsWith(patientCalls.Max(call => call.ReceivedAt).ToString("dd.MM.yyyy")) == true,
            $"строк: {history.Rows.Count}");

        var hospital = service.GetHospitalizations(from, to);
        Check("Запрос 10: госпитализации", hospital.Rows.Count > 0, hospital.Summary);

        var late = service.GetLateCalls(from, to, null, null);
        Check("Запрос 11: задержки прибытия", late.Rows.Count > 0, late.Summary);

        var fleet = service.GetFleet(null, null, null);
        Check("Запрос 12: автопарк", fleet.Rows.Count == store.Vehicles.Count, fleet.Summary);

        var empty = new QueryService(new DataStore());
        var emptyResult = empty.GetCalls(from, to, null, null);
        Check("Пустое хранилище возвращает пустой результат", emptyResult.IsEmpty, emptyResult.Summary);
    }
}
