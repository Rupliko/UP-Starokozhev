﻿using AmbulanceIs.Domain;

namespace AmbulanceIs.Services;

/// <summary>Набор справочников и документов, с которым работают окна приложения.</summary>
public class DataStore
{
    public List<Substation> Substations { get; set; } = new();

    public List<Employee> Employees { get; set; } = new();

    public List<Vehicle> Vehicles { get; set; } = new();

    public List<Crew> Crews { get; set; } = new();

    public List<CrewMember> CrewMembers { get; set; } = new();

    public List<Patient> Patients { get; set; } = new();

    public List<Call> Calls { get; set; } = new();

    public List<Hospital> Hospitals { get; set; } = new();

    /// <summary>Признак того, что набор сформирован из демонстрационных данных.</summary>
    public bool IsDemo { get; set; }

    private static DataStore? _demo;

    /// <summary>Демонстрационный набор данных создаётся один раз при первом обращении.</summary>
    public static DataStore Demo => _demo ??= DemoDataProvider.Create();

    /// <summary>Формирует демонстрационный набор заново (возврат к тестовым данным).</summary>
    public static DataStore ResetDemo()
    {
        _demo = DemoDataProvider.Create();
        return _demo;
    }

    /// <summary>Принудительная инициализация демонстрационного набора (используется при формировании отчёта).</summary>
    public static void Initialize() => _ = Demo;
}
