﻿using AmbulanceIs.Common;
using AmbulanceIs.Domain;
using AmbulanceIs.Services;

namespace AmbulanceIs.Forms;

/// <summary>Диалоговое окно создания и редактирования учётной записи.</summary>
public class UserEditForm : Form
{
    private readonly UserRepository _repository;
    private readonly UserAccount? _account;
    private readonly bool _isNew;

    private readonly TextBox _loginBox = AppTheme.CreateTextBox(320);
    private readonly TextBox _fullNameBox = AppTheme.CreateTextBox(320);
    private readonly TextBox _passwordBox = AppTheme.CreateTextBox(320);
    private readonly ComboBox _roleBox = AppTheme.CreateComboBox(320);
    private readonly CheckBox _blockedBox = new() { Text = "Заблокировать учётную запись", AutoSize = true, Font = AppTheme.Body(9.5F) };

    public UserEditForm(UserRepository repository, UserAccount? account, bool isNew)
    {
        _repository = repository;
        _account = account;
        _isNew = isNew;

        Text = isNew ? "Новый пользователь" : "Изменение пользователя";
        FormBorderStyle = FormBorderStyle.FixedDialog;
        StartPosition = FormStartPosition.CenterParent;
        MaximizeBox = false;
        MinimizeBox = false;
        ClientSize = new Size(520, 430);
        BackColor = Color.White;
        Font = AppTheme.Body();

        var title = new Label
        {
            Text = isNew ? "Добавление пользователя" : "Данные пользователя",
            Dock = DockStyle.Top,
            Height = 54,
            Padding = new Padding(24, 20, 0, 0),
            Font = AppTheme.Heading(13F),
            ForeColor = AppTheme.TextPrimary
        };

        var layout = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            Padding = new Padding(24, 8, 24, 8),
            AutoScroll = true
        };

        _roleBox.Items.AddRange(["Администратор", "Пользователь"]);
        _roleBox.SelectedIndex = 1;

        layout.Controls.Add(AppTheme.CreateFieldLabel("Логин *"));
        layout.Controls.Add(_loginBox);
        layout.Controls.Add(AppTheme.CreateFieldLabel("ФИО сотрудника *"));
        layout.Controls.Add(_fullNameBox);
        layout.Controls.Add(AppTheme.CreateFieldLabel("Пароль *"));
        layout.Controls.Add(_passwordBox);
        layout.Controls.Add(AppTheme.CreateFieldLabel("Роль *"));
        layout.Controls.Add(_roleBox);
        layout.Controls.Add(_blockedBox);

        var saveButton = AppTheme.CreatePrimaryButton("Сохранить", 140);
        saveButton.Click += (_, _) => Save();
        var cancelButton = AppTheme.CreateSecondaryButton("Отмена", 110);
        cancelButton.Click += (_, _) => { DialogResult = DialogResult.Cancel; Close(); };

        var buttons = new FlowLayoutPanel
        {
            Dock = DockStyle.Bottom,
            Height = 62,
            Padding = new Padding(24, 12, 0, 0),
            FlowDirection = FlowDirection.LeftToRight
        };
        buttons.Controls.Add(saveButton);
        buttons.Controls.Add(cancelButton);

        Controls.Add(layout);
        Controls.Add(title);
        Controls.Add(buttons);

        AcceptButton = saveButton;
        CancelButton = cancelButton;

        if (account is not null)
        {
            _loginBox.Text = account.Login;
            _fullNameBox.Text = account.FullName;
            _passwordBox.Text = account.Password;
            _roleBox.SelectedIndex = (int)account.Role;
            _blockedBox.Checked = account.IsBlocked;
        }
    }

    public string ResultLogin { get; private set; } = string.Empty;

    private void Save()
    {
        var login = _loginBox.Text.Trim();
        if (login.Length < 3)
        {
            Messages.ShowError(this, "Поле «Логин» должно содержать не менее 3 символов.", "Некорректные данные");
            _loginBox.Focus();
            return;
        }

        if (_repository.LoginExists(login, _account))
        {
            Messages.ShowError(this,
                $"Пользователь с логином «{login}» уже существует в системе. Укажите другой логин.",
                "Пользователь уже существует");
            _loginBox.Focus();
            return;
        }

        if (!InputValidator.TryParseFullName(_fullNameBox.Text, out var fullName, out var nameError))
        {
            Messages.ShowError(this, nameError, "Некорректные данные");
            _fullNameBox.Focus();
            return;
        }

        if (_passwordBox.Text.Length < 5)
        {
            Messages.ShowError(this, "Пароль должен содержать не менее 5 символов.", "Некорректные данные");
            _passwordBox.Focus();
            return;
        }

        if (_roleBox.SelectedIndex < 0)
        {
            Messages.ShowError(this, "Выберите роль пользователя.", "Некорректные данные");
            return;
        }

        if (_isNew)
        {
            _repository.Add(new UserAccount
            {
                Login = login,
                FullName = fullName,
                Password = _passwordBox.Text,
                Role = (UserRole)_roleBox.SelectedIndex,
                IsBlocked = _blockedBox.Checked
            });
        }
        else if (_account is not null)
        {
            _account.Login = login;
            _account.FullName = fullName;
            _account.Password = _passwordBox.Text;
            _account.Role = (UserRole)_roleBox.SelectedIndex;
            _account.IsBlocked = _blockedBox.Checked;
            if (!_account.IsBlocked)
            {
                _account.FailedAttempts = 0;
            }
        }

        ResultLogin = login;
        DialogResult = DialogResult.OK;
        Close();
    }
}
