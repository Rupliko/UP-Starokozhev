﻿using System.Globalization;
using AmbulanceIs.Domain;

namespace AmbulanceIs.Services;

/// <summary>Реализация запросов информационной системы службы скорой помощи.</summary>
public class QueryService
{
    private readonly DataStore _store;

    public QueryService(DataStore store)
    {
        _store = store;
    }

    private static string FormatDate(DateTime value) => value.ToString("dd.MM.yyyy", CultureInfo.CurrentCulture);

    private static string FormatTime(DateTime value) => value.ToString("HH:mm", CultureInfo.CurrentCulture);

    private string SubstationName(int id) =>
        _store.Substations.FirstOrDefault(item => item.Id == id)?.ToString() ?? "—";

    private string EmployeeName(int? id) =>
        id is null ? "—" : _store.Employees.FirstOrDefault(item => item.Id == id)?.FullName ?? "—";

    private string CrewName(int? id) =>
        id is null ? "—" : _store.Crews.FirstOrDefault(item => item.Id == id)?.ToString() ?? "—";

    private string PatientName(int id) =>
        _store.Patients.FirstOrDefault(item => item.Id == id)?.FullName ?? "—";

    private string HospitalName(int? id) =>
        id is null ? "—" : _store.Hospitals.FirstOrDefault(item => item.Id == id)?.Name ?? "—";

    private string VehicleName(int? id)
    {
        var vehicle = id is null ? null : _store.Vehicles.FirstOrDefault(item => item.Id == id);
        return vehicle is null ? "не закреплён" : $"{vehicle.Brand} {vehicle.PlateNumber}";
    }

    /// <summary>Запрос 1. Перечень и общее число бригад указанного типа для подстанции либо всей службы.</summary>
    public QueryResult GetCrews(CrewType? type, int? substationId)
    {
        var query = _store.Crews.AsEnumerable();
        if (type is not null)
        {
            query = query.Where(crew => crew.Type == type);
        }

        if (substationId is not null)
        {
            query = query.Where(crew => crew.SubstationId == substationId);
        }

        var crews = query.OrderBy(crew => crew.SubstationId).ThenBy(crew => crew.Number).ToList();
        var result = new QueryResult();
        result.AddColumn("Номер бригады", "Number", 80)
            .AddColumn("Тип бригады", "Type", 110)
            .AddColumn("Подстанция", "Substation", 200)
            .AddColumn("Автомобиль", "Vehicle", 200)
            .AddColumn("Состояние", "State", 110);

        foreach (var crew in crews)
        {
            result.AddRow(
                ("Number", $"№{crew.Number}"),
                ("Type", crew.TypeName),
                ("Substation", SubstationName(crew.SubstationId)),
                ("Vehicle", VehicleName(crew.VehicleId)),
                ("State", crew.IsOnDuty ? "На дежурстве" : "Не дежурит"));
        }

        result.Summary = crews.Count == 0
            ? "Бригады, удовлетворяющие условиям поиска, не найдены."
            : $"Всего бригад: {crews.Count}. Из них на дежурстве: {crews.Count(crew => crew.IsOnDuty)}.";
        return result;
    }

    /// <summary>Запрос 2. Перечень и общее число сотрудников указанной категории.</summary>
    public QueryResult GetEmployees(EmployeeCategory? category, int? substationId)
    {
        var query = _store.Employees.AsEnumerable();
        if (category is not null)
        {
            query = query.Where(employee => employee.Category == category);
        }

        if (substationId is not null)
        {
            query = query.Where(employee => employee.SubstationId == substationId);
        }

        var employees = query.OrderBy(employee => employee.FullName).ToList();
        var result = new QueryResult();
        result.AddColumn("ФИО сотрудника", "Name", 260)
            .AddColumn("Категория", "Category", 150)
            .AddColumn("Специализация", "Specialization", 140)
            .AddColumn("Стаж, лет", "Experience", 90)
            .AddColumn("Подстанция", "Substation", 200);

        foreach (var employee in employees)
        {
            result.AddRow(
                ("Name", employee.FullName),
                ("Category", employee.CategoryName),
                ("Specialization", employee.SpecializationName),
                ("Experience", employee.ExperienceYears),
                ("Substation", SubstationName(employee.SubstationId)));
        }

        result.Summary = employees.Count == 0
            ? "Сотрудники, удовлетворяющие условиям поиска, не найдены."
            : $"Всего сотрудников: {employees.Count}. Средний стаж: {employees.Average(employee => employee.ExperienceYears):F1} года.";
        return result;
    }

    /// <summary>Запрос 3. Состав указанной бригады на указанную дату.</summary>
    public QueryResult GetCrewComposition(int crewId, DateTime date)
    {
        var crew = _store.Crews.FirstOrDefault(item => item.Id == crewId);
        var result = new QueryResult();
        result.AddColumn("Сотрудник", "Name", 260)
            .AddColumn("Категория", "Category", 150)
            .AddColumn("Роль в бригаде", "Role", 170)
            .AddColumn("Стаж, лет", "Experience", 90)
            .AddColumn("В составе с", "From", 110);

        if (crew is null)
        {
            result.Summary = "Бригада не выбрана.";
            return result;
        }

        var members = _store.CrewMembers
            .Where(member => member.CrewId == crewId && member.IsActiveOn(date))
            .Join(_store.Employees, member => member.EmployeeId, employee => employee.Id, (member, employee) => new { member, employee })
            .OrderBy(item => item.member.RoleInCrew)
            .ToList();

        foreach (var item in members)
        {
            result.AddRow(
                ("Name", item.employee.FullName),
                ("Category", item.employee.CategoryName),
                ("Role", item.member.RoleInCrew),
                ("Experience", item.employee.ExperienceYears),
                ("From", FormatDate(item.member.DateFrom)));
        }

        result.Summary = members.Count == 0
            ? $"На {FormatDate(date)} состав бригады №{crew.Number} не определён."
            : $"Состав {crew} на {FormatDate(date)}: {members.Count} чел.";
        return result;
    }

    /// <summary>Запрос 4. Перечень и общее число вызовов за период с разбивкой по категориям срочности.</summary>
    public QueryResult GetCalls(DateTime from, DateTime to, int? crewId, int? substationId)
    {
        var calls = FilterCalls(from, to, crewId, substationId).ToList();
        var result = new QueryResult();
        result.AddColumn("Номер вызова", "Number", 100)
            .AddColumn("Дата и время поступления", "Received", 160)
            .AddColumn("Бригада", "Crew", 190)
            .AddColumn("Срочность", "Urgency", 110)
            .AddColumn("Диагноз", "Diagnosis", 180)
            .AddColumn("Результат", "Result", 160);

        foreach (var call in calls.OrderBy(item => item.ReceivedAt))
        {
            result.AddRow(
                ("Number", call.Number),
                ("Received", $"{FormatDate(call.ReceivedAt)} {FormatTime(call.ReceivedAt)}"),
                ("Crew", CrewName(call.CrewId)),
                ("Urgency", call.Urgency.ToRussian()),
                ("Diagnosis", call.Diagnosis),
                ("Result", call.Result?.ToRussian() ?? call.Status.ToRussian()));
        }

        var emergency = calls.Count(call => call.Urgency == UrgencyCategory.Emergency);
        var urgent = calls.Count - emergency;
        result.Summary = calls.Count == 0
            ? "За указанный период вызовы не зарегистрированы."
            : $"Всего вызовов: {calls.Count}, в том числе экстренных: {emergency}, неотложных: {urgent}.";
        return result;
    }

    /// <summary>Запрос 5. Среднее время прибытия бригады на вызов за период.</summary>
    public QueryResult GetAverageArrival(DateTime from, DateTime to, int? crewId, int? substationId)
    {
        var calls = FilterCalls(from, to, crewId, substationId)
            .Where(call => call.ArrivalAt is not null)
            .ToList();

        var result = new QueryResult();
        result.AddColumn("Бригада", "Crew", 170)
            .AddColumn("Вызовов", "Calls", 90)
            .AddColumn("Среднее прибытие, мин", "Average", 150)
            .AddColumn("Норматив, мин", "Norm", 120)
            .AddColumn("Отклонение, мин", "Deviation", 130);

        var groups = calls
            .GroupBy(call => call.CrewId)
            .Select(group => new
            {
                CrewId = group.Key,
                Count = group.Count(),
                Average = group.Average(call => (call.ArrivalAt!.Value - call.ReceivedAt).TotalMinutes),
                Norm = group.Max(call => call.Urgency.NormativeArrivalMinutes())
            })
            .OrderBy(item => item.Average)
            .ToList();

        foreach (var group in groups)
        {
            result.AddRow(
                ("Crew", CrewName(group.CrewId)),
                ("Calls", group.Count),
                ("Average", group.Average.ToString("F1", CultureInfo.CurrentCulture)),
                ("Norm", group.Norm),
                ("Deviation", (group.Average - group.Norm).ToString("+0.0;-0.0;0.0", CultureInfo.CurrentCulture)));
        }

        if (calls.Count == 0)
        {
            result.Summary = "Нет вызовов с зафиксированным временем прибытия за указанный период.";
            return result;
        }

        var overall = calls.Average(call => (call.ArrivalAt!.Value - call.ReceivedAt).TotalMinutes);
        result.Summary = $"Среднее время прибытия по выборке: {overall:F1} мин при {calls.Count} вызовах.";
        return result;
    }

    /// <summary>Запрос 6. Выработка сотрудников: среднее число выездов в сутки за период.</summary>
    public QueryResult GetWorkload(DateTime from, DateTime to, EmployeeCategory category, int? employeeId)
    {
        var days = Math.Max(1, (to.Date - from.Date).Days + 1);
        var calls = FilterCalls(from, to, null, null).ToList();

        var employees = _store.Employees.Where(employee => employee.Category == category);
        if (employeeId is not null)
        {
            employees = employees.Where(employee => employee.Id == employeeId);
        }

        var result = new QueryResult();
        result.AddColumn("Сотрудник", "Name", 260)
            .AddColumn("Категория", "Category", 140)
            .AddColumn("Подстанция", "Substation", 190)
            .AddColumn("Выездов", "Trips", 90)
            .AddColumn("Выездов в сутки", "PerDay", 130);

        var rows = employees
            .Select(employee => new
            {
                Employee = employee,
                Trips = calls.Count(call => call.DoctorId == employee.Id)
            })
            .OrderByDescending(item => item.Trips)
            .ThenBy(item => item.Employee.FullName)
            .ToList();

        foreach (var row in rows)
        {
            result.AddRow(
                ("Name", row.Employee.FullName),
                ("Category", row.Employee.CategoryName),
                ("Substation", SubstationName(row.Employee.SubstationId)),
                ("Trips", row.Trips),
                ("PerDay", ((double)row.Trips / days).ToString("F2", CultureInfo.CurrentCulture)));
        }

        result.Summary = rows.Count == 0
            ? "Сотрудники указанной категории не найдены."
            : $"Период: {days} дн. Всего выездов: {rows.Sum(step => step.Trips)}. Средняя выработка: {(rows.Sum(step => step.Trips) / (double)days / rows.Count):F2} выезда в сутки на сотрудника.";
        return result;
    }

    /// <summary>Запрос 7. Загрузка подстанции на текущий момент.</summary>
    public QueryResult GetSubstationLoad(int? substationId)
    {
        var stations = _store.Substations.AsEnumerable();
        if (substationId is not null)
        {
            stations = stations.Where(station => station.Id == substationId);
        }

        var activeStatuses = new[] { CallStatus.Assigned, CallStatus.OnTheWay, CallStatus.InProgress };
        var result = new QueryResult();
        result.AddColumn("Подстанция", "Station", 220)
            .AddColumn("Бригад всего", "Total", 110)
            .AddColumn("На дежурстве", "OnDuty", 120)
            .AddColumn("Свободных", "Free", 110)
            .AddColumn("Выполняется вызовов", "Active", 140);

        var rows = new List<(string Station, int Total, int OnDuty, int Free, int Active)>();
        foreach (var station in stations)
        {
            var crews = _store.Crews.Where(crew => crew.SubstationId == station.Id).ToList();
            var onDuty = crews.Count(crew => crew.IsOnDuty);
            var busy = _store.Calls.Count(call => activeStatuses.Contains(call.Status) &&
                                                  crews.Any(crew => crew.Id == call.CrewId));
            rows.Add((station.ToString(), crews.Count, onDuty, Math.Max(0, onDuty - busy), busy));
        }

        foreach (var row in rows)
        {
            result.AddRow(
                ("Station", row.Station),
                ("Total", row.Total),
                ("OnDuty", row.OnDuty),
                ("Free", row.Free),
                ("Active", row.Active));
        }

        result.Summary = rows.Count == 0
            ? "Подстанции не найдены."
            : $"Подстанций: {rows.Count}. Дежурят бригад: {rows.Sum(row => row.OnDuty)}, свободны: {rows.Sum(row => row.Free)}, выполняют вызовы: {rows.Sum(row => row.Active)}.";
        return result;
    }

    /// <summary>Запрос 8. Пациенты, которым оказана помощь бригадой или врачом за период.</summary>
    public QueryResult GetServedPatients(DateTime from, DateTime to, int? crewId, int? doctorId)
    {
        var calls = FilterCalls(from, to, crewId, null)
            .Where(call => doctorId is null || call.DoctorId == doctorId)
            .Where(call => call.Result is not null)
            .ToList();

        var result = new QueryResult();
        result.AddColumn("Пациент", "Patient", 240)
            .AddColumn("Дата вызова", "Date", 110)
            .AddColumn("Диагноз", "Diagnosis", 230)
            .AddColumn("Результат", "Result", 170)
            .AddColumn("Больница", "Hospital", 190);

        foreach (var call in calls.OrderBy(call => call.ReceivedAt))
        {
            result.AddRow(
                ("Patient", PatientName(call.PatientId)),
                ("Date", FormatDate(call.ReceivedAt)),
                ("Diagnosis", call.Diagnosis),
                ("Result", call.Result!.Value.ToRussian()),
                ("Hospital", HospitalName(call.HospitalId)));
        }

        result.Summary = calls.Count == 0
            ? "За указанный период помощь не оказывалась."
            : $"Обслужено вызовов: {calls.Count}. Уникальных пациентов: {calls.Select(call => call.PatientId).Distinct().Count()}.";
        return result;
    }

    /// <summary>Запрос 9. Полная история обращений указанного пациента.</summary>
    public QueryResult GetPatientHistory(int patientId)
    {
        var result = new QueryResult();
        result.AddColumn("Дата и время", "Date", 150)
            .AddColumn("Повод к вызову", "Reason", 220)
            .AddColumn("Диагноз", "Diagnosis", 210)
            .AddColumn("Бригада", "Crew", 150)
            .AddColumn("Ответственный сотрудник", "Doctor", 210)
            .AddColumn("Результат", "Result", 160);

        var calls = _store.Calls.Where(call => call.PatientId == patientId).OrderBy(call => call.ReceivedAt).ToList();
        foreach (var call in calls)
        {
            result.AddRow(
                ("Date", $"{FormatDate(call.ReceivedAt)} {FormatTime(call.ReceivedAt)}"),
                ("Reason", call.Reason),
                ("Diagnosis", string.IsNullOrWhiteSpace(call.Diagnosis) ? "— (вызов не завершён)" : call.Diagnosis),
                ("Crew", CrewName(call.CrewId)),
                ("Doctor", EmployeeName(call.DoctorId)),
                ("Result", call.Result?.ToRussian() ?? call.Status.ToRussian()));
        }

        var patient = _store.Patients.FirstOrDefault(item => item.Id == patientId);
        result.Summary = calls.Count == 0
            ? "Обращения пациента не зарегистрированы."
            : $"Пациент: {patient?.FullName}. Обращений: {calls.Count}, последнее — {FormatDate(calls[^1].ReceivedAt)}.";
        return result;
    }

    /// <summary>Запрос 10. Вызовы с госпитализацией и число госпитализаций по каждой больнице.</summary>
    public QueryResult GetHospitalizations(DateTime from, DateTime to)
    {
        var calls = FilterCalls(from, to, null, null)
            .Where(call => call.Result == CallResult.Hospitalized)
            .ToList();

        var result = new QueryResult();
        result.AddColumn("Дата", "Date", 110)
            .AddColumn("Пациент", "Patient", 230)
            .AddColumn("Больница", "Hospital", 220)
            .AddColumn("Бригада", "Crew", 150)
            .AddColumn("Диагноз", "Diagnosis", 210);

        foreach (var call in calls.OrderBy(call => call.ReceivedAt))
        {
            result.AddRow(
                ("Date", FormatDate(call.ReceivedAt)),
                ("Patient", PatientName(call.PatientId)),
                ("Hospital", HospitalName(call.HospitalId)),
                ("Crew", CrewName(call.CrewId)),
                ("Diagnosis", call.Diagnosis));
        }

        var byHospital = calls
            .GroupBy(call => call.HospitalId)
            .Select(group => $"{HospitalName(group.Key)} — {group.Count()}")
            .ToList();

        result.Summary = calls.Count == 0
            ? "Госпитализаций за указанный период нет."
            : $"Всего госпитализаций: {calls.Count}. По больницам: {string.Join("; ", byHospital)}.";
        return result;
    }

    /// <summary>Запрос 11. Вызовы с прибытием бригады позже нормативного времени.</summary>
    public QueryResult GetLateCalls(DateTime from, DateTime to, int? crewId, int? substationId)
    {
        var calls = FilterCalls(from, to, crewId, substationId)
            .Where(call => call.IsLate)
            .OrderByDescending(call => call.ArrivalDelay!.Value.TotalMinutes)
            .ToList();

        var result = new QueryResult();
        result.AddColumn("Номер вызова", "Number", 100)
            .AddColumn("Дата", "Date", 110)
            .AddColumn("Бригада", "Crew", 160)
            .AddColumn("Поступление", "Received", 100)
            .AddColumn("Прибытие", "Arrival", 100)
            .AddColumn("Норматив, мин", "Norm", 120)
            .AddColumn("Задержка, мин", "Delay", 120);

        foreach (var call in calls)
        {
            result.AddRow(
                ("Number", call.Number),
                ("Date", FormatDate(call.ReceivedAt)),
                ("Crew", CrewName(call.CrewId)),
                ("Received", FormatTime(call.ReceivedAt)),
                ("Arrival", FormatTime(call.ArrivalAt!.Value)),
                ("Norm", call.Urgency.NormativeArrivalMinutes()),
                ("Delay", Math.Round(call.ArrivalDelay!.Value.TotalMinutes)));
        }

        result.Summary = calls.Count == 0
            ? "Вызовов с прибытием позже нормативного времени не зафиксировано."
            : $"Вызовов с задержкой: {calls.Count}. Максимальная задержка: {calls.Max(call => call.ArrivalDelay!.Value.TotalMinutes):F0} мин, средняя: {calls.Average(call => call.ArrivalDelay!.Value.TotalMinutes):F1} мин.";
        return result;
    }

    /// <summary>Запрос 12. Сведения об автопарке: распределение по подстанциям и типам, данные о пробеге.</summary>
    public QueryResult GetFleet(int? substationId, VehicleType? type, int? vehicleId)
    {
        var vehicles = _store.Vehicles.AsEnumerable();
        if (substationId is not null)
        {
            vehicles = vehicles.Where(vehicle => vehicle.SubstationId == substationId);
        }

        if (type is not null)
        {
            vehicles = vehicles.Where(vehicle => vehicle.Type == type);
        }

        if (vehicleId is not null)
        {
            vehicles = vehicles.Where(vehicle => vehicle.Id == vehicleId);
        }

        var list = vehicles.OrderBy(vehicle => vehicle.SubstationId).ThenBy(vehicle => vehicle.Brand).ToList();
        var result = new QueryResult();
        result.AddColumn("Подстанция", "Station", 220)
            .AddColumn("Тип", "Type", 120)
            .AddColumn("Марка", "Brand", 150)
            .AddColumn("Госномер", "Plate", 110)
            .AddColumn("Год выпуска", "Year", 100)
            .AddColumn("Пробег, км", "Mileage", 110)
            .AddColumn("Средний пробег в год, км", "Yearly", 170);

        foreach (var vehicle in list)
        {
            var age = Math.Max(1, DateTime.Today.Year - vehicle.ManufactureYear);
            result.AddRow(
                ("Station", SubstationName(vehicle.SubstationId)),
                ("Type", vehicle.TypeName),
                ("Brand", vehicle.Brand),
                ("Plate", vehicle.PlateNumber),
                ("Year", vehicle.ManufactureYear),
                ("Mileage", vehicle.MileageKm),
                ("Yearly", vehicle.MileageKm / age));
        }

        result.Summary = list.Count == 0
            ? "Автомобили, удовлетворяющие условиям поиска, не найдены."
            : $"Автомобилей: {list.Count}, из них реанимобилей: {list.Count(vehicle => vehicle.Type == VehicleType.Resuscitation)}, линейных: {list.Count(vehicle => vehicle.Type == VehicleType.Linear)}. Суммарный пробег: {list.Sum(vehicle => vehicle.MileageKm):N0} км.";
        return result;
    }

    private IEnumerable<Call> FilterCalls(DateTime from, DateTime to, int? crewId, int? substationId)
    {
        var query = _store.Calls.Where(call => call.ReceivedAt.Date >= from.Date && call.ReceivedAt.Date <= to.Date);
        if (crewId is not null)
        {
            query = query.Where(call => call.CrewId == crewId);
        }

        if (substationId is not null)
        {
            var crewIds = _store.Crews.Where(crew => crew.SubstationId == substationId).Select(crew => crew.Id).ToHashSet();
            query = query.Where(call => call.CrewId is not null && crewIds.Contains(call.CrewId.Value));
        }

        return query;
    }
}
