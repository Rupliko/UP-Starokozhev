﻿using System.ComponentModel;
using AmbulanceIs.Common;
using AmbulanceIs.Controls;
using AmbulanceIs.Domain;
using AmbulanceIs.Forms.Base;
using AmbulanceIs.Services;

namespace AmbulanceIs.Forms.Documents;

/// <summary>Окно регистрации и редактирования вызова — основного объекта учёта.</summary>
public class CallForm : Form
{
    private readonly DataStore _store;
    private readonly BindingList<Call> _calls = new();
    private readonly DataGridView _grid = new();
    private readonly TabControl _tabs = new();
    private readonly ToolStrip _toolStrip;
    private readonly ToolStripButton _saveButton;
    private readonly ToolStripButton _cancelButton;
    private readonly PlaceholderTextBox _searchBox;

    private readonly TextBox _numberBox = AppTheme.CreateTextBox();
    private readonly DateTimePicker _receivedDate = new() { Format = DateTimePickerFormat.Long, Width = 200 };
    private readonly DateTimePicker _receivedTime = new() { Format = DateTimePickerFormat.Time, ShowUpDown = true, Width = 100 };
    private readonly ComboBox _urgencyBox = AppTheme.CreateComboBox();
    private readonly TextBox _reasonBox = AppTheme.CreateTextBox();
    private readonly TextBox _districtBox = AppTheme.CreateTextBox();
    private readonly TextBox _streetBox = AppTheme.CreateTextBox();
    private readonly TextBox _houseBox = AppTheme.CreateTextBox();

    private readonly ComboBox _patientBox = AppTheme.CreateComboBox();
    private readonly Label _patientInfoLabel = new() { AutoSize = false, Height = 54, Width = 380, Font = AppTheme.Body(9.5F), ForeColor = AppTheme.TextMuted };

    private readonly ComboBox _crewBox = AppTheme.CreateComboBox();
    private readonly ComboBox _doctorBox = AppTheme.CreateComboBox();
    private readonly DateTimePicker _arrivalDate = new() { Format = DateTimePickerFormat.Long, Width = 200 };
    private readonly DateTimePicker _arrivalTime = new() { Format = DateTimePickerFormat.Time, ShowUpDown = true, Width = 100 };
    private readonly DateTimePicker _finishDate = new() { Format = DateTimePickerFormat.Long, Width = 200 };
    private readonly DateTimePicker _finishTime = new() { Format = DateTimePickerFormat.Time, ShowUpDown = true, Width = 100 };
    private readonly Label _delayLabel = new() { AutoSize = true, Font = AppTheme.SubHeading(10F), ForeColor = AppTheme.Primary };

    private readonly TextBox _aidBox = AppTheme.CreateTextBox();
    private readonly TextBox _diagnosisBox = AppTheme.CreateTextBox();
    private readonly ComboBox _resultBox = AppTheme.CreateComboBox();
    private readonly ComboBox _hospitalBox = AppTheme.CreateComboBox();

    private readonly ToolStripStatusLabel _statusLabel;
    private readonly ToolStripStatusLabel _hintLabel;
    private readonly ToolTip _toolTip = new()
    {
        AutoPopDelay = 9000,
        InitialDelay = 400,
        ReshowDelay = 200,
        ShowAlways = true
    };
    private bool _isEditing;
    private bool _isNew;

    public CallForm(DataStore store)
    {
        _store = store;

        Text = "Вызовы скорой помощи";
        StartPosition = FormStartPosition.CenterParent;
        MinimumSize = new Size(1100, 680);
        ClientSize = new Size(1240, 780);
        BackColor = AppTheme.Surface;
        Font = AppTheme.Body();

        var header = new PageHeaderPanel("Регистрация вызовов",
            "Основной объект учёта: данные пациента, адрес, повод, бригада, время обслуживания и результат");

        _toolStrip = new ToolStrip
        {
            GripStyle = ToolStripGripStyle.Hidden,
            BackColor = Color.White,
            Padding = new Padding(12, 4, 12, 4),
            Height = 42
        };

        var newButton = new ToolStripButton("Новый вызов") { DisplayStyle = ToolStripItemDisplayStyle.Text };
        newButton.Click += (_, _) => StartNew();
        var editButton = new ToolStripButton("Изменить") { DisplayStyle = ToolStripItemDisplayStyle.Text };
        editButton.Click += (_, _) => StartEdit();
        var refreshButton = new ToolStripButton("Обновить") { DisplayStyle = ToolStripItemDisplayStyle.Text };
        refreshButton.Click += (_, _) => Reload();

        _saveButton = new ToolStripButton("Сохранить") { DisplayStyle = ToolStripItemDisplayStyle.Text, Enabled = false };
        _saveButton.Click += (_, _) => Save();
        _cancelButton = new ToolStripButton("Отмена") { DisplayStyle = ToolStripItemDisplayStyle.Text, Enabled = false };
        _cancelButton.Click += (_, _) => CancelEditing();

        _searchBox = new PlaceholderTextBox
        {
            Width = 240,
            Placeholder = "Номер, повод или диагноз"
        };
        _toolTip.SetToolTip(_searchBox, "Введите номер вызова, повод или диагноз — журнал отфильтруется");
        var searchHost = new ToolStripControlHost(_searchBox)
        {
            AutoSize = false,
            Width = 246,
            Height = 25,
            Margin = new Padding(4, 3, 4, 3)
        };
        _searchBox.TextChanged += (_, _) => ApplyFilter();

        _toolStrip.Items.AddRange(new ToolStripItem[]
        {
            newButton, editButton, new ToolStripSeparator(), _saveButton, _cancelButton, new ToolStripSeparator(), refreshButton,
            new ToolStripLabel("Поиск:"), searchHost
        });

        AppTheme.StyleGrid(_grid);
        _grid.Dock = DockStyle.Fill;
        _grid.CellDoubleClick += (_, e) => { if (e.RowIndex >= 0) StartEdit(); };

        BuildTabs();
        BuildGridColumns();

        var split = new SplitContainer
        {
            Dock = DockStyle.Fill,
            Orientation = Orientation.Horizontal,
            SplitterWidth = 6
        };
        split.Panel1.Controls.Add(_grid);
        split.Panel1.Padding = new Padding(16, 10, 16, 4);
        split.Panel2.Controls.Add(_tabs);
        split.Panel2.Padding = new Padding(16, 4, 16, 10);
        split.SizeChanged += (_, _) => TuneSplit(split);
        split.HandleCreated += (_, _) => TuneSplit(split);

        var statusStrip = new StatusStrip { BackColor = Color.White, SizingGrip = false };
        _statusLabel = new ToolStripStatusLabel("Записей: 0") { Spring = false };
        _hintLabel = new ToolStripStatusLabel
        {
            Spring = true,
            TextAlign = ContentAlignment.MiddleLeft,
            ForeColor = AppTheme.TextMuted,
            Text = "Выберите вызов и нажмите «Изменить» или создайте новый вызов"
        };
        statusStrip.Items.Add(_statusLabel);
        statusStrip.Items.Add(new ToolStripSeparator());
        statusStrip.Items.Add(_hintLabel);
        _toolTip.SetToolTip(_grid, "Двойной щелчок по строке открывает вызов для изменения");
        _toolTip.SetToolTip(_numberBox, "Номер формируется автоматически, при необходимости его можно изменить вручную");
        _toolTip.SetToolTip(_urgencyBox, "Экстренный вызов — норматив прибытия 20 минут, неотложный — 40 минут");
        _toolTip.SetToolTip(_patientBox, "Выберите пациента из справочника; отсутствующего добавьте в меню «Справочники → Пациенты»");
        _toolTip.SetToolTip(_crewBox, "Список врачей ограничивается составом выбранной бригады");
        _toolTip.SetToolTip(_arrivalTime, "Фактическое время прибытия бригады на адрес");
        _toolTip.SetToolTip(_finishTime, "Время окончания обслуживания вызова");
        _toolTip.SetToolTip(_resultBox, "При результате «Госпитализация» обязательно указывается больница");
        _toolTip.SetToolTip(_tabs, "Заполняйте вкладки по порядку: вызов, пациент, бригада и время, результат");

        Controls.Add(split);
        Controls.Add(_toolStrip);
        Controls.Add(header);
        Controls.Add(statusStrip);

        _patientBox.SelectedIndexChanged += (_, _) => UpdatePatientInfo();
        _crewBox.SelectedIndexChanged += (_, _) => UpdateDoctors();
        _urgencyBox.SelectedIndexChanged += (_, _) => UpdateDelay();
        _arrivalDate.ValueChanged += (_, _) => UpdateDelay();
        _arrivalTime.ValueChanged += (_, _) => UpdateDelay();
        _receivedDate.ValueChanged += (_, _) => UpdateDelay();
        _receivedTime.ValueChanged += (_, _) => UpdateDelay();
        _resultBox.SelectedIndexChanged += (_, _) => _hospitalBox.Enabled = _resultBox.SelectedIndex == 0;

        _urgencyBox.Items.AddRange(["Экстренный", "Неотложный"]);
        _resultBox.Items.AddRange(["Госпитализация", "Отказ от госпитализации", "Оставлен на месте"]);

        SetEditing(false);
        Load += (_, _) =>
        {
            Reload();
        };
    }

    /// <summary>Задаёт границы панелей после того, как окно получило окончательные размеры.</summary>
    private static void TuneSplit(SplitContainer split)
    {
        var height = split.Height;
        if (height < 420)
        {
            return;
        }

        try
        {
            split.Panel1MinSize = 150;
            split.Panel2MinSize = 280;
            var target = (int)(height * 0.42);
            if (target > split.Panel1MinSize && target < height - split.Panel2MinSize - split.SplitterWidth)
            {
                split.SplitterDistance = target;
            }
        }
        catch (ArgumentOutOfRangeException)
        {
            // Размеры окна ещё не установлены — границы будут заданы при следующем изменении размера.
        }
    }

    private void BuildGridColumns()
    {
        _grid.AutoGenerateColumns = false;
        _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Номер", DataPropertyName = nameof(Call.Number), FillWeight = 70 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Дата и время", DataPropertyName = nameof(Call.ReceivedAt), FillWeight = 110, DefaultCellStyle = { Format = "dd.MM.yyyy HH:mm" } });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Пациент", DataPropertyName = nameof(CallRow.PatientName), FillWeight = 180 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Адрес", DataPropertyName = nameof(CallRow.Address), FillWeight = 200 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Срочность", DataPropertyName = nameof(CallRow.UrgencyName), FillWeight = 90 });
        _grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Результат / состояние", DataPropertyName = nameof(CallRow.StatusName), FillWeight = 150 });
    }

    /// <summary>Строка журнала вызовов с подготовленными для отображения значениями.</summary>
    private class CallRow
    {
        public CallRow(Call call, string patientName)
        {
            Call = call;
            PatientName = patientName;
        }

        public Call Call { get; }

        public string Number => Call.Number;

        public DateTime ReceivedAt => Call.ReceivedAt;

        public string PatientName { get; }

        public string Address => Call.Address;

        public string UrgencyName => Call.Urgency.ToRussian();

        public string StatusName => Call.Result?.ToRussian() ?? Call.Status.ToRussian();
    }

    private void BuildTabs()
    {
        _tabs.Dock = DockStyle.Fill;
        _tabs.Font = AppTheme.Body(9.75F);

        var callTab = new TabPage("Вызов") { BackColor = Color.White, Padding = new Padding(14) };
        var callLayout = CreateTwoColumnLayout();
        AddField(callLayout, 0, 0, "Номер вызова *", _numberBox, "Формируется автоматически, допускается ручная корректировка");
        AddField(callLayout, 0, 1, "Категория срочности *", _urgencyBox);
        AddField(callLayout, 1, 0, "Повод к вызову *", _reasonBox, "Краткое описание причины обращения");
        AddField(callLayout, 2, 0, "Район *", _districtBox);
        AddField(callLayout, 2, 1, "Улица *", _streetBox);
        AddField(callLayout, 3, 0, "Дом *", _houseBox);
        var timeGroup = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight, AutoSize = true };
        _receivedTime.Margin = new Padding(8, 0, 0, 0);
        timeGroup.Controls.Add(_receivedDate);
        timeGroup.Controls.Add(_receivedTime);
        AddField(callLayout, 1, 1, "Дата и время поступления *", timeGroup);
        callTab.Controls.Add(callLayout);

        var patientTab = new TabPage("Пациент") { BackColor = Color.White, Padding = new Padding(14) };
        var patientLayout = CreateTwoColumnLayout();
        AddField(patientLayout, 0, 0, "Пациент *", _patientBox, "Выбор из справочника пациентов");
        _patientInfoLabel.Margin = new Padding(0, 4, 0, 0);
        var infoHost = new Panel { Dock = DockStyle.Fill, AutoSize = true };
        infoHost.Controls.Add(_patientInfoLabel);
        AddField(patientLayout, 1, 0, "Данные пациента", infoHost);
        patientTab.Controls.Add(patientLayout);

        var crewTab = new TabPage("Бригада и время") { BackColor = Color.White, Padding = new Padding(14) };
        var crewLayout = CreateTwoColumnLayout();
        AddField(crewLayout, 0, 0, "Бригада *", _crewBox);
        AddField(crewLayout, 0, 1, "Врач / ответственный *", _doctorBox);
        var arrivalGroup = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight, AutoSize = true };
        _arrivalTime.Margin = new Padding(8, 0, 0, 0);
        arrivalGroup.Controls.Add(_arrivalDate);
        arrivalGroup.Controls.Add(_arrivalTime);
        AddField(crewLayout, 1, 0, "Время прибытия *", arrivalGroup);
        var finishGroup = new FlowLayoutPanel { Dock = DockStyle.Fill, FlowDirection = FlowDirection.LeftToRight, AutoSize = true };
        _finishTime.Margin = new Padding(8, 0, 0, 0);
        finishGroup.Controls.Add(_finishDate);
        finishGroup.Controls.Add(_finishTime);
        AddField(crewLayout, 1, 1, "Время окончания", finishGroup);
        _delayLabel.Margin = new Padding(0, 10, 0, 0);
        AddField(crewLayout, 2, 0, "Отклонение от норматива", _delayLabel, "Норматив: 20 мин для экстренного и 40 мин для неотложного вызова");
        crewTab.Controls.Add(crewLayout);

        var resultTab = new TabPage("Результат") { BackColor = Color.White, Padding = new Padding(14) };
        var resultLayout = CreateTwoColumnLayout();
        AddField(resultLayout, 0, 0, "Оказанная помощь *", _aidBox, "Перечень выполненных мероприятий");
        AddField(resultLayout, 1, 0, "Диагноз *", _diagnosisBox);
        AddField(resultLayout, 2, 0, "Результат вызова *", _resultBox);
        AddField(resultLayout, 2, 1, "Больница", _hospitalBox, "Обязательно при госпитализации");
        resultTab.Controls.Add(resultLayout);

        _tabs.TabPages.AddRange([callTab, patientTab, crewTab, resultTab]);
    }

    private static TableLayoutPanel CreateTwoColumnLayout()
    {
        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 4,
            BackColor = Color.Transparent
        };
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50));
        for (var row = 0; row < 4; row++)
        {
            layout.RowStyles.Add(new RowStyle(SizeType.Absolute, 70));
        }

        return layout;
    }

    private static void AddField(TableLayoutPanel layout, int row, int column, string label, Control control, string? hint = null)
    {
        var group = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            BackColor = Color.Transparent,
            Margin = new Padding(0, 4, 24, 4)
        };

        var caption = new Label
        {
            Text = label,
            AutoSize = true,
            Font = AppTheme.Body(9F),
            ForeColor = AppTheme.TextMuted,
            Margin = new Padding(0, 0, 0, 3)
        };

        control.Width = 330;
        control.Margin = new Padding(0, 0, 0, 2);
        group.Controls.Add(caption);
        group.Controls.Add(control);

        if (hint is not null)
        {
            group.Controls.Add(new Label
            {
                Text = hint,
                AutoSize = false,
                Width = 330,
                Height = 16,
                Font = AppTheme.Body(7.75F),
                ForeColor = AppTheme.TextMuted,
                Margin = new Padding(0, 0, 0, 0)
            });
        }

        layout.Controls.Add(group, column, row);
    }

    private void Reload()
    {
        foreach (var combo in new[] { _patientBox, _crewBox, _hospitalBox })
        {
            combo.Items.Clear();
        }

        foreach (var patient in _store.Patients.OrderBy(patient => patient.FullName))
        {
            _patientBox.Items.Add(patient);
        }

        foreach (var crew in _store.Crews)
        {
            _crewBox.Items.Add(crew);
        }

        foreach (var hospital in _store.Hospitals)
        {
            _hospitalBox.Items.Add(hospital);
        }

        _calls.RaiseListChangedEvents = false;
        _calls.Clear();
        foreach (var call in _store.Calls.OrderByDescending(call => call.ReceivedAt))
        {
            _calls.Add(call);
        }

        _calls.RaiseListChangedEvents = true;
        ApplyFilter();
    }

    private void ApplyFilter()
    {
        var query = _searchBox.Text.Trim();
        var filtered = query.Length == 0
            ? _calls.ToList()
            : _calls.Where(call => call.Number.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                                   call.Reason.Contains(query, StringComparison.OrdinalIgnoreCase) ||
                                   call.Diagnosis.Contains(query, StringComparison.OrdinalIgnoreCase)).ToList();

        var rows = filtered
            .Select(call => new CallRow(call, _store.Patients.FirstOrDefault(patient => patient.Id == call.PatientId)?.FullName ?? "—"))
            .ToList();
        _grid.DataSource = new BindingList<CallRow>(rows);
        _statusLabel.Text = $"Записей: {filtered.Count}. Демонстрационный набор данных: {(_calls.Count > 0 ? "включён" : "отключён")}";
    }

    private void StartNew()
    {
        _isEditing = true;
        _isNew = true;
        var nextNumber = _store.Calls.Count == 0 ? 1 : _store.Calls.Max(call => call.Id) + 1;
        _numberBox.Text = $"В-{nextNumber:0000}";
        _receivedDate.Value = DateTime.Today;
        _receivedTime.Value = DateTime.Now;
        _urgencyBox.SelectedIndex = 0;
        _reasonBox.Clear();
        _districtBox.Clear();
        _streetBox.Clear();
        _houseBox.Clear();
        _patientBox.SelectedIndex = -1;
        _crewBox.SelectedIndex = -1;
        _doctorBox.Items.Clear();
        _arrivalDate.Value = DateTime.Today;
        _arrivalTime.Value = DateTime.Now;
        _finishDate.Value = DateTime.Today;
        _finishTime.Value = DateTime.Now;
        _aidBox.Clear();
        _diagnosisBox.Clear();
        _resultBox.SelectedIndex = -1;
        _hospitalBox.SelectedIndex = -1;
        SetEditing(true);
        _tabs.SelectedIndex = 0;
        _numberBox.Focus();
    }

    private void StartEdit()
    {
        if (_grid.CurrentRow?.DataBoundItem is not CallRow row)
        {
            Messages.ShowWarning(this, "Выберите вызов в таблице, который требуется изменить.", "Запись не выбрана");
            return;
        }

        var call = row.Call;

        _isEditing = true;
        _isNew = false;
        _numberBox.Text = call.Number;
        _receivedDate.Value = call.ReceivedAt.Date;
        _receivedTime.Value = call.ReceivedAt;
        _urgencyBox.SelectedIndex = (int)call.Urgency;
        _reasonBox.Text = call.Reason;
        _districtBox.Text = call.District;
        _streetBox.Text = call.Street;
        _houseBox.Text = call.House;
        _patientBox.SelectedItem = _store.Patients.FirstOrDefault(patient => patient.Id == call.PatientId);
        _crewBox.SelectedItem = _store.Crews.FirstOrDefault(crew => crew.Id == call.CrewId);
        UpdateDoctors();
        _doctorBox.SelectedItem = _store.Employees.FirstOrDefault(employee => employee.Id == call.DoctorId);
        if (call.ArrivalAt is not null)
        {
            _arrivalDate.Value = call.ArrivalAt.Value.Date;
            _arrivalTime.Value = call.ArrivalAt.Value;
        }

        if (call.FinishedAt is not null)
        {
            _finishDate.Value = call.FinishedAt.Value.Date;
            _finishTime.Value = call.FinishedAt.Value;
        }

        _aidBox.Text = call.Aid;
        _diagnosisBox.Text = call.Diagnosis;
        _resultBox.SelectedIndex = call.Result is null ? -1 : (int)call.Result;
        _hospitalBox.SelectedItem = _store.Hospitals.FirstOrDefault(hospital => hospital.Id == call.HospitalId);
        SetEditing(true);
        UpdateDelay();
    }

    private void UpdateDoctors()
    {
        _doctorBox.Items.Clear();
        if (_crewBox.SelectedItem is not Crew crew)
        {
            return;
        }

        var memberIds = _store.CrewMembers.Where(member => member.CrewId == crew.Id).Select(member => member.EmployeeId).ToHashSet();
        foreach (var employee in _store.Employees.Where(employee => memberIds.Contains(employee.Id)))
        {
            _doctorBox.Items.Add(employee);
        }
    }

    private void UpdatePatientInfo()
    {
        if (_patientBox.SelectedItem is Patient patient)
        {
            _patientInfoLabel.Text = $"{patient.FullName}\r\nПол: {patient.SexName}. Возраст: {patient.Age} лет.\r\nРайон: {patient.District}. Полис: {patient.PolicyNumber}";
        }
        else
        {
            _patientInfoLabel.Text = "Пациент не выбран";
        }
    }

    private void UpdateDelay()
    {
        if (_urgencyBox.SelectedIndex < 0)
        {
            _delayLabel.Text = "—";
            return;
        }

        var urgency = (UrgencyCategory)_urgencyBox.SelectedIndex;
        var received = _receivedDate.Value.Date + _receivedTime.Value.TimeOfDay;
        var arrival = _arrivalDate.Value.Date + _arrivalTime.Value.TimeOfDay;
        var actual = (arrival - received).TotalMinutes;
        var norm = urgency.NormativeArrivalMinutes();
        var deviation = actual - norm;

        _delayLabel.ForeColor = deviation > 0 ? AppTheme.Accent : AppTheme.Success;
        _delayLabel.Text = deviation > 0
            ? $"Прибытие через {actual:F0} мин — задержка {deviation:F0} мин (норматив {norm} мин)"
            : $"Прибытие через {actual:F0} мин — в пределах норматива ({norm} мин)";
    }

    private void Save()
    {
        try
        {
            var call = BuildCallFromEditors();
            if (_isNew)
            {
                _store.Calls.Add(call);
            }
            else if (_grid.CurrentRow?.DataBoundItem is CallRow row)
            {
                CopyCall(call, row.Call);
            }

            if (!StoreFile.TrySave(_store))
            {
                Messages.ShowWarning(this,
                    (StoreFile.LastError ?? "Не удалось сохранить данные в файл.") +
                    Environment.NewLine + Environment.NewLine +
                    "Вызов остаётся в памяти и будет доступен до закрытия приложения.",
                    "Сохранение данных");
            }

            SetEditing(false);
            Reload();
            Messages.ShowInfo(this, "Вызов сохранён в журнале регистрации.", "Данные сохранены");
        }
        catch (InputValidationException exception)
        {
            Messages.ShowError(this, exception.Message, "Некорректные данные вызова");
        }
    }

    private Call BuildCallFromEditors()
    {
        if (_numberBox.Text.Trim().Length == 0)
        {
            throw new InputValidationException("Поле «Номер вызова» обязательно для заполнения.");
        }

        if (_patientBox.SelectedItem is not Patient patient)
        {
            throw new InputValidationException("Выберите пациента из справочника. Если пациента нет в списке, добавьте его в справочнике «Пациенты».");
        }

        if (_reasonBox.Text.Trim().Length < 3)
        {
            throw new InputValidationException("Поле «Повод к вызову» должно содержать не менее 3 символов.");
        }

        if (_districtBox.Text.Trim().Length == 0 || _streetBox.Text.Trim().Length == 0 || _houseBox.Text.Trim().Length == 0)
        {
            throw new InputValidationException("Адрес вызова заполнен не полностью: укажите район, улицу и номер дома.");
        }

        if (_urgencyBox.SelectedIndex < 0)
        {
            throw new InputValidationException("Выберите категорию срочности вызова.");
        }

        if (_crewBox.SelectedItem is not Crew crew)
        {
            throw new InputValidationException("Выберите бригаду, которая обслуживает вызов.");
        }

        if (_doctorBox.SelectedItem is not Employee doctor)
        {
            throw new InputValidationException("Выберите врача или ответственного сотрудника бригады.");
        }

        var received = _receivedDate.Value.Date + _receivedTime.Value.TimeOfDay;
        var arrival = _arrivalDate.Value.Date + _arrivalTime.Value.TimeOfDay;
        var finished = _finishDate.Value.Date + _finishTime.Value.TimeOfDay;

        if (arrival < received)
        {
            throw new InputValidationException("Время прибытия бригады не может быть раньше времени поступления вызова. Проверьте дату и время.");
        }

        if (finished < arrival)
        {
            throw new InputValidationException("Время окончания вызова не может быть раньше времени прибытия бригады.");
        }

        if (_diagnosisBox.Text.Trim().Length < 3)
        {
            throw new InputValidationException("Поле «Диагноз» должно содержать не менее 3 символов.");
        }

        if (_resultBox.SelectedIndex < 0)
        {
            throw new InputValidationException("Выберите результат вызова: госпитализация, отказ от госпитализации или оставлен на месте.");
        }

        var result = (CallResult)_resultBox.SelectedIndex;
        int? hospitalId = null;
        if (result == CallResult.Hospitalized)
        {
            if (_hospitalBox.SelectedItem is not Hospital hospital)
            {
                throw new InputValidationException("При госпитализации необходимо указать больницу, в которую доставлен пациент.");
            }

            hospitalId = hospital.Id;
        }

        return new Call
        {
            Id = _store.Calls.Count == 0 ? 1 : _store.Calls.Max(item => item.Id) + 1,
            Number = _numberBox.Text.Trim(),
            ReceivedAt = received,
            District = _districtBox.Text.Trim(),
            Street = _streetBox.Text.Trim(),
            House = _houseBox.Text.Trim(),
            PatientId = patient.Id,
            Reason = _reasonBox.Text.Trim(),
            Urgency = (UrgencyCategory)_urgencyBox.SelectedIndex,
            CrewId = crew.Id,
            DoctorId = doctor.Id,
            ArrivalAt = arrival,
            FinishedAt = finished,
            Aid = _aidBox.Text.Trim(),
            Diagnosis = _diagnosisBox.Text.Trim(),
            Result = result,
            HospitalId = hospitalId,
            Status = CallStatus.Completed
        };
    }

    private static void CopyCall(Call source, Call target)
    {
        target.Number = source.Number;
        target.ReceivedAt = source.ReceivedAt;
        target.District = source.District;
        target.Street = source.Street;
        target.House = source.House;
        target.PatientId = source.PatientId;
        target.Reason = source.Reason;
        target.Urgency = source.Urgency;
        target.CrewId = source.CrewId;
        target.DoctorId = source.DoctorId;
        target.ArrivalAt = source.ArrivalAt;
        target.FinishedAt = source.FinishedAt;
        target.Aid = source.Aid;
        target.Diagnosis = source.Diagnosis;
        target.Result = source.Result;
        target.HospitalId = source.HospitalId;
        target.Status = source.Status;
    }

    private void CancelEditing()
    {
        if (!_isEditing)
        {
            return;
        }

        SetEditing(false);
    }

    private void SetEditing(bool editing)
    {
        _isEditing = editing;
        _saveButton.Enabled = editing;
        _cancelButton.Enabled = editing;

        foreach (TabPage page in _tabs.TabPages)
        {
            foreach (Control control in page.Controls)
            {
                EnableControls(control, true);
            }
        }

        foreach (var control in new Control[] { _numberBox, _receivedDate, _receivedTime, _urgencyBox, _reasonBox, _districtBox, _streetBox, _houseBox,
                     _patientBox, _crewBox, _doctorBox, _arrivalDate, _arrivalTime, _finishDate, _finishTime, _aidBox, _diagnosisBox, _resultBox, _hospitalBox })
        {
            control.Enabled = editing;
        }

        _statusLabel.Text = editing ? "Режим редактирования" : $"Записей: {_calls.Count}";
        _hintLabel.Text = editing
            ? "Заполняйте вкладки по порядку: вызов, пациент, бригада и время, результат"
            : "Выберите вызов и нажмите «Изменить», чтобы посмотреть или исправить данные";
    }

    private static void EnableControls(Control control, bool enabled)
    {
        control.Enabled = enabled;
        foreach (Control child in control.Controls)
        {
            EnableControls(child, enabled);
        }
    }
}
