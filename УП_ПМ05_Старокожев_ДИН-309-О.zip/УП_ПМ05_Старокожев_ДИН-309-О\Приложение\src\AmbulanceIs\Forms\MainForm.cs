﻿using System.Diagnostics;
using AmbulanceIs.Common;
using AmbulanceIs.Controls;
using AmbulanceIs.Domain;
using AmbulanceIs.Forms.Documents;
using AmbulanceIs.Forms.Queries;
using AmbulanceIs.Forms.References;
using AmbulanceIs.Services;

namespace AmbulanceIs.Forms;

/// <summary>Главное окно приложения: меню, сводные показатели и быстрый доступ к окнам системы.</summary>
public class MainForm : Form
{
    private readonly UserRepository _repository;
    private ToolStripMenuItem _usersMenuItem = null!;
    private readonly DashboardCard _callsCard;
    private readonly DashboardCard _crewsCard;
    private readonly DashboardCard _employeesCard;
    private readonly DashboardCard _fleetCard;
    private readonly Label _greetingLabel;
    private readonly Label _roleLabel;
    private readonly ToolStripStatusLabel _userStatusLabel;
    private readonly ToolStripStatusLabel _modeStatusLabel;
    private readonly ToolStripStatusLabel _timeStatusLabel;
    private readonly Panel _dashboard;

    private DataStore _store;

    public MainForm(DataStore store, UserRepository repository)
    {
        _store = store;
        _repository = repository;

        Text = Messages.ApplicationTitle;
        StartPosition = FormStartPosition.CenterScreen;
        MinimumSize = new Size(1100, 700);
        ClientSize = new Size(1280, 800);
        BackColor = AppTheme.Surface;
        Font = AppTheme.Body();
        WindowState = FormWindowState.Normal;

        var menu = BuildMenu();
        _usersMenuItem = FindMenuItem(menu, "Пользователи системы...")!;

        var toolStrip = BuildToolStrip();

        _greetingLabel = new Label
        {
            Text = $"Добро пожаловать, {Session.CurrentUserName}",
            Dock = DockStyle.Top,
            Height = 36,
            Font = AppTheme.Heading(17F),
            ForeColor = AppTheme.TextPrimary
        };

        _roleLabel = new Label
        {
            Text = string.Empty,
            Dock = DockStyle.Top,
            Height = 24,
            Font = AppTheme.Body(9.5F),
            ForeColor = AppTheme.TextMuted
        };

        _callsCard = new DashboardCard("Вызовы за период", "нет данных", AppTheme.Primary);
        _crewsCard = new DashboardCard("Бригады на дежурстве", "нет данных", AppTheme.Success);
        _employeesCard = new DashboardCard("Сотрудники службы", "нет данных", AppTheme.Primary);
        _fleetCard = new DashboardCard("Автомобили автопарка", "нет данных", AppTheme.Accent);

        var cardsPanel = new FlowLayoutPanel
        {
            Dock = DockStyle.Top,
            Height = 132,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = false,
            Padding = new Padding(0, 6, 0, 0),
            BackColor = Color.Transparent
        };
        cardsPanel.Controls.Add(_callsCard);
        cardsPanel.Controls.Add(_crewsCard);
        cardsPanel.Controls.Add(_employeesCard);
        cardsPanel.Controls.Add(_fleetCard);

        var toolTip = new ToolTip { AutoPopDelay = 9000, InitialDelay = 350, ShowAlways = true };
        toolTip.SetToolTip(_callsCard, "Щёлкните, чтобы открыть окно запроса «Вызовы за период»");
        toolTip.SetToolTip(_crewsCard, "Щёлкните, чтобы открыть окно «Загрузка подстанций»");
        toolTip.SetToolTip(_employeesCard, "Щёлкните, чтобы открыть справочник сотрудников");
        toolTip.SetToolTip(_fleetCard, "Щёлкните, чтобы открыть справочник автомобилей");

        _callsCard.Click += (_, _) => OpenWindow(new Query04CallsForm(_store));
        _crewsCard.Click += (_, _) => OpenWindow(new Query07StationLoadForm(_store));
        _employeesCard.Click += (_, _) => OpenWindow(new EmployeeForm(_store));
        _fleetCard.Click += (_, _) => OpenWindow(new VehicleForm(_store));

        var quickPanel = BuildQuickActions();

        var infoPanel = BuildInfoPanel();

        _dashboard = new Panel { Dock = DockStyle.Fill, Padding = new Padding(28, 18, 28, 18), AutoScroll = true, BackColor = AppTheme.Surface };
        _dashboard.Controls.Add(infoPanel);
        _dashboard.Controls.Add(quickPanel);
        _dashboard.Controls.Add(cardsPanel);
        _dashboard.Controls.Add(_roleLabel);
        _dashboard.Controls.Add(_greetingLabel);

        var statusStrip = new StatusStrip { BackColor = Color.White, SizingGrip = false };
        _userStatusLabel = new ToolStripStatusLabel { Spring = false };
        _modeStatusLabel = new ToolStripStatusLabel { Spring = true, TextAlign = ContentAlignment.MiddleLeft };
        _timeStatusLabel = new ToolStripStatusLabel { Spring = false };
        statusStrip.Items.Add(_userStatusLabel);
        statusStrip.Items.Add(new ToolStripSeparator());
        statusStrip.Items.Add(_modeStatusLabel);
        statusStrip.Items.Add(_timeStatusLabel);

        Controls.Add(_dashboard);
        Controls.Add(statusStrip);
        Controls.Add(toolStrip);
        Controls.Add(menu);

        MainMenuStrip = menu;
        KeyPreview = true;
        KeyDown += (_, e) =>
        {
            if (e.KeyCode == Keys.F1)
            {
                ShowUserGuide();
                e.Handled = true;
            }
        };
        UpdateUserInfo();
        RefreshDashboard();
        UpdateDemoMenu();

        FormClosing += (_, _) => StoreFile.TrySave(_store);
        Load += (_, _) => UpdateDemoMenu();
    }

    /// <summary>Признак того, что пользователь запросил смену учётной записи.</summary>
    public bool SwitchUserRequested { get; private set; }

    private MenuStrip BuildMenu()
    {
        var menu = new MenuStrip
        {
            BackColor = Color.White,
            Padding = new Padding(8, 2, 0, 2),
            Font = AppTheme.Body(9.75F)
        };

        var fileMenu = new ToolStripMenuItem("Файл");
        var saveItem = new ToolStripMenuItem("Сохранить данные", null, (_, _) => SaveData())
        {
            ShortcutKeys = Keys.Control | Keys.S
        };
        var openFolder = new ToolStripMenuItem("Открыть папку с данными", null, (_, _) => OpenDataFolder());
        var switchUser = new ToolStripMenuItem("Сменить пользователя", null, (_, _) =>
        {
            SwitchUserRequested = true;
            Close();
        }) { ShortcutKeys = Keys.F2 };
        var exit = new ToolStripMenuItem("Выход", null, (_, _) =>
        {
            SwitchUserRequested = false;
            Close();
        }) { ShortcutKeys = Keys.Alt | Keys.F4 };
        fileMenu.DropDownItems.AddRange(
        [
            saveItem,
            openFolder,
            new ToolStripSeparator(),
            switchUser,
            new ToolStripSeparator(),
            exit
        ]);

        var operationMenu = new ToolStripMenuItem("Работа службы");
        operationMenu.DropDownItems.AddRange(
        [
            new ToolStripMenuItem("Регистрация вызова...", null, (_, _) => OpenWindow(new CallForm(_store)), Keys.Control | Keys.N),
            new ToolStripMenuItem("Состав выездных бригад...", null, (_, _) => OpenWindow(new CrewMemberForm(_store)))
        ]);

        var referenceMenu = new ToolStripMenuItem("Справочники");
        referenceMenu.DropDownItems.AddRange(
        [
            new ToolStripMenuItem("Подстанции...", null, (_, _) => OpenWindow(new SubstationForm(_store))),
            new ToolStripMenuItem("Сотрудники...", null, (_, _) => OpenWindow(new EmployeeForm(_store))),
            new ToolStripMenuItem("Бригады...", null, (_, _) => OpenWindow(new CrewForm(_store))),
            new ToolStripMenuItem("Автомобили...", null, (_, _) => OpenWindow(new VehicleForm(_store))),
            new ToolStripMenuItem("Пациенты...", null, (_, _) => OpenWindow(new PatientForm(_store))),
            new ToolStripMenuItem("Больницы...", null, (_, _) => OpenWindow(new HospitalForm(_store)))
        ]);

        var queryMenu = new ToolStripMenuItem("Запросы");

        var crewsQueries = new ToolStripMenuItem("Бригады и сотрудники");
        crewsQueries.DropDownItems.AddRange(
        [
            new ToolStripMenuItem("Перечень бригад по типу...", null, (_, _) => OpenWindow(new Query01CrewsForm(_store))),
            new ToolStripMenuItem("Перечень сотрудников по категории...", null, (_, _) => OpenWindow(new Query02EmployeesForm(_store))),
            new ToolStripMenuItem("Состав бригады на дату...", null, (_, _) => OpenWindow(new Query03CrewCompositionForm(_store)))
        ]);

        var workQueries = new ToolStripMenuItem("Работа службы");
        workQueries.DropDownItems.AddRange(
        [
            new ToolStripMenuItem("Вызовы за период...", null, (_, _) => OpenWindow(new Query04CallsForm(_store))),
            new ToolStripMenuItem("Загрузка подстанций...", null, (_, _) => OpenWindow(new Query07StationLoadForm(_store))),
            new ToolStripMenuItem("Задержки прибытия бригад...", null, (_, _) => OpenWindow(new Query11LateCallsForm(_store)))
        ]);

        var analyticsQueries = new ToolStripMenuItem("Аналитика");
        analyticsQueries.DropDownItems.AddRange(
        [
            new ToolStripMenuItem("Среднее время прибытия...", null, (_, _) => OpenWindow(new Query05ArrivalForm(_store))),
            new ToolStripMenuItem("Выработка сотрудников...", null, (_, _) => OpenWindow(new Query06WorkloadForm(_store))),
            new ToolStripMenuItem("Пациенты, которым оказана помощь...", null, (_, _) => OpenWindow(new Query08ServedPatientsForm(_store))),
            new ToolStripMenuItem("История обращений пациента...", null, (_, _) => OpenWindow(new Query09PatientHistoryForm(_store))),
            new ToolStripMenuItem("Госпитализации по больницам...", null, (_, _) => OpenWindow(new Query10HospitalizationsForm(_store)))
        ]);

        var fleetQueries = new ToolStripMenuItem("Автопарк");
        fleetQueries.DropDownItems.Add(new ToolStripMenuItem("Автопарк и пробег...", null, (_, _) => OpenWindow(new Query12FleetForm(_store))));

        queryMenu.DropDownItems.AddRange([crewsQueries, workQueries, analyticsQueries, fleetQueries]);

        var adminMenu = new ToolStripMenuItem("Администрирование");
        var usersItem = new ToolStripMenuItem("Пользователи системы...", null, (_, _) => OpenUsers())
        {
            Enabled = Session.IsAdministrator
        };
        var demoItem = new ToolStripMenuItem("Загрузить демонстрационные данные...", null, (_, _) => LoadDemoData());
        var clearItem = new ToolStripMenuItem("Очистить все данные...", null, (_, _) => ClearData());
        adminMenu.DropDownItems.AddRange(
        [
            usersItem,
            new ToolStripSeparator(),
            demoItem,
            clearItem
        ]);

        var helpMenu = new ToolStripMenuItem("Справка");
        var aboutItem = new ToolStripMenuItem("О программе...", null, (_, _) => OpenWindow(new AboutForm()));
        helpMenu.DropDownItems.AddRange(
        [
            new ToolStripMenuItem("Руководство пользователя", null, (_, _) => ShowUserGuide()) { ShortcutKeys = Keys.F1 },
            aboutItem
        ]);

        menu.Items.AddRange([fileMenu, operationMenu, referenceMenu, queryMenu, adminMenu, helpMenu]);
        return menu;
    }

    private static ToolStripMenuItem? FindMenuItem(ToolStrip menu, string text)
    {
        return FindMenuItem(menu.Items, text);
    }

    private static ToolStripMenuItem? FindMenuItem(ToolStripItemCollection items, string text)
    {
        foreach (ToolStripItem item in items)
        {
            if (item is not ToolStripMenuItem menuItem)
            {
                continue;
            }

            if (menuItem.Text == text)
            {
                return menuItem;
            }

            var nested = FindMenuItem(menuItem.DropDownItems, text);
            if (nested is not null)
            {
                return nested;
            }
        }

        return null;
    }

    private ToolStrip BuildToolStrip()
    {
        var strip = new ToolStrip
        {
            GripStyle = ToolStripGripStyle.Hidden,
            BackColor = Color.White,
            Padding = new Padding(16, 2, 16, 4),
            Height = 38,
            Font = AppTheme.Body(9.5F)
        };

        var newCallButton = new ToolStripButton("Регистрация вызова")
        {
            DisplayStyle = ToolStripItemDisplayStyle.Text,
            ToolTipText = "Принять и оформить вызов (Ctrl+N)"
        };
        newCallButton.Click += (_, _) => OpenWindow(new CallForm(_store));
        var crewButton = new ToolStripButton("Бригады")
        {
            DisplayStyle = ToolStripItemDisplayStyle.Text,
            ToolTipText = "Справочник выездных бригад: тип, подстанция, автомобиль"
        };
        crewButton.Click += (_, _) => OpenWindow(new CrewForm(_store));
        var callsButton = new ToolStripButton("Журнал вызовов")
        {
            DisplayStyle = ToolStripItemDisplayStyle.Text,
            ToolTipText = "Вызовы за период с разбивкой по категориям срочности"
        };
        callsButton.Click += (_, _) => OpenWindow(new Query04CallsForm(_store));
        var loadButton = new ToolStripButton("Загрузка подстанций")
        {
            DisplayStyle = ToolStripItemDisplayStyle.Text,
            ToolTipText = "Сколько бригад дежурит, сколько свободно и сколько вызовов выполняется"
        };
        loadButton.Click += (_, _) => OpenWindow(new Query07StationLoadForm(_store));
        var usersButton = new ToolStripButton("Пользователи")
        {
            DisplayStyle = ToolStripItemDisplayStyle.Text,
            Enabled = Session.IsAdministrator,
            ToolTipText = "Управление учётными записями (доступно администратору)"
        };
        usersButton.Click += (_, _) => OpenUsers();
        var aboutButton = new ToolStripButton("О программе")
        {
            DisplayStyle = ToolStripItemDisplayStyle.Text,
            ToolTipText = "Сведения о назначении программы и версии"
        };
        aboutButton.Click += (_, _) => OpenWindow(new AboutForm());

        strip.Items.AddRange(new ToolStripItem[]
        {
            newCallButton, callsButton, crewButton, loadButton, new ToolStripSeparator(), usersButton, aboutButton
        });
        return strip;
    }

    private Panel BuildInfoPanel()
    {
        var panel = new Panel
        {
            Dock = DockStyle.Top,
            Height = 158,
            BackColor = Color.White,
            Padding = new Padding(20, 12, 20, 12),
            Margin = new Padding(0, 14, 0, 0)
        };
        AppTheme.ApplyRoundedBorder(panel, AppTheme.Border);

        var title = new Label
        {
            Text = "Порядок работы с системой",
            Dock = DockStyle.Top,
            Height = 26,
            Font = AppTheme.SubHeading(11F),
            ForeColor = AppTheme.Primary
        };

        var text = new Label
        {
            Dock = DockStyle.Fill,
            Font = AppTheme.Body(9.25F),
            ForeColor = AppTheme.TextPrimary,
            Text = "1. Учётные записи выдаёт администратор: для роли «Пользователь» при входе дополнительно требуется собрать капчу-пазл.\r\n" +
                   "2. Регистрация вызова выполняется в окне «Работа службы → Регистрация вызова»: адрес, пациент, бригада, время и результат.\r\n" +
                   "3. Справочники подстанций, сотрудников, бригад, автомобилей, пациентов и больниц ведутся в меню «Справочники».\r\n" +
                   "4. Отчёты формируются в меню «Запросы»; результат любого запроса можно выгрузить в файл CSV.\r\n" +
                   "5. Все изменения автоматически сохраняются в файл data/ambulance-data.json рядом с программой и загружаются при следующем запуске.\r\n" +
                   "6. Демонстрационный набор данных загружается из меню «Администрирование»; там же данные можно очистить."
        };

        panel.Controls.Add(text);
        panel.Controls.Add(title);
        return panel;
    }

    private Panel BuildQuickActions()
    {
        var panel = new Panel
        {
            Dock = DockStyle.Top,
            Height = 236,
            BackColor = Color.White,
            Padding = new Padding(20, 12, 20, 12),
            Margin = new Padding(0, 16, 0, 0)
        };
        AppTheme.ApplyRoundedBorder(panel, AppTheme.Border);

        var title = new Label
        {
            Text = "Быстрый доступ",
            Dock = DockStyle.Top,
            Height = 28,
            Font = AppTheme.SubHeading(11F),
            ForeColor = AppTheme.Primary
        };

        var hint = new Label
        {
            Text = "Основные операции учёта вызовов и работы выездных бригад доступны также из главного меню",
            Dock = DockStyle.Top,
            Height = 24,
            Font = AppTheme.Body(8.75F),
            ForeColor = AppTheme.TextMuted
        };

        var buttons = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = true,
            Padding = new Padding(0, 8, 0, 0)
        };

        void AddAction(string text, string description, Action action)
        {
            var button = new Button
            {
                Text = $"{text}\r\n{description}",
                Width = 300,
                Height = 66,
                TextAlign = ContentAlignment.MiddleLeft,
                FlatStyle = FlatStyle.Flat,
                BackColor = AppTheme.Surface,
                ForeColor = AppTheme.TextPrimary,
                Font = AppTheme.Body(9F),
                Padding = new Padding(10, 0, 0, 0),
                Margin = new Padding(0, 0, 12, 10),
                Cursor = Cursors.Hand
            };
            button.FlatAppearance.BorderColor = AppTheme.Border;
            button.Click += (_, _) => action();
            buttons.Controls.Add(button);
        }

        AddAction("Регистрация вызова", "приём и оформление вызова", () => OpenWindow(new CallForm(_store)));
        AddAction("Бригады на дежурстве", "состояние выездных бригад", () => OpenWindow(new CrewForm(_store)));
        AddAction("Загрузка подстанций", "дежурные и свободные бригады", () => OpenWindow(new Query07StationLoadForm(_store)));
        AddAction("Госпитализации", "сводка по больницам", () => OpenWindow(new Query10HospitalizationsForm(_store)));
        AddAction("Сотрудники", "справочник персонала", () => OpenWindow(new EmployeeForm(_store)));
        AddAction("Автопарк", "автомобили и пробег", () => OpenWindow(new VehicleForm(_store)));

        panel.Controls.Add(buttons);
        panel.Controls.Add(hint);
        panel.Controls.Add(title);
        return panel;
    }

    private void OpenWindow(Form form)
    {
        try
        {
            form.ShowDialog(this);
        }
        catch (Exception exception)
        {
            Messages.ShowError(this,
                "Не удалось открыть окно. Приложение продолжает работу.\r\n\r\n" + exception.Message,
                "Ошибка открытия окна");
        }

        RefreshDashboard();
    }

    private void OpenUsers()
    {
        if (!Session.IsAdministrator)
        {
            Messages.ShowWarning(this,
                "Доступ к управлению пользователями имеет только администратор системы. Войдите с учётной записью администратора.",
                "Недостаточно прав");
            return;
        }

        OpenWindow(new UsersForm(_repository));
    }

    private void LoadDemoData()
    {
        if (!Messages.Confirm(this,
            "Текущие записи будут заменены демонстрационным набором: 4 подстанции, 31 сотрудник, " +
            "8 бригад, 10 автомобилей, 15 пациентов и 357 вызовов. Продолжить?",
            "Демонстрационные данные"))
        {
            return;
        }

        _store = DataStore.ResetDemo();
        Session.DemoMode = true;
        StoreFile.TrySave(_store);
        RefreshDashboard();
        UpdateDemoMenu();
    }

    private void ClearData()
    {
        if (!Messages.Confirm(this,
            "Все записи будут удалены из файла данных. Действие нельзя отменить. Продолжить?",
            "Очистка данных"))
        {
            return;
        }

        _store = new DataStore();
        Session.DemoMode = false;
        StoreFile.TrySave(_store);
        RefreshDashboard();
        UpdateDemoMenu();
    }

    private void UpdateDemoMenu()
    {
        if (_modeStatusLabel is null)
        {
            return;
        }

        var mode = _store.IsDemo ? "демонстрационный набор" : "собственные записи";
        _modeStatusLabel.Text =
            $"Данные: {mode} · записей: {StoreFile.CountRecords(_store)} · файл: data/ambulance-data.json";
        _modeStatusLabel.ToolTipText = StoreFile.FilePath;
    }

    private void SaveData()
    {
        if (StoreFile.TrySave(_store))
        {
            RefreshDashboard();
            UpdateDemoMenu();
            Messages.ShowInfo(this,
                $"Данные сохранены в файл:{Environment.NewLine}{StoreFile.FilePath}" +
                $"{Environment.NewLine}{Environment.NewLine}Записей в наборе: {StoreFile.CountRecords(_store)}.",
                "Сохранение данных");
            return;
        }

        Messages.ShowWarning(this,
            StoreFile.LastError ?? "Не удалось сохранить данные в файл.",
            "Сохранение данных");
    }

    private void OpenDataFolder()
    {
        try
        {
            Directory.CreateDirectory(StoreFile.Folder);
            Process.Start(new ProcessStartInfo(StoreFile.Folder) { UseShellExecute = true });
        }
        catch (Exception exception)
        {
            Messages.ShowWarning(this,
                $"Не удалось открыть папку с данными.{Environment.NewLine}{Environment.NewLine}{exception.Message}",
                "Папка с данными");
        }
    }

    private void UpdateUserInfo()
    {
        var user = Session.CurrentUser;
        _roleLabel.Text = user is null
            ? "Роль не определена"
            : $"Роль: {user.RoleName} · Учётная запись: {user.Login} · Дата входа: {DateTime.Now:dd.MM.yyyy HH:mm}";

        _userStatusLabel.Text = user is null ? "Гость" : $"{user.FullName} ({user.RoleName})";
        _timeStatusLabel.Text = DateTime.Now.ToString("dd.MM.yyyy HH:mm");
    }

    private void RefreshDashboard()
    {
        var calls = _store.Calls;
        _callsCard.Value = calls.Count.ToString();
        _callsCard.Caption = calls.Count == 0
            ? "нет данных: база не подключена"
            : $"за период с {calls.Min(call => call.ReceivedAt):dd.MM.yyyy} по {calls.Max(call => call.ReceivedAt):dd.MM.yyyy}";

        var onDuty = _store.Crews.Count(crew => crew.IsOnDuty);
        _crewsCard.Value = $"{onDuty} из {_store.Crews.Count}";
        _crewsCard.Caption = "дежурные бригады подстанций";

        _employeesCard.Value = _store.Employees.Count.ToString();
        _employeesCard.Caption = $"врачей: {_store.Employees.Count(employee => employee.Category == EmployeeCategory.Doctor)}, фельдшеров: {_store.Employees.Count(employee => employee.Category == EmployeeCategory.Feldsher)}";

        _fleetCard.Value = _store.Vehicles.Count.ToString();
        _fleetCard.Caption = $"реанимобилей: {_store.Vehicles.Count(vehicle => vehicle.Type == VehicleType.Resuscitation)}, линейных: {_store.Vehicles.Count(vehicle => vehicle.Type == VehicleType.Linear)}";

        _usersMenuItem.Enabled = Session.IsAdministrator;
    }

    private void ShowUserGuide()
    {
        Messages.ShowInfo(this,
            "1. Вход в систему выполняется по логину и паролю, выданному администратором.\r\n" +
            "2. Для роли «Пользователь» дополнительно требуется собрать изображение из четырёх фрагментов.\r\n" +
            "3. Регистрация вызова выполняется в окне «Работа службы → Регистрация вызова».\r\n" +
            "4. Справочники подстанций, сотрудников, бригад, автомобилей, пациентов и больниц доступны в меню «Справочники».\r\n" +
            "5. Запросы и отчёты формируются в меню «Запросы»; результат можно выгрузить в файл CSV.\r\n" +
            "6. Изменения автоматически сохраняются в файл данных и загружаются при следующем запуске; " +
            "файл открывается из меню «Файл → Открыть папку с данными», сохранить вручную — Ctrl+S.\r\n" +
            "7. Смена пользователя выполняется по клавише F2 или через меню «Файл».\r\n\r\n" +
            "Демонстрационные записи: admin / Admin2026 (администратор), dispatcher / Disp2026 (пользователь).",
            "Руководство пользователя");
    }
}
