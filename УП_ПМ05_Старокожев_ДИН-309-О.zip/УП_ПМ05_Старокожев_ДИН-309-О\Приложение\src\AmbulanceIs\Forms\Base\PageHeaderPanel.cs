﻿using AmbulanceIs.Common;

namespace AmbulanceIs.Forms.Base;

/// <summary>Заголовочная панель окна с названием раздела и пояснением.</summary>
public class PageHeaderPanel : Panel
{
    private readonly Label _titleLabel;
    private readonly Label _subtitleLabel;

    public PageHeaderPanel(string title, string subtitle)
    {
        Dock = DockStyle.Top;
        Height = 76;
        BackColor = Color.White;
        Padding = new Padding(20, 14, 20, 8);

        _titleLabel = new Label
        {
            Text = title,
            Dock = DockStyle.Top,
            Height = 30,
            Font = AppTheme.Heading(15.5F),
            ForeColor = AppTheme.TextPrimary
        };

        _subtitleLabel = new Label
        {
            Text = subtitle,
            Dock = DockStyle.Top,
            Height = 22,
            Font = AppTheme.Body(9F),
            ForeColor = AppTheme.TextMuted
        };

        var separator = new Panel { Dock = DockStyle.Bottom, Height = 1, BackColor = AppTheme.Border };

        Controls.Add(_subtitleLabel);
        Controls.Add(_titleLabel);
        Controls.Add(separator);
    }

    public void UpdateSubtitle(string text) => _subtitleLabel.Text = text;
}
