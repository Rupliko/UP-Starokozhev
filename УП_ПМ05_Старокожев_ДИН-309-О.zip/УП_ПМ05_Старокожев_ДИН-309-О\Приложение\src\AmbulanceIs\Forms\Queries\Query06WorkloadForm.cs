﻿using AmbulanceIs.Common;
using AmbulanceIs.Domain;
using AmbulanceIs.Forms.Base;
using AmbulanceIs.Services;

namespace AmbulanceIs.Forms.Queries;

/// <summary>Запрос 6: выработка сотрудников — среднее число выездов в сутки.</summary>
public class Query06WorkloadForm : QueryFormBase
{
    private readonly DateTimePicker _fromPicker = new() { Format = DateTimePickerFormat.Short };
    private readonly DateTimePicker _toPicker = new() { Format = DateTimePickerFormat.Short };
    private readonly FilterCombo _categoryCombo = new();
    private readonly FilterCombo _employeeCombo = new();

    public Query06WorkloadForm(DataStore store)
        : base(store, "Выработка сотрудников",
            "Среднее число выездов в сутки за период для конкретного врача или фельдшера либо всех сотрудников категории")
    {
        var (from, to) = DefaultPeriod();
        _fromPicker.Value = from;
        _toPicker.Value = to;
        _categoryCombo.Fill([(0, "Врачи"), (1, "Фельдшеры")]);
        _employeeCombo.Fill(EmployeeOptions(EmployeeCategory.Doctor, "Все сотрудники категории"));
        _categoryCombo.SelectedIndexChanged += (_, _) => RefreshEmployees();
    }

    private void RefreshEmployees()
    {
        var category = (EmployeeCategory?)_categoryCombo.SelectedValue;
        _employeeCombo.Fill(EmployeeOptions(category, "Все сотрудники категории"));
    }

    protected override void BuildFilters(FlowLayoutPanel host)
    {
        AddFilter(host, "Период с", _fromPicker, 150);
        AddFilter(host, "по", _toPicker, 150);
        AddFilter(host, "Категория", _categoryCombo, 150);
        AddFilter(host, "Сотрудник", _employeeCombo, 260);
    }

    protected override QueryResult Execute()
    {
        var (from, to) = ValidatePeriod(_fromPicker, _toPicker);
        var category = _categoryCombo.SelectedValue is int value ? (EmployeeCategory)value : EmployeeCategory.Doctor;
        return Service.GetWorkload(from, to, category, _employeeCombo.SelectedValue);
    }
}
