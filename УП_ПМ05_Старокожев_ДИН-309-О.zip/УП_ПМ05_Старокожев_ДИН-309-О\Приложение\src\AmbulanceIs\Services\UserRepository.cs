﻿using AmbulanceIs.Domain;

namespace AmbulanceIs.Services;

/// <summary>Хранилище учётных записей. На этапе макетирования данные хранятся в программном коде.</summary>
public class UserRepository
{
    private readonly List<UserAccount> _accounts =
    [
        new UserAccount { Login = "admin", Password = "Admin2026", Role = UserRole.Administrator, FullName = "Сидоров Алексей Петрович" },
        new UserAccount { Login = "dispatcher", Password = "Disp2026", Role = UserRole.Dispatcher, FullName = "Ковалёва Ирина Сергеевна" },
        new UserAccount { Login = "feldsher", Password = "Feld2026", Role = UserRole.Dispatcher, FullName = "Гордеев Артём Павлович" }
    ];

    public IReadOnlyList<UserAccount> Accounts => _accounts;

    public UserAccount? Find(string login) =>
        _accounts.FirstOrDefault(account => string.Equals(account.Login, login.Trim(), StringComparison.OrdinalIgnoreCase));

    public bool LoginExists(string login, UserAccount? except = null) =>
        _accounts.Any(account => account != except &&
                                 string.Equals(account.Login, login.Trim(), StringComparison.OrdinalIgnoreCase));

    public void Add(UserAccount account) => _accounts.Add(account);

    public void Remove(UserAccount account) => _accounts.Remove(account);
}
