﻿using AmbulanceIs.Common;
using AmbulanceIs.Domain;
using AmbulanceIs.Forms.Base;
using AmbulanceIs.Services;

namespace AmbulanceIs.Forms.Queries;

/// <summary>Запрос 5: среднее время прибытия бригады на вызов за период.</summary>
public class Query05ArrivalForm : QueryFormBase
{
    private readonly DateTimePicker _fromPicker = new() { Format = DateTimePickerFormat.Short };
    private readonly DateTimePicker _toPicker = new() { Format = DateTimePickerFormat.Short };
    private readonly FilterCombo _crewCombo = new();
    private readonly FilterCombo _stationCombo = new();

    public Query05ArrivalForm(DataStore store)
        : base(store, "Среднее время прибытия",
            "Среднее время прибытия бригады на вызов за указанный период для бригады, подстанции либо всей службы")
    {
        var (from, to) = DefaultPeriod();
        _fromPicker.Value = from;
        _toPicker.Value = to;
        _crewCombo.Fill(CrewOptions());
        _stationCombo.Fill(StationOptions());
    }

    protected override void BuildFilters(FlowLayoutPanel host)
    {
        AddFilter(host, "Период с", _fromPicker, 150);
        AddFilter(host, "по", _toPicker, 150);
        AddFilter(host, "Бригада", _crewCombo, 240);
        AddFilter(host, "Подстанция", _stationCombo, 220);
    }

    protected override QueryResult Execute()
    {
        var (from, to) = ValidatePeriod(_fromPicker, _toPicker);
        return Service.GetAverageArrival(from, to, _crewCombo.SelectedValue, _stationCombo.SelectedValue);
    }
}
