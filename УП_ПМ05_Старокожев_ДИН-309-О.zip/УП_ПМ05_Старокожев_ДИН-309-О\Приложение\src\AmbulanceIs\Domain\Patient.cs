﻿namespace AmbulanceIs.Domain;

/// <summary>Пациент службы скорой помощи.</summary>
public class Patient
{
    public int Id { get; set; }

    public string FullName { get; set; } = string.Empty;

    public Sex Sex { get; set; }

    public int Age { get; set; }

    public string District { get; set; } = string.Empty;

    public string PolicyNumber { get; set; } = string.Empty;

    public string SexName => Sex.ToRussian();

    public override string ToString() => FullName;
}
