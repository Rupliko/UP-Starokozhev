﻿using AmbulanceIs.Common;
using AmbulanceIs.Domain;
using AmbulanceIs.Forms.Base;
using AmbulanceIs.Services;

namespace AmbulanceIs.Forms.References;

/// <summary>Окно справочника выездных бригад.</summary>
public class CrewForm : EntityForm<Crew>
{
    private readonly TextBox _numberBox = AppTheme.CreateTextBox();
    private readonly ComboBox _typeBox = AppTheme.CreateComboBox();
    private readonly ComboBox _substationBox = AppTheme.CreateComboBox();
    private readonly ComboBox _vehicleBox = AppTheme.CreateComboBox();
    private readonly CheckBox _onDutyBox = new() { Text = "Бригада на дежурстве", Font = AppTheme.Body(10F), AutoSize = true };

    public CrewForm(DataStore store)
        : base(store, "Выездные бригады", "Справочник бригад: тип, подстанция, закреплённый автомобиль и состояние дежурства")
    {
        _typeBox.Items.AddRange(["Фельдшерская", "Врачебная"]);
        foreach (var substation in store.Substations)
        {
            _substationBox.Items.Add(substation);
        }

        foreach (var vehicle in store.Vehicles)
        {
            _vehicleBox.Items.Add(vehicle);
        }
    }

    protected override string SearchPlaceholder => "Номер или тип бригады";

    protected override string EntityName => "Бригада";

    protected override void ConfigureColumns(DataGridView grid)
    {
        grid.AutoGenerateColumns = false;
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Номер бригады", DataPropertyName = nameof(Crew.Number), FillWeight = 90 });
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Тип", DataPropertyName = nameof(Crew.TypeName), FillWeight = 120 });
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Подстанция", DataPropertyName = nameof(Crew.SubstationName), FillWeight = 170 });
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Автомобиль", DataPropertyName = nameof(Crew.VehicleName), FillWeight = 140 });
        grid.Columns.Add(new DataGridViewCheckBoxColumn { HeaderText = "На дежурстве", DataPropertyName = nameof(Crew.IsOnDuty), FillWeight = 90 });
    }

    protected override void BuildEditor(FlowLayoutPanel host)
    {
        AddEditorRow(host, "Номер бригады *", _numberBox, "Например: 103");
        AddEditorRow(host, "Тип бригады *", _typeBox);
        AddEditorRow(host, "Подстанция *", _substationBox);
        AddEditorRow(host, "Закреплённый автомобиль *", _vehicleBox);
        _onDutyBox.Margin = new Padding(0, 8, 0, 4);
        host.Controls.Add(_onDutyBox);
    }

    protected override void ClearEditor()
    {
        _numberBox.Clear();
        _typeBox.SelectedIndex = -1;
        _substationBox.SelectedIndex = -1;
        _vehicleBox.SelectedIndex = -1;
        _onDutyBox.Checked = false;
    }

    protected override Crew CreateEntity()
    {
        if (_numberBox.Text.Trim().Length == 0)
        {
            throw new InputValidationException("Поле «Номер бригады» обязательно для заполнения.");
        }

        if (_typeBox.SelectedIndex < 0)
        {
            throw new InputValidationException("Выберите тип бригады из выпадающего списка.");
        }

        if (_substationBox.SelectedItem is not Substation substation)
        {
            throw new InputValidationException("Выберите подстанцию, к которой относится бригада.");
        }

        if (_vehicleBox.SelectedItem is not Vehicle vehicle)
        {
            throw new InputValidationException("Выберите автомобиль, закреплённый за бригадой на время дежурства.");
        }

        return new Crew
        {
            Id = Store.Crews.Count == 0 ? 1 : Store.Crews.Max(item => item.Id) + 1,
            Number = _numberBox.Text.Trim(),
            Type = (CrewType)_typeBox.SelectedIndex,
            SubstationId = substation.Id,
            VehicleId = vehicle.Id,
            IsOnDuty = _onDutyBox.Checked
        };
    }

    protected override void FillEditor(Crew item)
    {
        _numberBox.Text = item.Number;
        _typeBox.SelectedIndex = (int)item.Type;
        _substationBox.SelectedItem = Store.Substations.FirstOrDefault(substation => substation.Id == item.SubstationId);
        _vehicleBox.SelectedItem = Store.Vehicles.FirstOrDefault(vehicle => vehicle.Id == item.VehicleId);
        _onDutyBox.Checked = item.IsOnDuty;
    }

    protected override IReadOnlyList<Crew> LoadItems()
    {
        foreach (var crew in Store.Crews)
        {
            crew.SubstationName = Store.Substations.FirstOrDefault(substation => substation.Id == crew.SubstationId)?.ToString() ?? "—";
            var vehicle = Store.Vehicles.FirstOrDefault(item => item.Id == crew.VehicleId);
            crew.VehicleName = vehicle is null ? "не закреплён" : $"{vehicle.Brand} {vehicle.PlateNumber}";
        }

        return Store.Crews;
    }

    protected override void EditExisting(Crew? current, Crew updated)
    {
        if (current is null)
        {
            return;
        }

        current.Number = updated.Number;
        current.Type = updated.Type;
        current.SubstationId = updated.SubstationId;
        current.VehicleId = updated.VehicleId;
        current.IsOnDuty = updated.IsOnDuty;
    }

    protected override void PersistNew(Crew entity) => Store.Crews.Add(entity);

    protected override void PersistDelete(Crew entity) => Store.Crews.Remove(entity);

    protected override bool MatchesSearch(Crew item, string query) =>
        item.Number.Contains(query, StringComparison.OrdinalIgnoreCase) ||
        item.TypeName.Contains(query, StringComparison.OrdinalIgnoreCase);
}
