﻿using AmbulanceIs.Common;
using AmbulanceIs.Domain;
using AmbulanceIs.Forms.Base;
using AmbulanceIs.Services;

namespace AmbulanceIs.Forms.Queries;

/// <summary>Запрос 8: пациенты, которым оказана помощь бригадой или врачом за период.</summary>
public class Query08ServedPatientsForm : QueryFormBase
{
    private readonly DateTimePicker _fromPicker = new() { Format = DateTimePickerFormat.Short };
    private readonly DateTimePicker _toPicker = new() { Format = DateTimePickerFormat.Short };
    private readonly FilterCombo _crewCombo = new();
    private readonly FilterCombo _doctorCombo = new();

    public Query08ServedPatientsForm(DataStore store)
        : base(store, "Пациенты, которым оказана помощь",
            "Перечень пациентов с указанием диагноза и результата вызова за выбранный промежуток времени")
    {
        var (from, to) = DefaultPeriod();
        _fromPicker.Value = from;
        _toPicker.Value = to;
        _crewCombo.Fill(CrewOptions());
        _doctorCombo.Fill(EmployeeOptions(EmployeeCategory.Doctor, "Все врачи"));
    }

    protected override void BuildFilters(FlowLayoutPanel host)
    {
        AddFilter(host, "Период с", _fromPicker, 150);
        AddFilter(host, "по", _toPicker, 150);
        AddFilter(host, "Бригада", _crewCombo, 230);
        AddFilter(host, "Врач", _doctorCombo, 240);
    }

    protected override QueryResult Execute()
    {
        var (from, to) = ValidatePeriod(_fromPicker, _toPicker);
        return Service.GetServedPatients(from, to, _crewCombo.SelectedValue, _doctorCombo.SelectedValue);
    }
}
