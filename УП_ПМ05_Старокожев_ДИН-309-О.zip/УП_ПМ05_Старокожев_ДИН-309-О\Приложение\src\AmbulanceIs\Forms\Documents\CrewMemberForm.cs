﻿using AmbulanceIs.Common;
using AmbulanceIs.Domain;
using AmbulanceIs.Forms.Base;
using AmbulanceIs.Services;

namespace AmbulanceIs.Forms.Documents;

/// <summary>Окно учёта состава бригад: вхождение сотрудников в бригаду на период дежурства.</summary>
public class CrewMemberForm : EntityForm<CrewMemberForm.MemberRow>
{
    private static readonly string[] Roles = ["Врач бригады", "Фельдшер-бригадир", "Фельдшер", "Медицинская сестра", "Водитель"];

    private readonly ComboBox _crewBox = AppTheme.CreateComboBox();
    private readonly ComboBox _employeeBox = AppTheme.CreateComboBox();
    private readonly ComboBox _roleBox = AppTheme.CreateComboBox();
    private readonly DateTimePicker _fromPicker = new() { Format = DateTimePickerFormat.Long, Width = 300 };
    private readonly DateTimePicker _toPicker = new() { Format = DateTimePickerFormat.Long, Width = 300 };
    private readonly CheckBox _noEndBox = new() { Text = "Состав действует по настоящее время", AutoSize = true, Font = AppTheme.Body(9F) };

    public CrewMemberForm(DataStore store)
        : base(store, "Состав выездных бригад", "Закрепление сотрудников за бригадами с указанием роли и периода дежурства")
    {
        foreach (var crew in store.Crews)
        {
            _crewBox.Items.Add(crew);
        }

        foreach (var employee in store.Employees.OrderBy(employee => employee.FullName))
        {
            _employeeBox.Items.Add(employee);
        }

        _roleBox.Items.AddRange(Roles);
        _noEndBox.Checked = true;
        _noEndBox.CheckedChanged += (_, _) => _toPicker.Enabled = !_noEndBox.Checked;
    }

    /// <summary>Строка таблицы состава бригады.</summary>
    public class MemberRow
    {
        public required CrewMember Member { get; init; }

        public required string CrewName { get; init; }

        public required string EmployeeName { get; init; }

        public required string Role { get; init; }

        public DateTime DateFrom => Member.DateFrom;

        public string DateTo => Member.DateTo is null ? "по настоящее время" : Member.DateTo.Value.ToString("dd.MM.yyyy");
    }

    protected override string SearchPlaceholder => "Сотрудник или номер бригады";

    protected override string EntityName => "Запись состава";

    protected override void ConfigureColumns(DataGridView grid)
    {
        grid.AutoGenerateColumns = false;
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Бригада", DataPropertyName = nameof(MemberRow.CrewName), FillWeight = 170 });
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Сотрудник", DataPropertyName = nameof(MemberRow.EmployeeName), FillWeight = 220 });
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Роль в бригаде", DataPropertyName = nameof(MemberRow.Role), FillWeight = 140 });
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "В составе с", DataPropertyName = nameof(MemberRow.DateFrom), FillWeight = 100 });
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "По", DataPropertyName = nameof(MemberRow.DateTo), FillWeight = 120 });
    }

    protected override void BuildEditor(FlowLayoutPanel host)
    {
        AddEditorRow(host, "Бригада *", _crewBox);
        AddEditorRow(host, "Сотрудник *", _employeeBox);
        AddEditorRow(host, "Роль в бригаде *", _roleBox);
        AddEditorRow(host, "Дата включения в состав *", _fromPicker);
        AddEditorRow(host, "Дата исключения", _toPicker);
        _noEndBox.Margin = new Padding(0, 4, 0, 4);
        host.Controls.Add(_noEndBox);
    }

    protected override void ClearEditor()
    {
        _crewBox.SelectedIndex = -1;
        _employeeBox.SelectedIndex = -1;
        _roleBox.SelectedIndex = -1;
        _fromPicker.Value = DateTime.Today;
        _toPicker.Value = DateTime.Today;
        _noEndBox.Checked = true;
    }

    protected override MemberRow CreateEntity()
    {
        if (_crewBox.SelectedItem is not Crew crew)
        {
            throw new InputValidationException("Выберите бригаду из выпадающего списка.");
        }

        if (_employeeBox.SelectedItem is not Employee employee)
        {
            throw new InputValidationException("Выберите сотрудника, включаемого в состав бригады.");
        }

        if (_roleBox.SelectedIndex < 0)
        {
            throw new InputValidationException("Выберите роль сотрудника в бригаде.");
        }

        if (!_noEndBox.Checked && _toPicker.Value.Date < _fromPicker.Value.Date)
        {
            throw new InputValidationException("Дата исключения из состава не может быть раньше даты включения.");
        }

        var member = new CrewMember
        {
            CrewId = crew.Id,
            EmployeeId = employee.Id,
            RoleInCrew = _roleBox.SelectedItem!.ToString()!,
            DateFrom = _fromPicker.Value.Date,
            DateTo = _noEndBox.Checked ? null : _toPicker.Value.Date
        };

        return ToRow(member);
    }

    protected override void FillEditor(MemberRow item)
    {
        _crewBox.SelectedItem = Store.Crews.FirstOrDefault(crew => crew.Id == item.Member.CrewId);
        _employeeBox.SelectedItem = Store.Employees.FirstOrDefault(employee => employee.Id == item.Member.EmployeeId);
        _roleBox.SelectedItem = item.Member.RoleInCrew;
        _fromPicker.Value = item.Member.DateFrom;
        _noEndBox.Checked = item.Member.DateTo is null;
        _toPicker.Value = item.Member.DateTo ?? DateTime.Today;
    }

    protected override IReadOnlyList<MemberRow> LoadItems() => Store.CrewMembers.Select(ToRow).ToList();

    protected override void EditExisting(MemberRow? current, MemberRow updated)
    {
        if (current is null)
        {
            return;
        }

        current.Member.CrewId = updated.Member.CrewId;
        current.Member.EmployeeId = updated.Member.EmployeeId;
        current.Member.RoleInCrew = updated.Member.RoleInCrew;
        current.Member.DateFrom = updated.Member.DateFrom;
        current.Member.DateTo = updated.Member.DateTo;
    }

    protected override void PersistNew(MemberRow entity) => Store.CrewMembers.Add(entity.Member);

    protected override void PersistDelete(MemberRow entity) => Store.CrewMembers.Remove(entity.Member);

    protected override bool MatchesSearch(MemberRow item, string query) =>
        item.EmployeeName.Contains(query, StringComparison.OrdinalIgnoreCase) ||
        item.CrewName.Contains(query, StringComparison.OrdinalIgnoreCase);

    private MemberRow ToRow(CrewMember member)
    {
        var crew = Store.Crews.FirstOrDefault(item => item.Id == member.CrewId);
        var employee = Store.Employees.FirstOrDefault(item => item.Id == member.EmployeeId);
        return new MemberRow
        {
            Member = member,
            CrewName = crew is null ? "—" : $"Бригада №{crew.Number}",
            EmployeeName = employee?.FullName ?? "—",
            Role = member.RoleInCrew
        };
    }
}
