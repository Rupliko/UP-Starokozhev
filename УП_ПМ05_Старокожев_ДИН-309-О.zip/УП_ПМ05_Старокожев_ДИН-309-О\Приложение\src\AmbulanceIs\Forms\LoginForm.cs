﻿using AmbulanceIs.Common;
using AmbulanceIs.Controls;
using AmbulanceIs.Domain;
using AmbulanceIs.Services;

namespace AmbulanceIs.Forms;

/// <summary>Окно авторизации зарегистрированных пользователей с интерактивной капчей-пазлом.</summary>
public class LoginForm : Form
{
    private readonly AuthenticationService _authenticationService;
    private readonly UserRepository _repository;

    private readonly TextBox _loginTextBox;
    private readonly TextBox _passwordTextBox;
    private readonly CheckBox _showPasswordCheckBox;
    private readonly Label _errorLabel;
    private readonly Button _loginButton;
    private readonly Button _exitButton;
    private readonly TableLayoutPanel _captchaPanel;
    private readonly ToolTip _toolTip = new()
    {
        AutoPopDelay = 9000,
        InitialDelay = 400,
        ReshowDelay = 200,
        ShowAlways = true
    };
    private readonly CaptchaPuzzleControl _captcha;

    private UserAccount? _pendingAccount;

    public LoginForm(AuthenticationService authenticationService, UserRepository repository)
    {
        _authenticationService = authenticationService;
        _repository = repository;

        Text = "АИС «Скорая помощь» — вход в систему";
        StartPosition = FormStartPosition.CenterScreen;
        FormBorderStyle = FormBorderStyle.FixedSingle;
        MaximizeBox = false;
        ClientSize = new Size(1000, 660);
        MinimumSize = new Size(1016, 699);
        BackColor = Color.White;
        Font = AppTheme.Body();

        var brandPanel = CreateBrandPanel();
        var contentPanel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(48, 40, 48, 24), AutoScroll = true };
        var layout = new TableLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink,
            ColumnCount = 1,
            RowCount = 13,
            BackColor = Color.Transparent
        };
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

        var heading = new Label
        {
            Text = "Вход в систему",
            AutoSize = true,
            Font = AppTheme.Heading(19F),
            ForeColor = AppTheme.TextPrimary,
            Margin = new Padding(0, 0, 0, 4)
        };

        var subtitle = new Label
        {
            Text = "Введите учётные данные, выданные администратором системы",
            AutoSize = true,
            Font = AppTheme.Body(9.5F),
            ForeColor = AppTheme.TextMuted,
            Margin = new Padding(0, 0, 0, 22)
        };

        _loginTextBox = AppTheme.CreateTextBox(380);
        _loginTextBox.Dock = DockStyle.Fill;
        _loginTextBox.PlaceholderText = "Например: dispatcher";
        _loginTextBox.TabIndex = 0;

        _passwordTextBox = AppTheme.CreateTextBox(380);
        _passwordTextBox.Dock = DockStyle.Fill;
        _passwordTextBox.UseSystemPasswordChar = true;
        _passwordTextBox.PlaceholderText = "Введите пароль";
        _passwordTextBox.TabIndex = 1;

        _showPasswordCheckBox = new CheckBox
        {
            Text = "Показать пароль",
            AutoSize = true,
            Font = AppTheme.Body(9F),
            ForeColor = AppTheme.TextMuted,
            Margin = new Padding(0, 0, 0, 10),
            TabIndex = 2
        };
        _showPasswordCheckBox.CheckedChanged += (_, _) =>
            _passwordTextBox.UseSystemPasswordChar = !_showPasswordCheckBox.Checked;

        _errorLabel = new Label
        {
            AutoSize = false,
            Height = 46,
            Dock = DockStyle.Fill,
            ForeColor = AppTheme.Accent,
            Font = AppTheme.Body(9.25F),
            Text = string.Empty,
            Margin = new Padding(0, 0, 0, 8)
        };

        _loginButton = AppTheme.CreatePrimaryButton("Войти", 160);
        _loginButton.TabIndex = 3;
        _loginButton.Click += (_, _) => OnLoginClick();

        _exitButton = AppTheme.CreateSecondaryButton("Выход", 120);
        _exitButton.TabIndex = 4;
        _exitButton.Click += (_, _) =>
        {
            DialogResult = DialogResult.Cancel;
            Close();
        };

        var buttonsPanel = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            AutoSize = true,
            FlowDirection = FlowDirection.LeftToRight,
            Margin = new Padding(0, 4, 0, 0)
        };
        buttonsPanel.Controls.Add(_loginButton);
        buttonsPanel.Controls.Add(_exitButton);

        _captcha = new CaptchaPuzzleControl { Dock = DockStyle.Fill, Visible = true };

        var captchaButtons = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            AutoSize = true,
            FlowDirection = FlowDirection.LeftToRight,
            Margin = new Padding(0, 4, 0, 0)
        };

        var captchaTitle = new Label
        {
            Text = "Соберите картинку из фрагментов",
            Dock = DockStyle.Fill,
            AutoSize = false,
            Height = 26,
            Font = AppTheme.SubHeading(10F),
            ForeColor = AppTheme.Primary,
            Margin = new Padding(0, 0, 0, 4)
        };

        _captchaPanel = new TableLayoutPanel
        {
            Dock = DockStyle.Top,
            Height = 358,
            ColumnCount = 1,
            RowCount = 3,
            Visible = false,
            Margin = new Padding(0, 12, 0, 0),
            Padding = new Padding(0)
        };
        _captchaPanel.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        _captchaPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 28));
        _captchaPanel.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        _captchaPanel.RowStyles.Add(new RowStyle(SizeType.Absolute, 4));

        _captchaPanel.Controls.Add(captchaTitle, 0, 0);
        _captchaPanel.Controls.Add(_captcha, 0, 1);
        _captchaPanel.Controls.Add(captchaButtons, 0, 2);

        var credentialsPanel = new Panel
        {
            Dock = DockStyle.Fill,
            BackColor = Color.FromArgb(246, 248, 251),
            Padding = new Padding(12, 8, 12, 8),
            Margin = new Padding(0, 10, 0, 0),
            AutoSize = true,
            AutoSizeMode = AutoSizeMode.GrowAndShrink
        };

        var credentialsLabel = new Label
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            Font = AppTheme.Body(8.5F),
            ForeColor = AppTheme.TextMuted,
            Text = "Учётные записи для входа:\r\n" +
                   "admin / Admin2026 — администратор (без капчи)\r\n" +
                   "dispatcher / Disp2026, feldsher / Feld2026 — пользователь (с капчей)"
        };
        credentialsPanel.Controls.Add(credentialsLabel);

        layout.Controls.Add(heading, 0, 0);
        layout.Controls.Add(subtitle, 0, 1);
        layout.Controls.Add(AppTheme.CreateFieldLabel("Логин *"), 0, 2);
        layout.Controls.Add(_loginTextBox, 0, 3);
        layout.Controls.Add(AppTheme.CreateFieldLabel("Пароль *"), 0, 4);
        layout.Controls.Add(_passwordTextBox, 0, 5);
        layout.Controls.Add(_showPasswordCheckBox, 0, 6);
        layout.Controls.Add(_errorLabel, 0, 7);
        layout.Controls.Add(buttonsPanel, 0, 8);
        layout.Controls.Add(credentialsPanel, 0, 9);
        layout.Controls.Add(_captchaPanel, 0, 10);

        contentPanel.Controls.Add(layout);
        Controls.Add(contentPanel);
        Controls.Add(brandPanel);

        AcceptButton = _loginButton;
        CancelButton = _exitButton;

        _toolTip.SetToolTip(_loginTextBox, "Логин учётной записи, выданный администратором (регистр букв не важен)");
        _toolTip.SetToolTip(_passwordTextBox, "Пароль выдаётся администратором и учитывает регистр букв");
        _toolTip.SetToolTip(_showPasswordCheckBox, "Показывает введённый пароль, чтобы проверить раскладку клавиатуры");
        _toolTip.SetToolTip(_loginButton, "Проверить логин и пароль. Для роли «Пользователь» далее потребуется собрать капчу");
        _toolTip.SetToolTip(_exitButton, "Закрыть приложение");
        _toolTip.SetToolTip(_captcha, "Перетащите фрагменты в ячейки так, чтобы получилось целое изображение," +
                                      " или выберите фрагмент щелчком и укажите ячейку");

        Shown += (_, _) => _passwordTextBox.Focus();
    }

    /// <summary>Авторизованный пользователь; заполняется после успешного входа.</summary>
    public UserAccount? AuthenticatedUser { get; private set; }

    private Panel CreateBrandPanel()
    {
        var panel = new Panel { Dock = DockStyle.Left, Width = 392, BackColor = AppTheme.Primary, Padding = new Padding(40, 44, 32, 32) };

        var logo = new Panel { Dock = DockStyle.Top, Height = 74, BackColor = Color.Transparent };
        logo.Paint += (_, e) =>
        {
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            using var brush = new SolidBrush(Color.White);
            var center = new Point(28, 28);
            e.Graphics.FillRectangle(brush, center.X - 5, center.Y - 22, 10, 44);
            e.Graphics.FillRectangle(brush, center.X - 22, center.Y - 5, 44, 10);
        };

        var caption = new Label
        {
            Text = "СЛУЖБА СКОРОЙ\nМЕДИЦИНСКОЙ ПОМОЩИ",
            Dock = DockStyle.Top,
            AutoSize = false,
            Height = 56,
            Font = AppTheme.Body(10F),
            ForeColor = Color.FromArgb(198, 219, 238),
            Padding = new Padding(66, 4, 0, 0)
        };

        var title = new Label
        {
            Text = "АИС «Скорая помощь»",
            Dock = DockStyle.Top,
            AutoSize = false,
            Height = 76,
            Font = AppTheme.Heading(16.5F),
            ForeColor = Color.White
        };

        var description = new Label
        {
            Text = "Автоматизированное рабочее место диспетчера\nи учёт работы выездных бригад",
            Dock = DockStyle.Top,
            AutoSize = false,
            Height = 60,
            Font = AppTheme.Body(10F),
            ForeColor = Color.FromArgb(212, 228, 242)
        };

        var footer = new Label
        {
            Text = "Версия 1.0\nОмск, 2026\n\nОмГУ им. Ф.М. Достоевского\nИнститут СПО и ДП",
            Dock = DockStyle.Bottom,
            AutoSize = false,
            Height = 110,
            Font = AppTheme.Body(8.75F),
            ForeColor = Color.FromArgb(174, 202, 226)
        };

        panel.Controls.Add(footer);
        panel.Controls.Add(description);
        panel.Controls.Add(title);
        panel.Controls.Add(caption);
        panel.Controls.Add(logo);
        return panel;
    }

    private void OnLoginClick()
    {
        _errorLabel.Text = string.Empty;

        if (_pendingAccount is not null)
        {
            VerifyCaptcha();
            return;
        }

        var result = _authenticationService.Authenticate(_loginTextBox.Text, _passwordTextBox.Text);
        switch (result.Status)
        {
            case AuthenticationStatus.EmptyCredentials:
                _errorLabel.Text = result.Message;
                Messages.ShowWarning(this, "Поля «Логин» и «Пароль» обязательны для заполнения. Введите учётные данные.", "Заполните обязательные поля");
                if (string.IsNullOrWhiteSpace(_loginTextBox.Text))
                {
                    _loginTextBox.Focus();
                }
                else
                {
                    _passwordTextBox.Focus();
                }

                return;

            case AuthenticationStatus.InvalidCredentials:
                _errorLabel.Text = result.Message;
                _passwordTextBox.Clear();
                _passwordTextBox.Focus();
                Messages.ShowError(this, result.Message, "Ошибка авторизации");
                return;

            case AuthenticationStatus.Blocked:
                _errorLabel.Text = result.Message;
                _passwordTextBox.Clear();
                Messages.ShowError(this, result.Message, "Доступ заблокирован");
                return;

            case AuthenticationStatus.CaptchaRequired:
                _pendingAccount = result.Account;
                ShowCaptchaPanel();
                Messages.ShowInfo(this,
                    "Учётные данные подтверждены. Для роли «Пользователь» необходимо собрать изображение из фрагментов.",
                    "Проверка «Я не робот»");
                return;

            case AuthenticationStatus.Success:
                CompleteLogin(result.Account!);
                return;
        }
    }

    private void ShowCaptchaPanel()
    {
        _captchaPanel.Visible = true;
        _loginButton.Text = "Проверить и войти";
        _loginTextBox.Enabled = false;
        _passwordTextBox.Enabled = false;
        _captcha.Reset();
        ClientSize = new Size(1000, 880);
    }

    private void VerifyCaptcha()
    {
        if (_pendingAccount is null)
        {
            return;
        }

        if (_captcha.IsSolved)
        {
            var success = _authenticationService.ConfirmSuccess(_pendingAccount);
            CompleteLogin(success.Account!);
            return;
        }

        var failure = _authenticationService.RegisterCaptchaFailure(_pendingAccount);
        _captcha.Reset();

        if (failure.Status == AuthenticationStatus.Blocked)
        {
            _pendingAccount = null;
            _captchaPanel.Visible = false;
            _loginButton.Text = "Войти";
            _loginTextBox.Enabled = true;
            _passwordTextBox.Enabled = true;
            _passwordTextBox.Clear();
            ClientSize = new Size(1000, 660);
            _errorLabel.Text = failure.Message;
            Messages.ShowError(this, failure.Message, "Доступ заблокирован");
            return;
        }

        _errorLabel.Text = failure.Message;
        Messages.ShowWarning(this,
            "Изображение собрано неверно. Расположите фрагменты так, чтобы получилась целая картинка. " + failure.Message,
            "Проверка «Я не робот»");
    }

    private void CompleteLogin(UserAccount account)
    {
        AuthenticatedUser = account;
        Messages.ShowInfo(this, Messages.AuthorizationSucceeded, "Вход выполнен");
        DialogResult = DialogResult.OK;
        Close();
    }

    /// <summary>Открывает панель капчи без проверки пароля (используется при демонстрации интерфейса).</summary>
    internal void ShowCaptchaForPreview(bool solved)
    {
        _captchaPanel.Visible = true;
        _loginButton.Text = "Проверить и войти";
        ClientSize = new Size(1000, 880);
        if (solved)
        {
            _captcha.SolveAutomatically();
        }
        else
        {
            _captcha.Reset();
        }
    }

    /// <summary>Показывает сообщение об ошибке в окне (используется при демонстрации интерфейса).</summary>
    internal void ShowErrorForPreview(string text)
    {
        _errorLabel.Text = text;
    }
}
