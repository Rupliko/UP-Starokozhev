﻿namespace AmbulanceIs.Domain;

/// <summary>Автомобиль автопарка службы скорой помощи.</summary>
public class Vehicle
{
    public int Id { get; set; }

    public string Brand { get; set; } = string.Empty;

    public string PlateNumber { get; set; } = string.Empty;

    public int ManufactureYear { get; set; }

    public VehicleType Type { get; set; }

    public int SubstationId { get; set; }

    public int MileageKm { get; set; }

    public string TypeName => Type.ToRussian();

    /// <summary>Название подстанции для отображения в таблице.</summary>
    public string SubstationName { get; set; } = string.Empty;

    public override string ToString() => $"{Brand} {PlateNumber}";
}
