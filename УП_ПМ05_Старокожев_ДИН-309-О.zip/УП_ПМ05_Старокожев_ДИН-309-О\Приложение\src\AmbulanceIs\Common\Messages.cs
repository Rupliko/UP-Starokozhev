﻿namespace AmbulanceIs.Common;

/// <summary>Единые тексты уведомлений и методы их показа с корректными заголовками и пиктограммами.</summary>
internal static class Messages
{
    public const string ApplicationTitle = "АИС «Скорая помощь» — Служба скорой медицинской помощи г. Омска";

    public const string AuthorizationFailed =
        "Вы ввели неверный логин или пароль. Пожалуйста, проверьте ещё раз введенные данные";

    public const string AccountBlocked = "Вы заблокированы. Обратитесь к администратору";
    public const string AuthorizationSucceeded = "Вы успешно авторизовались";

    public static void ShowError(IWin32Window? owner, string text, string title = "Ошибка ввода данных")
        => Show(owner, text, title, MessageBoxIcon.Error);

    public static void ShowWarning(IWin32Window? owner, string text, string title = "Предупреждение")
        => Show(owner, text, title, MessageBoxIcon.Warning);

    public static void ShowInfo(IWin32Window? owner, string text, string title = "Информация")
        => Show(owner, text, title, MessageBoxIcon.Information);

    public static bool Confirm(IWin32Window? owner, string text, string title = "Подтверждение действия")
        => MessageBox.Show(owner, text, title, MessageBoxButtons.YesNo, MessageBoxIcon.Question,
            MessageBoxDefaultButton.Button2) == DialogResult.Yes;

    private static void Show(IWin32Window? owner, string text, string title, MessageBoxIcon icon)
        => MessageBox.Show(owner, text, title, MessageBoxButtons.OK, icon, MessageBoxDefaultButton.Button1);
}
