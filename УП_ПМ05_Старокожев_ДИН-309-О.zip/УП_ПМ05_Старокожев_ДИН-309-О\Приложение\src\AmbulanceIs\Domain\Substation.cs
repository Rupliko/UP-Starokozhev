﻿namespace AmbulanceIs.Domain;

/// <summary>Подстанция скорой помощи, закреплённая за районом города.</summary>
public class Substation
{
    public int Id { get; set; }

    public string Number { get; set; } = string.Empty;

    public string District { get; set; } = string.Empty;

    public string Address { get; set; } = string.Empty;

    public string Phone { get; set; } = string.Empty;

    public override string ToString() => $"Подстанция №{Number} ({District})";
}
