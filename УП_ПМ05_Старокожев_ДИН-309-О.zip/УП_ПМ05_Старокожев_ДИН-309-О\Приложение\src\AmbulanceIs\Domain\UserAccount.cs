﻿namespace AmbulanceIs.Domain;

/// <summary>Учётная запись пользователя информационной системы.</summary>
public class UserAccount
{
    public string Login { get; set; } = string.Empty;

    public string Password { get; set; } = string.Empty;

    public UserRole Role { get; set; }

    public string FullName { get; set; } = string.Empty;

    public bool IsBlocked { get; set; }

    public int FailedAttempts { get; set; }

    public string RoleName => Role.ToRussian();

    public UserAccount Clone() => (UserAccount)MemberwiseClone();
}
