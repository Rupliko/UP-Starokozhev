﻿using System.ComponentModel;
using AmbulanceIs.Common;
using AmbulanceIs.Controls;
using AmbulanceIs.Domain;
using AmbulanceIs.Services;

namespace AmbulanceIs.Forms.Base;

/// <summary>Базовое окно справочника: табличная форма с панелью ввода и редактирования данных.</summary>
public abstract class EntityForm<T> : Form where T : class
{
    private readonly BindingList<T> _items = new();
    private readonly DataGridView _grid = new();
    private readonly Panel _editorPanel;
    private readonly FlowLayoutPanel _editorHost;
    private readonly ToolStrip _toolStrip;
    private readonly ToolStripButton _saveButton;
    private readonly ToolStripButton _cancelButton;
    private readonly PlaceholderTextBox _searchBox;
    private readonly StatusStrip _statusStrip;
    private readonly ToolStripStatusLabel _countLabel;
    private readonly ToolStripStatusLabel _modeLabel;
    private readonly Label _editorTitle;
    private readonly ToolStripStatusLabel _hintLabel;
    private readonly ToolTip _toolTip = new()
    {
        AutoPopDelay = 9000,
        InitialDelay = 400,
        ReshowDelay = 200,
        ShowAlways = true
    };

    private bool _isEditing;
    private bool _isNew;

    protected EntityForm(DataStore store, string title, string subtitle)
    {
        Store = store;

        Text = title;
        StartPosition = FormStartPosition.CenterParent;
        MinimumSize = new Size(1024, 640);
        ClientSize = new Size(1180, 720);
        BackColor = AppTheme.Surface;
        Font = AppTheme.Body();

        var header = new PageHeaderPanel(title, subtitle);

        _toolStrip = new ToolStrip
        {
            GripStyle = ToolStripGripStyle.Hidden,
            BackColor = Color.White,
            Renderer = new ToolStripProfessionalRenderer(),
            Padding = new Padding(12, 4, 12, 4),
            Height = 42
        };

        var addButton = new ToolStripButton("Добавить") { DisplayStyle = ToolStripItemDisplayStyle.Text, ToolTipText = "Добавить новую запись" };
        addButton.Click += (_, _) => StartAdd();
        var editButton = new ToolStripButton("Изменить") { DisplayStyle = ToolStripItemDisplayStyle.Text };
        editButton.Click += (_, _) => StartEdit();
        var deleteButton = new ToolStripButton("Удалить") { DisplayStyle = ToolStripItemDisplayStyle.Text };
        deleteButton.Click += (_, _) => DeleteSelected();
        var refreshButton = new ToolStripButton("Обновить") { DisplayStyle = ToolStripItemDisplayStyle.Text };
        refreshButton.Click += (_, _) => Reload();

        _saveButton = new ToolStripButton("Сохранить") { DisplayStyle = ToolStripItemDisplayStyle.Text, Enabled = false };
        _saveButton.Click += (_, _) => SaveEditor();
        _cancelButton = new ToolStripButton("Отмена") { DisplayStyle = ToolStripItemDisplayStyle.Text, Enabled = false };
        _cancelButton.Click += (_, _) => CancelEditor();

        _searchBox = new PlaceholderTextBox { Width = 260, Placeholder = SearchPlaceholder };
        _searchBox.TextChanged += (_, _) => ApplyFilter();
        var searchHost = new ToolStripControlHost(_searchBox)
        {
            AutoSize = false,
            Width = 266,
            Height = 25,
            Margin = new Padding(4, 3, 4, 3)
        };

        _toolStrip.Items.AddRange(new ToolStripItem[]
        {
            addButton, editButton, deleteButton, new ToolStripSeparator(), _saveButton, _cancelButton,
            new ToolStripSeparator(), refreshButton, new ToolStripLabel("Поиск:"), searchHost
        });

        _grid.Dock = DockStyle.Fill;
        AppTheme.StyleGrid(_grid);
        _grid.CellDoubleClick += (_, e) => { if (e.RowIndex >= 0) StartEdit(); };
        _grid.SelectionChanged += (_, _) => OnSelectionChanged();

        _editorTitle = AppTheme.CreateGroupHeader("Карточка записи");
        _editorTitle.Dock = DockStyle.Top;
        _editorTitle.Height = 28;
        _editorTitle.Padding = new Padding(12, 4, 0, 0);

        _editorHost = new FlowLayoutPanel
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false,
            AutoScroll = true,
            Padding = new Padding(12, 4, 12, 12),
            BackColor = Color.White
        };

        _editorPanel = new Panel
        {
            Dock = DockStyle.Right,
            Width = 360,
            BackColor = Color.White,
            Padding = new Padding(1, 0, 0, 0)
        };
        _editorPanel.Controls.Add(_editorHost);
        _editorPanel.Controls.Add(_editorTitle);

        var gridHost = new Panel { Dock = DockStyle.Fill, Padding = new Padding(16, 12, 16, 12), BackColor = AppTheme.Surface };
        gridHost.Controls.Add(_grid);

        _statusStrip = new StatusStrip { BackColor = Color.White, SizingGrip = false };
        _countLabel = new ToolStripStatusLabel("Записей: 0") { Spring = false };
        _hintLabel = new ToolStripStatusLabel
        {
            Spring = true,
            TextAlign = ContentAlignment.MiddleLeft,
            ForeColor = AppTheme.TextMuted,
            Text = "Двойной щелчок по строке открывает запись для изменения"
        };
        _modeLabel = new ToolStripStatusLabel
        {
            Spring = false,
            TextAlign = ContentAlignment.MiddleRight,
            ForeColor = AppTheme.TextMuted
        };
        _statusStrip.Items.Add(_countLabel);
        _statusStrip.Items.Add(new ToolStripStatusLabel("  |  "));
        _statusStrip.Items.Add(_hintLabel);
        _statusStrip.Items.Add(_modeLabel);

        Controls.Add(gridHost);
        Controls.Add(_editorPanel);
        Controls.Add(_toolStrip);
        Controls.Add(header);
        Controls.Add(_statusStrip);

        addButton.ToolTipText = "Создать новую запись: заполните карточку справа и нажмите «Сохранить»";
        editButton.ToolTipText = "Изменить запись, выбранную в таблице (или двойной щелчок по строке)";
        deleteButton.ToolTipText = "Удалить выбранную запись после подтверждения";
        refreshButton.ToolTipText = "Перечитать список записей";
        _saveButton.ToolTipText = "Проверить введённые значения и сохранить запись";
        _cancelButton.ToolTipText = "Отменить изменения и вернуть карточку в режим просмотра";
        _toolTip.SetToolTip(_searchBox, SearchPlaceholder);
        _toolTip.SetToolTip(_grid, "Выберите строку, чтобы увидеть значения в карточке справа");

        BuildEditor(_editorHost);
        ConfigureColumns(_grid);
        SetEditorEnabled(false);
        Load += (_, _) => Reload();
    }

    protected DataStore Store { get; }

    protected DataGridView Grid => _grid;

    protected abstract void ConfigureColumns(DataGridView grid);

    protected abstract void BuildEditor(FlowLayoutPanel host);

    protected abstract void ClearEditor();

    protected abstract T CreateEntity();

    protected abstract void FillEditor(T item);

    protected abstract IReadOnlyList<T> LoadItems();

    /// <summary>Подсказка в поле поиска: какие реквизиты можно вводить.</summary>
    protected virtual string SearchPlaceholder => "Поиск по таблице";

    protected virtual bool MatchesSearch(T item, string query) => true;

    protected virtual string EmptyHint => "Записи отсутствуют. База данных не подключена — используйте демонстрационный режим меню «Вид».";

    protected void Reload()
    {
        var items = LoadItems();
        _items.RaiseListChangedEvents = false;
        _items.Clear();
        foreach (var item in items)
        {
            _items.Add(item);
        }

        _items.RaiseListChangedEvents = true;
        _items.ResetBindings();
        ApplyFilter();
        UpdateStatus();
        CancelEditor();
    }

    private void ApplyFilter()
    {
        var query = _searchBox.Text.Trim();
        var filtered = query.Length == 0
            ? _items.ToList()
            : _items.Where(item => MatchesSearch(item, query)).ToList();

        _grid.DataSource = new BindingList<T>(filtered);
        UpdateStatus();
    }

    private void UpdateStatus()
    {
        _countLabel.Text = $"Записей: {_grid.Rows.Count}";
        _modeLabel.Text = Store.IsDemo
            ? "Демонстрационный набор данных"
            : "Собственные записи: данные сохраняются в файл";
    }

    protected T? SelectedItem => _grid.CurrentRow?.DataBoundItem as T;

    private void OnSelectionChanged()
    {
        if (_isEditing || SelectedItem is null)
        {
            return;
        }

        FillEditor(SelectedItem);
    }

    private void StartAdd()
    {
        _isEditing = true;
        _isNew = true;
        ClearEditor();
        SetEditorEnabled(true);
        _editorTitle.Text = "Новая запись";
        _grid.ClearSelection();
        FocusFirstEditorControl();
    }

    private void StartEdit()
    {
        var item = SelectedItem;
        if (item is null)
        {
            Messages.ShowWarning(this, "Выберите запись в таблице, которую требуется изменить.", "Запись не выбрана");
            return;
        }

        _isEditing = true;
        _isNew = false;
        FillEditor(item);
        SetEditorEnabled(true);
        _editorTitle.Text = "Редактирование записи";
        FocusFirstEditorControl();
    }

    private void SaveEditor()
    {
        try
        {
            var entity = CreateEntity();
            if (_isNew)
            {
                PersistNew(entity);
                SaveStore();
                Reload();
                Messages.ShowInfo(this, $"{EntityName} добавлен(а) в таблицу.", "Данные сохранены");
            }
            else
            {
                var current = SelectedItem;
                EditExisting(current, entity);
                SaveStore();
                Reload();
                Messages.ShowInfo(this, "Изменения сохранены.", "Данные сохранены");
            }

            _isEditing = false;
            SetEditorEnabled(false);
            _editorTitle.Text = "Карточка записи";
        }
        catch (InputValidationException exception)
        {
            Messages.ShowError(this, exception.Message, "Некорректные данные");
        }
    }

    /// <summary>Переносит значения из новой сущности в существующую запись списка.</summary>
    protected abstract void EditExisting(T? current, T updated);

    /// <summary>Добавляет новую запись в хранилище.</summary>
    protected abstract void PersistNew(T entity);

    /// <summary>Удаляет запись из хранилища.</summary>
    protected abstract void PersistDelete(T entity);

    private void CancelEditor()
    {
        _isEditing = false;
        SetEditorEnabled(false);
        _editorTitle.Text = "Карточка записи";
        if (SelectedItem is not null)
        {
            FillEditor(SelectedItem);
        }
        else
        {
            ClearEditor();
        }
    }

    private void DeleteSelected()
    {
        var item = SelectedItem;
        if (item is null)
        {
            Messages.ShowWarning(this, "Выберите запись в таблице, которую требуется удалить.", "Запись не выбрана");
            return;
        }

        if (!Messages.Confirm(this, $"Удалить запись «{DescribeForDelete(item)}»? Действие нельзя отменить.", "Удаление записи"))
        {
            return;
        }

        PersistDelete(item);
        SaveStore();
        Reload();
    }

    /// <summary>Сохраняет состояние хранилища в файл данных (автосохранение после изменения).</summary>
    protected void SaveStore()
    {
        if (StoreFile.TrySave(Store))
        {
            return;
        }

        Messages.ShowWarning(this,
            (StoreFile.LastError ?? "Не удалось сохранить данные в файл.") +
            Environment.NewLine + Environment.NewLine +
            "Данные остаются в памяти и будут доступны до закрытия приложения.",
            "Сохранение данных");
    }

    protected virtual string DescribeForDelete(T item) => item.ToString() ?? EntityName;

    /// <summary>Число записей в таблице (используется автоматическими проверками).</summary>
    internal int ItemCount => _items.Count;

    /// <summary>Добавляет запись через тот же путь, что и кнопка «Сохранить» (автоматическая проверка).</summary>
    internal void TestAdd(T entity)
    {
        PersistNew(entity);
        SaveStore();
        Reload();
    }

    /// <summary>Удаляет запись через тот же путь, что и кнопка «Удалить» (автоматическая проверка).</summary>
    internal void TestRemove(T entity)
    {
        PersistDelete(entity);
        SaveStore();
        Reload();
    }

    protected abstract string EntityName { get; }

    private void SetEditorEnabled(bool enabled)
    {
        foreach (Control control in _editorHost.Controls)
        {
            if (control is Label)
            {
                continue;
            }

            control.Enabled = enabled;
        }

        _saveButton.Enabled = enabled;
        _cancelButton.Enabled = enabled;
        _hintLabel.Text = enabled
            ? "Заполните поля и нажмите «Сохранить». Поля со знаком * обязательны"
            : "Двойной щелчок по строке открывает запись для изменения";
    }

    private void FocusFirstEditorControl()
    {
        foreach (Control control in _editorHost.Controls)
        {
            if (control.CanSelect && !(control is Label))
            {
                control.Focus();
                return;
            }
        }
    }

    /// <summary>Создаёт пару «подпись — элемент управления» для панели ввода.</summary>
    protected static void AddEditorRow(FlowLayoutPanel host, string label, Control control, string? hint = null)
    {
        var caption = new Label
        {
            Text = label,
            AutoSize = true,
            Font = AppTheme.Body(9F),
            ForeColor = AppTheme.TextMuted,
            Margin = new Padding(0, 6, 0, 2)
        };

        control.Width = 300;
        control.Margin = new Padding(0, 0, 0, hint is null ? 4 : 0);
        host.Controls.Add(caption);
        host.Controls.Add(control);

        if (hint is not null)
        {
            var hintLabel = new Label
            {
                Text = hint,
                AutoSize = false,
                Width = 300,
                Height = 18,
                Font = AppTheme.Body(8F),
                ForeColor = AppTheme.TextMuted,
                Margin = new Padding(0, 0, 0, 4)
            };
            host.Controls.Add(hintLabel);
        }
    }
}
