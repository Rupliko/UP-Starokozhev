﻿namespace AmbulanceIs.Common;

/// <summary>Выпадающий список для условий отбора, поддерживающий вариант «все значения».</summary>
public class FilterCombo : ComboBox
{
    private readonly List<int?> _values = new();

    public FilterCombo()
    {
        DropDownStyle = ComboBoxStyle.DropDownList;
        Font = AppTheme.Body(9.75F);
    }

    /// <summary>Заполняет список вариантами отбора; значение null означает «все записи».</summary>
    public void Fill(IEnumerable<(int? Value, string Text)> items, int selectedIndex = 0)
    {
        Items.Clear();
        _values.Clear();
        foreach (var (value, text) in items)
        {
            Items.Add(text);
            _values.Add(value);
        }

        if (Items.Count > 0)
        {
            SelectedIndex = Math.Min(selectedIndex, Items.Count - 1);
        }
    }

    /// <summary>Выбранное значение; null — условие не задано.</summary>
    public new int? SelectedValue => SelectedIndex >= 0 && SelectedIndex < _values.Count ? _values[SelectedIndex] : null;
}
