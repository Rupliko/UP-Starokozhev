﻿namespace AmbulanceIs.Domain;

/// <summary>Колонка результата запроса информационной системы.</summary>
public class QueryColumn
{
    public QueryColumn(string header, string propertyName, int weight = 100)
    {
        Header = header;
        PropertyName = propertyName;
        Weight = weight;
    }

    public string Header { get; }

    public string PropertyName { get; }

    public int Weight { get; }
}

/// <summary>Результат выполнения запроса: набор строк с описанием колонок.</summary>
public class QueryResult
{
    public List<QueryColumn> Columns { get; } = new();

    public List<Dictionary<string, object?>> Rows { get; } = new();

    public string Summary { get; set; } = string.Empty;

    public bool IsEmpty => Rows.Count == 0;

    public QueryResult AddColumn(string header, string propertyName, int weight = 100)
    {
        Columns.Add(new QueryColumn(header, propertyName, weight));
        return this;
    }

    public QueryResult AddRow(params (string Column, object? Value)[] values)
    {
        var row = new Dictionary<string, object?>();
        foreach (var (column, value) in values)
        {
            row[column] = value;
        }

        Rows.Add(row);
        return this;
    }
}
