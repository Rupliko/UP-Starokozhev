﻿using AmbulanceIs.Common;
using AmbulanceIs.Domain;
using AmbulanceIs.Forms.Base;
using AmbulanceIs.Services;

namespace AmbulanceIs.Forms.Queries;

/// <summary>Запрос 12: сведения об автопарке и пробеге автомобилей.</summary>
public class Query12FleetForm : QueryFormBase
{
    private readonly FilterCombo _stationCombo = new();
    private readonly FilterCombo _typeCombo = new();
    private readonly FilterCombo _vehicleCombo = new();

    public Query12FleetForm(DataStore store)
        : base(store, "Автопарк службы",
            "Распределение автомобилей по подстанциям и типам, данные о пробеге указанного автомобиля или категории")
    {
        _stationCombo.Fill(StationOptions());
        _typeCombo.Fill([(null, "Все типы"), (0, "Реанимобиль"), (1, "Линейный")]);
        _vehicleCombo.Fill(VehicleOptions());
    }

    protected override void BuildFilters(FlowLayoutPanel host)
    {
        AddFilter(host, "Подстанция", _stationCombo, 240);
        AddFilter(host, "Тип автомобиля", _typeCombo, 170);
        AddFilter(host, "Автомобиль", _vehicleCombo, 220);
    }

    protected override QueryResult Execute()
    {
        VehicleType? type = _typeCombo.SelectedValue is int value ? (VehicleType)value : null;
        return Service.GetFleet(_stationCombo.SelectedValue, type, _vehicleCombo.SelectedValue);
    }
}
