﻿using System.Drawing.Drawing2D;

namespace AmbulanceIs.Common;

/// <summary>Единая цветовая схема, шрифты и вспомогательные фабрики элементов интерфейса.</summary>
internal static class AppTheme
{
    public static readonly Color Primary = Color.FromArgb(12, 84, 140);
    public static readonly Color PrimaryDark = Color.FromArgb(8, 58, 98);
    public static readonly Color Accent = Color.FromArgb(208, 45, 60);
    public static readonly Color Surface = Color.FromArgb(248, 249, 251);
    public static readonly Color Border = Color.FromArgb(206, 213, 221);
    public static readonly Color TextPrimary = Color.FromArgb(32, 38, 46);
    public static readonly Color TextMuted = Color.FromArgb(104, 114, 128);
    public static readonly Color GridHeader = Color.FromArgb(232, 238, 245);
    public static readonly Color Success = Color.FromArgb(22, 122, 74);

    public static readonly string UiFamily = "Segoe UI";

    public static Font Heading(float size = 15F) => new(UiFamily, size, FontStyle.Bold);
    public static Font SubHeading(float size = 11F) => new(UiFamily, size, FontStyle.Bold);
    public static Font Body(float size = 9.75F) => new(UiFamily, size, FontStyle.Regular);

    /// <summary>Создаёт подпись поля ввода с единым оформлением.</summary>
    public static Label CreateFieldLabel(string text) => new()
    {
        Text = text,
        AutoSize = true,
        Font = Body(),
        ForeColor = TextPrimary,
        Margin = new Padding(0, 6, 8, 4)
    };

    /// <summary>Создаёт текстовое поле ввода с единым оформлением.</summary>
    public static TextBox CreateTextBox(int width = 240) => new()
    {
        Width = width,
        Font = Body(10.5F),
        BorderStyle = BorderStyle.FixedSingle,
        Margin = new Padding(0, 2, 0, 6)
    };

    /// <summary>Создаёт выпадающий список с единым оформлением.</summary>
    public static ComboBox CreateComboBox(int width = 240) => new()
    {
        Width = width,
        Font = Body(10.5F),
        DropDownStyle = ComboBoxStyle.DropDownList,
        Margin = new Padding(0, 2, 0, 6)
    };

    /// <summary>Создаёт основную кнопку окна.</summary>
    public static Button CreatePrimaryButton(string text, int width = 150) => new()
    {
        Text = text,
        Width = width,
        Height = 34,
        FlatStyle = FlatStyle.Flat,
        BackColor = Primary,
        ForeColor = Color.White,
        Font = SubHeading(10F),
        Cursor = Cursors.Hand,
        Margin = new Padding(0, 0, 10, 0)
    };

    /// <summary>Создаёт второстепенную кнопку окна.</summary>
    public static Button CreateSecondaryButton(string text, int width = 130) => new()
    {
        Text = text,
        Width = width,
        Height = 34,
        FlatStyle = FlatStyle.Flat,
        BackColor = Color.White,
        ForeColor = TextPrimary,
        Font = Body(10F),
        Cursor = Cursors.Hand,
        Margin = new Padding(0, 0, 10, 0)
    };

    /// <summary>Настраивает таблицу данных: оформление, поведение при изменении размера окна.</summary>
    public static void StyleGrid(DataGridView grid)
    {
        grid.BackgroundColor = Color.White;
        grid.BorderStyle = BorderStyle.None;
        grid.GridColor = Border;
        grid.Font = Body(9.75F);
        grid.RowHeadersVisible = false;
        grid.AllowUserToAddRows = false;
        grid.AllowUserToDeleteRows = false;
        grid.AllowUserToResizeRows = false;
        grid.ReadOnly = true;
        grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        grid.MultiSelect = false;
        grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        grid.ColumnHeadersHeight = 38;
        grid.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
        grid.RowTemplate.Height = 28;
        grid.EnableHeadersVisualStyles = false;
        grid.ColumnHeadersDefaultCellStyle.BackColor = GridHeader;
        grid.ColumnHeadersDefaultCellStyle.ForeColor = TextPrimary;
        grid.ColumnHeadersDefaultCellStyle.Font = SubHeading(9.5F);
        grid.ColumnHeadersDefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleLeft;
        grid.ColumnHeadersDefaultCellStyle.Padding = new Padding(6, 0, 6, 0);
        grid.DefaultCellStyle.Padding = new Padding(6, 0, 6, 0);
        grid.DefaultCellStyle.SelectionBackColor = Color.FromArgb(214, 231, 245);
        grid.DefaultCellStyle.SelectionForeColor = TextPrimary;
        grid.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(250, 251, 252);
    }

    /// <summary>Создаёт панель-разделитель с заголовком группы элементов.</summary>
    public static Label CreateGroupHeader(string text) => new()
    {
        Text = text,
        AutoSize = true,
        Font = SubHeading(10.5F),
        ForeColor = Primary,
        Margin = new Padding(0, 8, 0, 6)
    };

    /// <summary>Рисует скруглённую рамку вокруг панели.</summary>
    public static void ApplyRoundedBorder(Control control, Color borderColor, int radius = 8)
    {
        void Paint(object? sender, PaintEventArgs e)
        {
            using var pen = new Pen(borderColor);
            var path = CreateRoundedPath(new Rectangle(0, 0, control.Width - 1, control.Height - 1), radius);
            e.Graphics.SmoothingMode = SmoothingMode.AntiAlias;
            e.Graphics.DrawPath(pen, path);
        }

        control.Paint += Paint;
        control.Resize += (_, _) => control.Invalidate();
    }

    public static GraphicsPath CreateRoundedPath(Rectangle bounds, int radius)
    {
        var path = new GraphicsPath();
        var diameter = radius * 2;
        path.AddArc(bounds.X, bounds.Y, diameter, diameter, 180, 90);
        path.AddArc(bounds.Right - diameter, bounds.Y, diameter, diameter, 270, 90);
        path.AddArc(bounds.Right - diameter, bounds.Bottom - diameter, diameter, diameter, 0, 90);
        path.AddArc(bounds.X, bounds.Bottom - diameter, diameter, diameter, 90, 90);
        path.CloseFigure();
        return path;
    }
}
