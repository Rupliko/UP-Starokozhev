﻿namespace AmbulanceIs.Domain;

/// <summary>Пол пациента.</summary>
public enum Sex
{
    Male = 0,
    Female = 1
}

/// <summary>Отображаемые названия пола пациента.</summary>
public static class SexNames
{
    public static string ToRussian(this Sex sex) => sex == Sex.Male ? "Мужской" : "Женский";
}
