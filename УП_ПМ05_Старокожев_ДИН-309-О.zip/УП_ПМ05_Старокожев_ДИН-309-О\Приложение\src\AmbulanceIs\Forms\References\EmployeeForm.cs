﻿using AmbulanceIs.Common;
using AmbulanceIs.Domain;
using AmbulanceIs.Forms.Base;
using AmbulanceIs.Services;

namespace AmbulanceIs.Forms.References;

/// <summary>Окно справочника сотрудников службы скорой помощи.</summary>
public class EmployeeForm : EntityForm<Employee>
{
    private readonly TextBox _fullNameBox = AppTheme.CreateTextBox();
    private readonly ComboBox _categoryBox = AppTheme.CreateComboBox();
    private readonly ComboBox _specializationBox = AppTheme.CreateComboBox();
    private readonly NumericUpDown _experienceBox = CreateExperienceBox();
    private readonly ComboBox _substationBox = AppTheme.CreateComboBox();

    public EmployeeForm(DataStore store)
        : base(store, "Сотрудники службы", "Справочник персонала: категория, специализация, стаж и место работы")
    {
        _categoryBox.Items.AddRange(["Врач", "Фельдшер", "Медицинская сестра", "Водитель", "Диспетчер"]);
        _specializationBox.Items.AddRange(["Терапевт", "Кардиолог", "Педиатр", "Реаниматолог", "Хирург"]);
        foreach (var substation in store.Substations)
        {
            _substationBox.Items.Add(substation);
        }

        _categoryBox.SelectedIndexChanged += (_, _) =>
            _specializationBox.Enabled = _categoryBox.SelectedIndex == 0;
        if (_categoryBox.Items.Count > 0)
        {
            _categoryBox.SelectedIndex = 1;
        }
    }

    protected override string SearchPlaceholder => "ФИО или категория";

    protected override string EntityName => "Сотрудник";

    private static NumericUpDown CreateExperienceBox()
    {
        var box = new NumericUpDown { Minimum = 0, Maximum = 60, Font = AppTheme.Body(10F) };
        return box;
    }

    protected override void ConfigureColumns(DataGridView grid)
    {
        grid.AutoGenerateColumns = false;
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "ФИО", DataPropertyName = nameof(Employee.FullName), FillWeight = 190 });
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Категория", DataPropertyName = nameof(Employee.CategoryName), FillWeight = 120 });
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Специализация", DataPropertyName = nameof(Employee.SpecializationName), FillWeight = 110 });
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Стаж, лет", DataPropertyName = nameof(Employee.ExperienceYears), FillWeight = 70 });
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Подстанция", DataPropertyName = nameof(Employee.SubstationName), FillWeight = 150 });
    }

    protected override void BuildEditor(FlowLayoutPanel host)
    {
        AddEditorRow(host, "ФИО сотрудника *", _fullNameBox, "Фамилия Имя Отчество");
        AddEditorRow(host, "Категория *", _categoryBox);
        AddEditorRow(host, "Специализация", _specializationBox, "Заполняется только для врачей");
        AddEditorRow(host, "Стаж работы, лет *", _experienceBox);
        AddEditorRow(host, "Подстанция *", _substationBox);
    }

    protected override void ClearEditor()
    {
        _fullNameBox.Clear();
        _categoryBox.SelectedIndex = _categoryBox.Items.Count > 0 ? 0 : -1;
        _specializationBox.SelectedIndex = -1;
        _experienceBox.Value = 0;
        _substationBox.SelectedIndex = -1;
    }

    protected override Employee CreateEntity()
    {
        if (!InputValidator.TryParseFullName(_fullNameBox.Text, out var fullName, out var error))
        {
            throw new InputValidationException(error);
        }

        if (_categoryBox.SelectedIndex < 0)
        {
            throw new InputValidationException("Выберите категорию персонала из выпадающего списка.");
        }

        if (_substationBox.SelectedItem is not Substation substation)
        {
            throw new InputValidationException("Выберите подстанцию, на которой работает сотрудник.");
        }

        return new Employee
        {
            Id = Store.Employees.Count == 0 ? 1 : Store.Employees.Max(item => item.Id) + 1,
            FullName = fullName,
            Category = (EmployeeCategory)_categoryBox.SelectedIndex,
            Specialization = _specializationBox.SelectedIndex < 0 ? DoctorSpecialization.Therapist : (DoctorSpecialization)_specializationBox.SelectedIndex,
            ExperienceYears = (int)_experienceBox.Value,
            SubstationId = substation.Id
        };
    }

    protected override void FillEditor(Employee item)
    {
        _fullNameBox.Text = item.FullName;
        _categoryBox.SelectedIndex = (int)item.Category;
        _specializationBox.SelectedIndex = (int)item.Specialization;
        _experienceBox.Value = item.ExperienceYears;
        _substationBox.SelectedItem = Store.Substations.FirstOrDefault(substation => substation.Id == item.SubstationId);
    }

    protected override IReadOnlyList<Employee> LoadItems()
    {
        foreach (var employee in Store.Employees)
        {
            employee.SubstationName = Store.Substations.FirstOrDefault(substation => substation.Id == employee.SubstationId)?.ToString() ?? "—";
        }

        return Store.Employees;
    }

    protected override void EditExisting(Employee? current, Employee updated)
    {
        if (current is null)
        {
            return;
        }

        current.FullName = updated.FullName;
        current.Category = updated.Category;
        current.Specialization = updated.Specialization;
        current.ExperienceYears = updated.ExperienceYears;
        current.SubstationId = updated.SubstationId;
    }

    protected override void PersistNew(Employee entity) => Store.Employees.Add(entity);

    protected override void PersistDelete(Employee entity) => Store.Employees.Remove(entity);

    protected override bool MatchesSearch(Employee item, string query) =>
        item.FullName.Contains(query, StringComparison.OrdinalIgnoreCase) ||
        item.CategoryName.Contains(query, StringComparison.OrdinalIgnoreCase);
}
