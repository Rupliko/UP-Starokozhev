﻿namespace AmbulanceIs.Domain;

/// <summary>Выездная бригада подстанции с закреплённым автомобилем.</summary>
public class Crew
{
    public int Id { get; set; }

    public string Number { get; set; } = string.Empty;

    public CrewType Type { get; set; }

    public int SubstationId { get; set; }

    public int? VehicleId { get; set; }

    public bool IsOnDuty { get; set; }

    public string TypeName => Type.ToRussian();

    /// <summary>Название подстанции для отображения в таблице.</summary>
    public string SubstationName { get; set; } = string.Empty;

    /// <summary>Марка и номер закреплённого автомобиля.</summary>
    public string VehicleName { get; set; } = string.Empty;

    public override string ToString() => $"Бригада №{Number} ({TypeName})";
}
