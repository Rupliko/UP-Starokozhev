﻿namespace AmbulanceIs.Domain;

/// <summary>Категория срочности вызова.</summary>
public enum UrgencyCategory
{
    Emergency = 0,
    Urgent = 1
}

/// <summary>Отображаемые названия категорий срочности и нормативы времени прибытия.</summary>
public static class UrgencyCategoryNames
{
    public static string ToRussian(this UrgencyCategory category) => category switch
    {
        UrgencyCategory.Emergency => "Экстренный",
        UrgencyCategory.Urgent => "Неотложный",
        _ => "Не указана"
    };

    /// <summary>Нормативное время прибытия бригады, минут.</summary>
    public static int NormativeArrivalMinutes(this UrgencyCategory category)
        => category == UrgencyCategory.Emergency ? 20 : 40;
}
