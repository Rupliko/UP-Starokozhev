﻿namespace AmbulanceIs.Domain;

/// <summary>Сотрудник службы скорой медицинской помощи.</summary>
public class Employee
{
    public int Id { get; set; }

    public string FullName { get; set; } = string.Empty;

    public EmployeeCategory Category { get; set; }

    public DoctorSpecialization Specialization { get; set; }

    public int ExperienceYears { get; set; }

    public int SubstationId { get; set; }

    public string CategoryName => Category.ToRussian();

    /// <summary>Название подстанции для отображения в таблице.</summary>
    public string SubstationName { get; set; } = string.Empty;

    public string SpecializationName => Category == EmployeeCategory.Doctor
        ? Specialization.ToRussian()
        : "—";

    public override string ToString() => FullName;
}
