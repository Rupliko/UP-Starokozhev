﻿using AmbulanceIs.Common;
using AmbulanceIs.Domain;
using AmbulanceIs.Forms.Base;
using AmbulanceIs.Services;

namespace AmbulanceIs.Forms.References;

/// <summary>Окно справочника подстанций скорой помощи.</summary>
public class SubstationForm : EntityForm<Substation>
{
    private readonly TextBox _numberBox = AppTheme.CreateTextBox();
    private readonly TextBox _districtBox = AppTheme.CreateTextBox();
    private readonly TextBox _addressBox = AppTheme.CreateTextBox();
    private readonly TextBox _phoneBox = AppTheme.CreateTextBox();

    public SubstationForm(DataStore store)
        : base(store, "Подстанции скорой помощи", "Справочник подстанций: район обслуживания, адрес и контактный телефон")
    {
    }

    protected override string SearchPlaceholder => "Номер, район или адрес";

    protected override string EntityName => "Подстанция";

    protected override void ConfigureColumns(DataGridView grid)
    {
        grid.AutoGenerateColumns = false;
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "№ подстанции", DataPropertyName = nameof(Substation.Number), FillWeight = 60 });
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Район города", DataPropertyName = nameof(Substation.District), FillWeight = 110 });
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Адрес", DataPropertyName = nameof(Substation.Address), FillWeight = 170 });
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Телефон", DataPropertyName = nameof(Substation.Phone), FillWeight = 80 });
    }

    protected override void BuildEditor(FlowLayoutPanel host)
    {
        AddEditorRow(host, "Номер подстанции *", _numberBox, "Например: 5");
        AddEditorRow(host, "Район города *", _districtBox, "Например: Октябрьский");
        AddEditorRow(host, "Адрес *", _addressBox, "Улица, дом");
        AddEditorRow(host, "Телефон", _phoneBox, "Например: 78-05-12");
    }

    protected override void ClearEditor()
    {
        _numberBox.Clear();
        _districtBox.Clear();
        _addressBox.Clear();
        _phoneBox.Clear();
    }

    protected override Substation CreateEntity()
    {
        var number = _numberBox.Text.Trim();
        if (number.Length == 0)
        {
            throw new InputValidationException("Поле «Номер подстанции» обязательно для заполнения.");
        }

        if (_districtBox.Text.Trim().Length < 3)
        {
            throw new InputValidationException("Поле «Район города» должно содержать не менее 3 символов.");
        }

        if (_addressBox.Text.Trim().Length < 5)
        {
            throw new InputValidationException("Поле «Адрес» должно содержать не менее 5 символов, например: ул. Ленина, 12.");
        }

        return new Substation
        {
            Id = Store.Substations.Count == 0 ? 1 : Store.Substations.Max(item => item.Id) + 1,
            Number = number,
            District = _districtBox.Text.Trim(),
            Address = _addressBox.Text.Trim(),
            Phone = _phoneBox.Text.Trim()
        };
    }

    protected override void FillEditor(Substation item)
    {
        _numberBox.Text = item.Number;
        _districtBox.Text = item.District;
        _addressBox.Text = item.Address;
        _phoneBox.Text = item.Phone;
    }

    protected override IReadOnlyList<Substation> LoadItems() => Store.Substations;

    protected override void EditExisting(Substation? current, Substation updated)
    {
        if (current is null)
        {
            return;
        }

        current.Number = updated.Number;
        current.District = updated.District;
        current.Address = updated.Address;
        current.Phone = updated.Phone;
    }

    protected override void PersistNew(Substation entity) => Store.Substations.Add(entity);

    protected override void PersistDelete(Substation entity) => Store.Substations.Remove(entity);

    protected override bool MatchesSearch(Substation item, string query) =>
        item.Number.Contains(query, StringComparison.OrdinalIgnoreCase) ||
        item.District.Contains(query, StringComparison.OrdinalIgnoreCase) ||
        item.Address.Contains(query, StringComparison.OrdinalIgnoreCase);
}
