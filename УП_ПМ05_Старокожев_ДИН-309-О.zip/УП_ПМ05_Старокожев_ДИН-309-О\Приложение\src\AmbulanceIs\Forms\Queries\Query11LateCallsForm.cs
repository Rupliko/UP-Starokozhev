﻿using AmbulanceIs.Common;
using AmbulanceIs.Domain;
using AmbulanceIs.Forms.Base;
using AmbulanceIs.Services;

namespace AmbulanceIs.Forms.Queries;

/// <summary>Запрос 11: вызовы с прибытием бригады позже нормативного времени.</summary>
public class Query11LateCallsForm : QueryFormBase
{
    private readonly DateTimePicker _fromPicker = new() { Format = DateTimePickerFormat.Short };
    private readonly DateTimePicker _toPicker = new() { Format = DateTimePickerFormat.Short };
    private readonly FilterCombo _crewCombo = new();
    private readonly FilterCombo _stationCombo = new();

    public Query11LateCallsForm(DataStore store)
        : base(store, "Задержки прибытия бригад",
            "Перечень вызовов, на которые бригада прибыла позже нормативного времени, с величиной задержки")
    {
        var (from, to) = DefaultPeriod();
        _fromPicker.Value = from;
        _toPicker.Value = to;
        _crewCombo.Fill(CrewOptions());
        _stationCombo.Fill(StationOptions());
    }

    protected override void BuildFilters(FlowLayoutPanel host)
    {
        AddFilter(host, "Период с", _fromPicker, 150);
        AddFilter(host, "по", _toPicker, 150);
        AddFilter(host, "Бригада", _crewCombo, 230);
        AddFilter(host, "Подстанция", _stationCombo, 220);
    }

    protected override QueryResult Execute()
    {
        var (from, to) = ValidatePeriod(_fromPicker, _toPicker);
        return Service.GetLateCalls(from, to, _crewCombo.SelectedValue, _stationCombo.SelectedValue);
    }
}
