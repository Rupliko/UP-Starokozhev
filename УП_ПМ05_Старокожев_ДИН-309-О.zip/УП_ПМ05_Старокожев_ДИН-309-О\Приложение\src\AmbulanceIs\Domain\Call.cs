﻿namespace AmbulanceIs.Domain;

/// <summary>Вызов — основной объект учёта службы скорой помощи.</summary>
public class Call
{
    public int Id { get; set; }

    public string Number { get; set; } = string.Empty;

    public DateTime ReceivedAt { get; set; }

    public string District { get; set; } = string.Empty;

    public string Street { get; set; } = string.Empty;

    public string House { get; set; } = string.Empty;

    public int PatientId { get; set; }

    public string Reason { get; set; } = string.Empty;

    public UrgencyCategory Urgency { get; set; }

    public int? CrewId { get; set; }

    public int? DoctorId { get; set; }

    public DateTime? ArrivalAt { get; set; }

    public DateTime? FinishedAt { get; set; }

    public string Aid { get; set; } = string.Empty;

    public string Diagnosis { get; set; } = string.Empty;

    public CallResult? Result { get; set; }

    public int? HospitalId { get; set; }

    public CallStatus Status { get; set; }

    public string Address => $"{District}, ул. {Street}, д. {House}";

    public TimeSpan? ArrivalDelay => ArrivalAt is null
        ? null
        : ArrivalAt.Value - ReceivedAt - TimeSpan.FromMinutes(Urgency.NormativeArrivalMinutes());

    public bool IsLate => ArrivalDelay is not null && ArrivalDelay.Value.TotalMinutes > 0;
}
