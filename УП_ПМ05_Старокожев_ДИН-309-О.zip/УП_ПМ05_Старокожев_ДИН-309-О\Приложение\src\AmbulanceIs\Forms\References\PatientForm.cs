﻿using AmbulanceIs.Common;
using AmbulanceIs.Domain;
using AmbulanceIs.Forms.Base;
using AmbulanceIs.Services;

namespace AmbulanceIs.Forms.References;

/// <summary>Окно справочника пациентов службы скорой помощи.</summary>
public class PatientForm : EntityForm<Patient>
{
    private readonly TextBox _fullNameBox = AppTheme.CreateTextBox();
    private readonly ComboBox _sexBox = AppTheme.CreateComboBox();
    private readonly NumericUpDown _ageBox = new() { Minimum = 0, Maximum = 120, Font = AppTheme.Body(10F) };
    private readonly TextBox _districtBox = AppTheme.CreateTextBox();
    private readonly TextBox _policyBox = AppTheme.CreateTextBox();

    public PatientForm(DataStore store)
        : base(store, "Пациенты", "Справочник пациентов: персональные данные и район обслуживания")
    {
        _sexBox.Items.AddRange(["Мужской", "Женский"]);
    }

    protected override string SearchPlaceholder => "ФИО или район";

    protected override string EntityName => "Пациент";

    protected override void ConfigureColumns(DataGridView grid)
    {
        grid.AutoGenerateColumns = false;
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "ФИО пациента", DataPropertyName = nameof(Patient.FullName), FillWeight = 200 });
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Пол", DataPropertyName = nameof(Patient.SexName), FillWeight = 80 });
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Возраст", DataPropertyName = nameof(Patient.Age), FillWeight = 70 });
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Район", DataPropertyName = nameof(Patient.District), FillWeight = 110 });
        grid.Columns.Add(new DataGridViewTextBoxColumn { HeaderText = "Номер полиса", DataPropertyName = nameof(Patient.PolicyNumber), FillWeight = 130 });
    }

    protected override void BuildEditor(FlowLayoutPanel host)
    {
        AddEditorRow(host, "ФИО пациента *", _fullNameBox, "Фамилия Имя Отчество");
        AddEditorRow(host, "Пол *", _sexBox);
        AddEditorRow(host, "Возраст, лет *", _ageBox);
        AddEditorRow(host, "Район проживания *", _districtBox);
        AddEditorRow(host, "Номер полиса ОМС *", _policyBox, "Формат: 5501 112233");
    }

    protected override void ClearEditor()
    {
        _fullNameBox.Clear();
        _sexBox.SelectedIndex = -1;
        _ageBox.Value = 0;
        _districtBox.Clear();
        _policyBox.Clear();
    }

    protected override Patient CreateEntity()
    {
        if (!InputValidator.TryParseFullName(_fullNameBox.Text, out var fullName, out var error))
        {
            throw new InputValidationException(error);
        }

        if (_sexBox.SelectedIndex < 0)
        {
            throw new InputValidationException("Выберите пол пациента.");
        }

        if (_districtBox.Text.Trim().Length < 3)
        {
            throw new InputValidationException("Поле «Район проживания» должно содержать не менее 3 символов.");
        }

        if (_policyBox.Text.Trim().Length < 6)
        {
            throw new InputValidationException("Поле «Номер полиса ОМС» должно содержать не менее 6 символов.");
        }

        return new Patient
        {
            Id = Store.Patients.Count == 0 ? 1 : Store.Patients.Max(item => item.Id) + 1,
            FullName = fullName,
            Sex = (Sex)_sexBox.SelectedIndex,
            Age = (int)_ageBox.Value,
            District = _districtBox.Text.Trim(),
            PolicyNumber = _policyBox.Text.Trim()
        };
    }

    protected override void FillEditor(Patient item)
    {
        _fullNameBox.Text = item.FullName;
        _sexBox.SelectedIndex = (int)item.Sex;
        _ageBox.Value = item.Age;
        _districtBox.Text = item.District;
        _policyBox.Text = item.PolicyNumber;
    }

    protected override IReadOnlyList<Patient> LoadItems() => Store.Patients;

    protected override void EditExisting(Patient? current, Patient updated)
    {
        if (current is null)
        {
            return;
        }

        current.FullName = updated.FullName;
        current.Sex = updated.Sex;
        current.Age = updated.Age;
        current.District = updated.District;
        current.PolicyNumber = updated.PolicyNumber;
    }

    protected override void PersistNew(Patient entity) => Store.Patients.Add(entity);

    protected override void PersistDelete(Patient entity) => Store.Patients.Remove(entity);

    protected override bool MatchesSearch(Patient item, string query) =>
        item.FullName.Contains(query, StringComparison.OrdinalIgnoreCase) ||
        item.District.Contains(query, StringComparison.OrdinalIgnoreCase);
}
