﻿namespace AmbulanceIs.Domain;

/// <summary>Тип выездной бригады.</summary>
public enum CrewType
{
    Feldsher = 0,
    Medical = 1
}

/// <summary>Отображаемые названия типов бригад.</summary>
public static class CrewTypeNames
{
    public static string ToRussian(this CrewType type) => type switch
    {
        CrewType.Feldsher => "Фельдшерская",
        CrewType.Medical => "Врачебная",
        _ => "Не указан"
    };
}
