﻿using AmbulanceIs.Common;
using AmbulanceIs.Domain;

namespace AmbulanceIs.Services;

/// <summary>Результат проверки логина и пароля.</summary>
public enum AuthenticationStatus
{
    Success,
    InvalidCredentials,
    Blocked,
    CaptchaRequired,
    EmptyCredentials
}

/// <summary>Итог попытки авторизации.</summary>
public class AuthenticationResult
{
    public AuthenticationStatus Status { get; init; }

    public string Message { get; init; } = string.Empty;

    public UserAccount? Account { get; init; }
}

/// <summary>Подсистема аутентификации: проверка пары «логин/пароль», блокировка после трёх неудач.</summary>
public class AuthenticationService
{
    public const int MaxFailedAttempts = 3;

    private readonly UserRepository _repository;

    public AuthenticationService(UserRepository repository)
    {
        _repository = repository;
    }

    /// <summary>Проверяет введённые данные. Для роли «Пользователь» требуется дополнительно собрать капчу.</summary>
    public AuthenticationResult Authenticate(string login, string password)
    {
        if (string.IsNullOrWhiteSpace(login) || string.IsNullOrWhiteSpace(password))
        {
            return new AuthenticationResult
            {
                Status = AuthenticationStatus.EmptyCredentials,
                Message = "Поля «Логин» и «Пароль» обязательны для заполнения."
            };
        }

        var account = _repository.Find(login);
        if (account is null)
        {
            return new AuthenticationResult
            {
                Status = AuthenticationStatus.InvalidCredentials,
                Message = Messages.AuthorizationFailed
            };
        }

        if (account.IsBlocked)
        {
            return new AuthenticationResult
            {
                Status = AuthenticationStatus.Blocked,
                Message = Messages.AccountBlocked,
                Account = account
            };
        }

        if (!string.Equals(account.Password, password, StringComparison.Ordinal))
        {
            return RegisterFailure(account);
        }

        if (account.Role == UserRole.Dispatcher)
        {
            return new AuthenticationResult
            {
                Status = AuthenticationStatus.CaptchaRequired,
                Message = "Для завершения входа соберите изображение из фрагментов.",
                Account = account
            };
        }

        account.FailedAttempts = 0;
        return new AuthenticationResult
        {
            Status = AuthenticationStatus.Success,
            Message = Messages.AuthorizationSucceeded,
            Account = account
        };
    }

    /// <summary>Учитывает неудачную попытку сборки капчи для уже проверенной учётной записи.</summary>
    public AuthenticationResult RegisterCaptchaFailure(UserAccount account)
    {
        account.FailedAttempts++;
        if (account.FailedAttempts >= MaxFailedAttempts)
        {
            account.IsBlocked = true;
            return new AuthenticationResult
            {
                Status = AuthenticationStatus.Blocked,
                Message = Messages.AccountBlocked,
                Account = account
            };
        }

        var left = MaxFailedAttempts - account.FailedAttempts;
        return new AuthenticationResult
        {
            Status = AuthenticationStatus.InvalidCredentials,
            Message = $"Изображение собрано неверно. Осталось попыток: {left}.",
            Account = account
        };
    }

    /// <summary>Фиксирует успешный вход и обнуляет счётчик неудачных попыток.</summary>
    public AuthenticationResult ConfirmSuccess(UserAccount account)
    {
        account.FailedAttempts = 0;
        return new AuthenticationResult
        {
            Status = AuthenticationStatus.Success,
            Message = Messages.AuthorizationSucceeded,
            Account = account
        };
    }

    private AuthenticationResult RegisterFailure(UserAccount account)
    {
        account.FailedAttempts++;
        if (account.FailedAttempts >= MaxFailedAttempts)
        {
            account.IsBlocked = true;
            return new AuthenticationResult
            {
                Status = AuthenticationStatus.Blocked,
                Message = Messages.AccountBlocked,
                Account = account
            };
        }

        return new AuthenticationResult
        {
            Status = AuthenticationStatus.InvalidCredentials,
            Message = Messages.AuthorizationFailed,
            Account = account
        };
    }
}
