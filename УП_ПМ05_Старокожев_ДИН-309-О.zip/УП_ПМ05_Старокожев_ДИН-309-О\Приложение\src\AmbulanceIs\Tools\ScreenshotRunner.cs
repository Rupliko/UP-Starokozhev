﻿using System.Drawing.Imaging;
using System.Runtime.InteropServices;
using AmbulanceIs.Common;
using AmbulanceIs.Controls;
using AmbulanceIs.Domain;
using AmbulanceIs.Forms;
using AmbulanceIs.Forms.Documents;
using AmbulanceIs.Forms.Queries;
using AmbulanceIs.Forms.References;
using AmbulanceIs.Services;

namespace AmbulanceIs.Tools;

/// <summary>Формирует изображения экранных форм для отчёта по практике.</summary>
public static class ScreenshotRunner
{
    [DllImport("user32.dll", CharSet = CharSet.Auto)]
    private static extern bool PostMessage(IntPtr hWnd, uint msg, IntPtr wParam, IntPtr lParam);

    [DllImport("user32.dll", CharSet = CharSet.Auto)]
    private static extern IntPtr FindWindow(string? className, string windowName);

    [DllImport("user32.dll")]
    private static extern bool GetWindowRect(IntPtr hWnd, out Rect rect);

    [DllImport("user32.dll")]
    private static extern bool PrintWindow(IntPtr hWnd, IntPtr hdc, uint flags);

    [StructLayout(LayoutKind.Sequential)]
    private struct Rect
    {
        public int Left;
        public int Top;
        public int Right;
        public int Bottom;
    }

    public static int Run(string directory)
    {
        Directory.CreateDirectory(directory);
        DataStore.Initialize();
        var store = DataStore.Demo;
        var repository = new UserRepository();
        var service = new AuthenticationService(repository);
        var admin = repository.Find("admin")!;
        Session.CurrentUser = admin;
        Session.DemoMode = true;

        Capture(directory, "01_login", new LoginForm(service, repository), form => { }, new Size(1000, 660));

        Capture(directory, "02_login_captcha", new LoginForm(service, repository), form =>
        {
            ((LoginForm)form).ShowCaptchaForPreview(solved: false);
        }, new Size(1000, 880));

        Capture(directory, "03_login_error", new LoginForm(service, repository), form =>
        {
            ((LoginForm)form).ShowErrorForPreview(Messages.AuthorizationFailed);
        }, new Size(1000, 660));

        Capture(directory, "04_main", new MainForm(store, repository), form => { }, new Size(1280, 800));
        Capture(directory, "05_substations", new SubstationForm(store), SelectAndEdit, new Size(1180, 720));
        Capture(directory, "06_employees", new EmployeeForm(store), SelectAndEdit, new Size(1180, 720));
        Capture(directory, "07_crews", new CrewForm(store), SelectAndEdit, new Size(1180, 720));
        Capture(directory, "08_vehicles", new VehicleForm(store), SelectAndEdit, new Size(1180, 720));
        Capture(directory, "09_patients", new PatientForm(store), SelectAndEdit, new Size(1180, 720));
        Capture(directory, "10_calls", new CallForm(store), SelectAndEdit, new Size(1240, 780));
        Capture(directory, "11_crew_members", new CrewMemberForm(store), SelectAndEdit, new Size(1180, 720));
        Capture(directory, "12_query_crews", new Query01CrewsForm(store), form => { }, new Size(1100, 660));
        Capture(directory, "13_query_calls", new Query04CallsForm(store), form => { }, new Size(1100, 660));
        Capture(directory, "14_query_arrival", new Query05ArrivalForm(store), form => { }, new Size(1100, 660));
        Capture(directory, "15_query_load", new Query07StationLoadForm(store), form => { }, new Size(1100, 660));
        Capture(directory, "16_query_history", new Query09PatientHistoryForm(store), form => { }, new Size(1100, 660));
        Capture(directory, "17_query_hospital", new Query10HospitalizationsForm(store), form => { }, new Size(1100, 660));
        Capture(directory, "18_query_late", new Query11LateCallsForm(store), form => { }, new Size(1100, 660));
        Capture(directory, "19_query_fleet", new Query12FleetForm(store), form => { }, new Size(1100, 660));
        Capture(directory, "20_users", new UsersForm(repository), SelectFirstRow, new Size(880, 520));
        Capture(directory, "21_about", new AboutForm(), form => { }, new Size(520, 360));
        CaptureMessageBox(directory, "22_message_error", "Ошибка авторизации", Messages.AuthorizationFailed);

        Console.WriteLine($"Изображения сохранены в каталог: {directory}");
        return 0;
    }

    /// <summary>Выделяет первую запись и переводит окно в режим редактирования.</summary>
    private static void SelectAndEdit(Form form)
    {
        SelectFirstRow(form);
        Application.DoEvents();
        foreach (var strip in FindToolStrips(form))
        {
            foreach (ToolStripItem item in strip.Items)
            {
                if (item is ToolStripButton { Text: "Изменить" } button)
                {
                    button.PerformClick();
                    Application.DoEvents();
                    return;
                }
            }
        }
    }

    private static IEnumerable<ToolStrip> FindToolStrips(Control parent)
    {
        foreach (Control child in parent.Controls)
        {
            if (child is ToolStrip strip)
            {
                yield return strip;
            }

            foreach (var nested in FindToolStrips(child))
            {
                yield return nested;
            }
        }
    }

    private static void SelectFirstRow(Form form)
    {
        var grids = FindGrids(form);
        foreach (var grid in grids)
        {
            if (grid.Rows.Count > 0)
            {
                grid.CurrentCell = grid.Rows[0].Cells[0];
                grid.Rows[0].Selected = true;
                break;
            }
        }
    }

    private static IEnumerable<DataGridView> FindGrids(Control parent)
    {
        foreach (Control child in parent.Controls)
        {
            if (child is DataGridView grid)
            {
                yield return grid;
            }

            foreach (var nested in FindGrids(child))
            {
                yield return nested;
            }
        }
    }

    /// <summary>Сохраняет изображение стандартного окна сообщения об ошибке.</summary>
    private static void CaptureMessageBox(string directory, string name, string title, string text)
    {
        try
        {
            using var owner = new Form
            {
                Text = "Служебное окно",
                StartPosition = FormStartPosition.Manual,
                Location = new Point(4, 4),
                Size = new Size(400, 300),
                ShowInTaskbar = false,
                Opacity = 0
            };
            owner.Show();
            Application.DoEvents();

            var path = Path.Combine(directory, $"{name}.png");
            var worker = new Thread(() =>
            {
                try
                {
                    Thread.Sleep(700);
                    var handle = IntPtr.Zero;
                    for (var attempt = 0; attempt < 40 && handle == IntPtr.Zero; attempt++)
                    {
                        handle = FindWindow("#32770", title);
                        if (handle == IntPtr.Zero)
                        {
                            Thread.Sleep(120);
                        }
                    }

                    if (handle == IntPtr.Zero || !GetWindowRect(handle, out var rect))
                    {
                        return;
                    }

                    var width = rect.Right - rect.Left;
                    var height = rect.Bottom - rect.Top;
                    using var bitmap = new Bitmap(width, height);
                    using (var graphics = Graphics.FromImage(bitmap))
                    {
                        var hdc = graphics.GetHdc();
                        PrintWindow(handle, hdc, 2);
                        graphics.ReleaseHdc(hdc);
                    }

                    bitmap.Save(path, ImageFormat.Png);
                    Console.WriteLine($"  {name}.png ({width}x{height})");
                }
                catch (Exception)
                {
                    // Окно сообщения не удалось сохранить — изображение не включается в отчёт.
                }
                finally
                {
                    var handle = FindWindow("#32770", title);
                    if (handle != IntPtr.Zero)
                    {
                        PostMessage(handle, 0x0010, IntPtr.Zero, IntPtr.Zero);
                    }
                }
            });
            worker.IsBackground = true;
            worker.Start();

            MessageBox.Show(owner, text, title, MessageBoxButtons.OK, MessageBoxIcon.Error);
            owner.Close();
        }
        catch (Exception)
        {
            // Изображение окна сообщения необязательно для отчёта.
        }
    }

    private static void Capture(string directory, string name, Form form, Action<Form> prepare, Size size)
    {
        form.StartPosition = FormStartPosition.Manual;
        form.Location = new Point(4, 4);
        form.TopMost = true;
        form.WindowState = FormWindowState.Normal;
        form.ShowInTaskbar = false;

        form.Show();
        Application.DoEvents();
        form.ClientSize = new Size(size.Width, size.Height - (form.Height - form.ClientSize.Height));
        prepare(form);
        Application.DoEvents();
        Thread.Sleep(220);
        Application.DoEvents();

        using var bitmap = new Bitmap(form.Width, form.Height);
        form.DrawToBitmap(bitmap, new Rectangle(0, 0, form.Width, form.Height));
        var path = Path.Combine(directory, $"{name}.png");
        bitmap.Save(path, ImageFormat.Png);
        Console.WriteLine($"  {name}.png ({bitmap.Width}x{bitmap.Height})");

        form.TopMost = false;
        form.Close();
        form.Dispose();
        Application.DoEvents();
    }
}
