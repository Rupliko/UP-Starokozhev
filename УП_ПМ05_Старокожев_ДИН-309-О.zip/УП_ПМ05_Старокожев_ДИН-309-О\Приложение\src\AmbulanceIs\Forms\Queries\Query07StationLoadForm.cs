﻿using AmbulanceIs.Common;
using AmbulanceIs.Domain;
using AmbulanceIs.Forms.Base;
using AmbulanceIs.Services;

namespace AmbulanceIs.Forms.Queries;

/// <summary>Запрос 7: загрузка подстанции на текущий момент.</summary>
public class Query07StationLoadForm : QueryFormBase
{
    private readonly FilterCombo _stationCombo = new();

    public Query07StationLoadForm(DataStore store)
        : base(store, "Загрузка подстанций",
            "Число дежурных и свободных бригад, число выполняемых вызовов на текущий момент")
    {
        _stationCombo.Fill(StationOptions());
    }

    protected override void BuildFilters(FlowLayoutPanel host)
    {
        AddFilter(host, "Подстанция", _stationCombo, 280);
    }

    protected override QueryResult Execute() => Service.GetSubstationLoad(_stationCombo.SelectedValue);
}
